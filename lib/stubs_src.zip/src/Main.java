import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.client.Options;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.jetbrains.tfsIntegration.stubs.RepositoryRepositorySoap12Stub;
import org.jetbrains.tfsIntegration.stubs.compatibility.CustomSOAPBuilder;
 
public class Main {

	public static void main(String[] args) {
		try {

			System.setProperty("http.proxyHost", "127.0.0.1");
			System.setProperty("http.proxyPort", "8888");

			String endpoint = "http://1win2k3r2ee2:8080/VersionControl/v1.0/Repository.asmx1";

			ConfigurationContext configContext = ConfigurationContextFactory.createDefaultConfigurationContext();
			configContext.getAxisConfiguration().addMessageBuilder("application/soap+xml", new CustomSOAPBuilder());

			RepositoryRepositorySoap12Stub repository = new RepositoryRepositorySoap12Stub(configContext, endpoint);
			Options options = repository._getServiceClient().getOptions();
			HttpTransportProperties.Authenticator auth = new HttpTransportProperties.Authenticator();
			auth.setUsername("tfsuser"); // TODO: remove hardcoded login and
											// password
			auth.setPassword("Parol");
			auth.setDomain("SWIFTTEAMS");
			auth.setHost(new URI(endpoint).getHost());
			options.setProperty(HTTPConstants.AUTHENTICATE, auth);
			options.setProperty(HTTPConstants.CHUNKED, Constants.VALUE_FALSE);
			repository.QueryWorkspace("dfg", "SWIFTTEAMS\\tfsuser");
		}
		// TODO Auto-generated catch block
		catch (AxisFault e) {
			Throwable cause = e.getCause();
			//TfsException ee = TfsExceptionManager.processException(e);
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
