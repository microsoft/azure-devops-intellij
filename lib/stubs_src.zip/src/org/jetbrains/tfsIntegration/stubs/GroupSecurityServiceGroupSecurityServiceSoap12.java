/**
 * GroupSecurityServiceGroupSecurityServiceSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  GroupSecurityServiceGroupSecurityServiceSoap12 java interface
 */
public interface GroupSecurityServiceGroupSecurityServiceSoap12 {
    /**
     * Auto generated method signature
     * @param readIdentity
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.Identity ReadIdentity(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor,
        java.lang.String factorValue,
        org.jetbrains.tfsIntegration.stubs.services.authorization.QueryMembership queryMembership)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param readIdentityFromSource
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.Identity ReadIdentityFromSource(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor0,
        java.lang.String factorValue1) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param isIdentityCached
     */
    public boolean IsIdentityCached(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor2,
        java.lang.String factorValue3) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getChangedIdentities
     */
    public java.lang.String GetChangedIdentities(int sequence_id)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createApplicationGroup
     */
    public java.lang.String CreateApplicationGroup(
        java.lang.String projectUri, java.lang.String groupName,
        java.lang.String groupDescription) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listApplicationGroups
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ArrayOfIdentity ListApplicationGroups(
        java.lang.String projectUri4) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateApplicationGroup
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse UpdateApplicationGroup(
        java.lang.String groupSid,
        org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupProperty property,
        java.lang.String newValue) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteApplicationGroup
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse DeleteApplicationGroup(
        java.lang.String groupSid5) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param addMemberToApplicationGroup
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse AddMemberToApplicationGroup(
        java.lang.String groupSid6, java.lang.String identitySid)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param removeMemberFromApplicationGroup
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse RemoveMemberFromApplicationGroup(
        java.lang.String groupSid7, java.lang.String identitySid8)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param isMember
     */
    public boolean IsMember(java.lang.String groupSid9,
        java.lang.String identitySid10) throws java.rmi.RemoteException;

    //
}
