

/**
 * ClassificationClassificationSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  ClassificationClassificationSoap12 java interface
     */

    public interface ClassificationClassificationSoap12 {
          

        /**
          * Auto generated method signature
          * 
                    * @param createNode
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse CreateNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode createNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNodesXml
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse GetNodesXml(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml getNodesXml)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProjectProperties
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse GetProjectProperties(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties getProjectProperties)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listProjects
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse ListProjects(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects listProjects)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNodeFromPath
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse GetNodeFromPath(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath getNodeFromPath)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteProject
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse DeleteProject(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject deleteProject)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProject
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse GetProject(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject getProject)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteBranches
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse DeleteBranches(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches deleteBranches)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNode
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse GetNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode getNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getDeletedNodesXml
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse GetDeletedNodesXml(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml getDeletedNodesXml)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createProject
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse CreateProject(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject createProject)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param reorderNode
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse ReorderNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode reorderNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listStructures
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse ListStructures(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures listStructures)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param renameNode
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse RenameNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode renameNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProjectFromName
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse GetProjectFromName(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName getProjectFromName)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param moveBranch
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse MoveBranch(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch moveBranch)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateProjectProperties
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse UpdateProjectProperties(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties updateProjectProperties)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getChangedNodes
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse GetChangedNodes(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes getChangedNodes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listAllProjects
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse ListAllProjects(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects listAllProjects)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    