/**
 * ClassificationClassificationSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClassificationClassificationSoap12 java interface
 */
public interface ClassificationClassificationSoap12 {
    /**
     * Auto generated method signature
     * @param createProject
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo CreateProject(
        java.lang.String projectName,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.Structure_type0 structure)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteProject
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse DeleteProject(
        java.lang.String projectUri) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getProjectProperties
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse GetProjectProperties(
        java.lang.String projectUri0) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateProjectProperties
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse UpdateProjectProperties(
        java.lang.String projectUri1, java.lang.String state,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectProperty properties)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getProject
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo GetProject(
        java.lang.String projectUri2) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getProjectFromName
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo GetProjectFromName(
        java.lang.String projectName3) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listProjects
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo ListProjects(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects listProjects)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listAllProjects
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo ListAllProjects(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects listAllProjects)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listStructures
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfNodeInfo ListStructures(
        java.lang.String projectUri4) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getNodesXml
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResult_type0 GetNodesXml(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString nodeUris,
        boolean childNodes) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createNode
     */
    public java.lang.String CreateNode(java.lang.String nodeName,
        java.lang.String parentNodeUri) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param renameNode
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse RenameNode(
        java.lang.String nodeUri, java.lang.String newNodeName)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param moveBranch
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse MoveBranch(
        java.lang.String nodeUri5, java.lang.String newParentNodeUri)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param reorderNode
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse ReorderNode(
        java.lang.String nodeUri6, int moveBy) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteBranches
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse DeleteBranches(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString nodeUris7,
        java.lang.String reclassifyUri) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getDeletedNodesXml
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResult_type0 GetDeletedNodesXml(
        java.lang.String projectUri8, java.util.Calendar since)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getNode
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo GetNode(
        java.lang.String nodeUri9) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getNodeFromPath
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo GetNodeFromPath(
        java.lang.String nodePath) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getChangedNodes
     */
    public java.lang.String GetChangedNodes(int firstSequenceId)
        throws java.rmi.RemoteException;

    //
}
