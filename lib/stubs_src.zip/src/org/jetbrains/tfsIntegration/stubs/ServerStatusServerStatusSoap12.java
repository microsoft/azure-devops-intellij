

/**
 * ServerStatusServerStatusSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  ServerStatusServerStatusSoap12 java interface
     */

    public interface ServerStatusServerStatusSoap12 {
          

        /**
          * Auto generated method signature
          * 
                    * @param checkAuthentication
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.serverstatus.CheckAuthenticationResponse CheckAuthentication(

                        org.jetbrains.tfsIntegration.stubs.services.serverstatus.CheckAuthentication checkAuthentication)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getServerStatus
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetServerStatusResponse GetServerStatus(

                        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetServerStatus getServerStatus)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getSupportedContractVersion
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetSupportedContractVersionResponse GetSupportedContractVersion(

                        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetSupportedContractVersion getSupportedContractVersion)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    