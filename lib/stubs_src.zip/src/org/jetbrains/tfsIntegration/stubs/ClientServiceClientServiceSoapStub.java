/**
 * ClientServiceClientServiceSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClientServiceClientServiceSoapStub java implementation
 */
public class ClientServiceClientServiceSoapStub extends org.apache.axis2.client.Stub
    implements ClientServiceClientServiceSoap {
    protected org.apache.axis2.description.AxisOperation[] _operations;

    //hashmaps to keep the fault mapping
    private java.util.HashMap faultExceptionNameMap = new java.util.HashMap();
    private java.util.HashMap faultExceptionClassNameMap = new java.util.HashMap();
    private java.util.HashMap faultMessageMap = new java.util.HashMap();
    private javax.xml.namespace.QName[] opNameArray = null;

    /**
     *Constructor that takes in a configContext
     */
    public ClientServiceClientServiceSoapStub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(configurationContext, targetEndpoint, false);
    }

    /**
     * Constructor that takes in a configContext  and useseperate listner
     */
    public ClientServiceClientServiceSoapStub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint, boolean useSeparateListener)
        throws org.apache.axis2.AxisFault {
        //To populate AxisService
        populateAxisService();
        populateFaults();

        _serviceClient = new org.apache.axis2.client.ServiceClient(configurationContext,
                _service);

        configurationContext = _serviceClient.getServiceContext()
                                             .getConfigurationContext();

        _serviceClient.getOptions()
                      .setTo(new org.apache.axis2.addressing.EndpointReference(
                targetEndpoint));
        _serviceClient.getOptions().setUseSeparateListener(useSeparateListener);
    }

    /**
     * Default Constructor
     */
    public ClientServiceClientServiceSoapStub(
        org.apache.axis2.context.ConfigurationContext configurationContext)
        throws org.apache.axis2.AxisFault {
        this(configurationContext,
            "http://wmw-2003-01:8080/WorkItemTracking/v1.0/ClientService.asmx");
    }

    /**
     * Default Constructor
     */
    public ClientServiceClientServiceSoapStub()
        throws org.apache.axis2.AxisFault {
        this("http://wmw-2003-01:8080/WorkItemTracking/v1.0/ClientService.asmx");
    }

    /**
     * Constructor taking the target endpoint
     */
    public ClientServiceClientServiceSoapStub(java.lang.String targetEndpoint)
        throws org.apache.axis2.AxisFault {
        this(null, targetEndpoint);
    }

    private void populateAxisService() throws org.apache.axis2.AxisFault {
        //creating the Service with a unique name
        _service = new org.apache.axis2.description.AxisService("ClientService" +
                this.hashCode());

        //creating the operations
        org.apache.axis2.description.AxisOperation __operation;

        _operations = new org.apache.axis2.description.AxisOperation[21];

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetWorkitemTrackingVersion"));
        _service.addOperation(__operation);

        _operations[0] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "StampWorkitemCache"));
        _service.addOperation(__operation);

        _operations[1] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetReferencingWorkitemUris"));
        _service.addOperation(__operation);

        _operations[2] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetWorkItem"));
        _service.addOperation(__operation);

        _operations[3] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "QueryWorkitems"));
        _service.addOperation(__operation);

        _operations[4] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "PageWorkitemsByIds"));
        _service.addOperation(__operation);

        _operations[5] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "PageWorkitemsByIdRevs"));
        _service.addOperation(__operation);

        _operations[6] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "PageItemsOnBehalfOf"));
        _service.addOperation(__operation);

        _operations[7] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "QueryWorkitemCount"));
        _service.addOperation(__operation);

        _operations[8] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "QueryWorkitemCountOnBehalfOf"));
        _service.addOperation(__operation);

        _operations[9] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetMetadata"));
        _service.addOperation(__operation);

        _operations[10] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetMetadataEx"));
        _service.addOperation(__operation);

        _operations[11] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetMetadataEx2"));
        _service.addOperation(__operation);

        _operations[12] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "Update"));
        _service.addOperation(__operation);

        _operations[13] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "BulkUpdate"));
        _service.addOperation(__operation);

        _operations[14] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetStoredQuery"));
        _service.addOperation(__operation);

        _operations[15] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetStoredQueries"));
        _service.addOperation(__operation);

        _operations[16] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "SyncExternalStructures"));
        _service.addOperation(__operation);

        _operations[17] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "SyncAccessControlLists"));
        _service.addOperation(__operation);

        _operations[18] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "SyncBisGroupsAndUsers"));
        _service.addOperation(__operation);

        _operations[19] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "RequestCancel"));
        _service.addOperation(__operation);

        _operations[20] = __operation;
    }

    //populates the faults
    private void populateFaults() {
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetWorkitemTrackingVersion
     * @param getWorkitemTrackingVersion43
     * @param requestHeader44
     */
    public java.lang.String GetWorkitemTrackingVersion(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion43,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader44)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[0].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetWorkitemTrackingVersion");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    getWorkitemTrackingVersion43,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetWorkitemTrackingVersion")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader44 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader44 = toOM(requestHeader44,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetWorkitemTrackingVersion")));
                addHeader(omElementrequestHeader44, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetWorkitemTrackingVersionResponseGetWorkitemTrackingVersionResult((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#StampWorkitemCache
     * @param stampWorkitemCache47
     * @param requestHeader48
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache47,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader48)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[1].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/StampWorkitemCache");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    stampWorkitemCache47,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "StampWorkitemCache")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader48 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader48 = toOM(requestHeader48,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "StampWorkitemCache")));
                addHeader(omElementrequestHeader48, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetReferencingWorkitemUris
     * @param getReferencingWorkitemUris50
     * @param requestHeader52
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString GetReferencingWorkitemUris(
        java.lang.String artifactUri51,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader52)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[2].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetReferencingWorkitemUris");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    artifactUri51, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetReferencingWorkitemUris")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader52 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader52 = toOM(requestHeader52,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetReferencingWorkitemUris")));
                addHeader(omElementrequestHeader52, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetReferencingWorkitemUrisResponseGetReferencingWorkitemUrisResult((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetWorkItem
     * @param getWorkItem55
     * @param requestHeader62
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(
        int workItemId56, int revisionId57, int minimumRevisionId58,
        java.util.Calendar asOfDate59, boolean useMaster60,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave61,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader62)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[3].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetWorkItem");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    workItemId56, revisionId57, minimumRevisionId58,
                    asOfDate59, useMaster60, metadataHave61, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetWorkItem")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader62 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader62 = toOM(requestHeader62,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetWorkItem")));
                addHeader(omElementrequestHeader62, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#QueryWorkitems
     * @param queryWorkitems64
     * @param requestHeader66
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 psQuery65,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader66)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[4].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitems");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    psQuery65, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "QueryWorkitems")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader66 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader66 = toOM(requestHeader66,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "QueryWorkitems")));
                addHeader(omElementrequestHeader66, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#PageWorkitemsByIds
     * @param pageWorkitemsByIds68
     * @param requestHeader75
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids69,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns70,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns71,
        java.util.Calendar asOfDate72, boolean useMaster73,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave74,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader75)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[5].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageWorkitemsByIds");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    ids69, columns70, longTextColumns71, asOfDate72,
                    useMaster73, metadataHave74, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "PageWorkitemsByIds")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader75 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader75 = toOM(requestHeader75,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "PageWorkitemsByIds")));
                addHeader(omElementrequestHeader75, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#PageWorkitemsByIdRevs
     * @param pageWorkitemsByIdRevs77
     * @param requestHeader83
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair pairs78,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns79,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns80,
        java.util.Calendar asOfDate81, boolean useMaster82,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader83)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[6].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageWorkitemsByIdRevs");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    pairs78, columns79, longTextColumns80, asOfDate81,
                    useMaster82, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "PageWorkitemsByIdRevs")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader83 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader83 = toOM(requestHeader83,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "PageWorkitemsByIdRevs")));
                addHeader(omElementrequestHeader83, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#PageItemsOnBehalfOf
     * @param pageItemsOnBehalfOf85
     * @param requestHeader89
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 PageItemsOnBehalfOf(
        java.lang.String userName86,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids87,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns88,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader89)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[7].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageItemsOnBehalfOf");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    userName86, ids87, columns88, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "PageItemsOnBehalfOf")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader89 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader89 = toOM(requestHeader89,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "PageItemsOnBehalfOf")));
                addHeader(omElementrequestHeader89, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getPageItemsOnBehalfOfResponseItems((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#QueryWorkitemCount
     * @param queryWorkitemCount92
     * @param requestHeader96
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 psQuery93,
        boolean useMaster94,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave95,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader96)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[8].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitemCount");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    psQuery93, useMaster94, metadataHave95, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "QueryWorkitemCount")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader96 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader96 = toOM(requestHeader96,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "QueryWorkitemCount")));
                addHeader(omElementrequestHeader96, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#QueryWorkitemCountOnBehalfOf
     * @param queryWorkitemCountOnBehalfOf98
     * @param requestHeader101
     */
    public int QueryWorkitemCountOnBehalfOf(java.lang.String userName99,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 query100,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader101)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[9].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitemCountOnBehalfOf");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    userName99, query100, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "QueryWorkitemCountOnBehalfOf")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader101 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader101 = toOM(requestHeader101,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "QueryWorkitemCountOnBehalfOf")));
                addHeader(omElementrequestHeader101, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getQueryWorkitemCountOnBehalfOfResponseCount((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetMetadata
     * @param getMetadata104
     * @param requestHeader107
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave105,
        boolean useMaster106,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader107)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[10].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadata");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    metadataHave105, useMaster106, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetMetadata")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader107 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader107 = toOM(requestHeader107,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetMetadata")));
                addHeader(omElementrequestHeader107, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetMetadataEx
     * @param getMetadataEx109
     * @param requestHeader112
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave110,
        boolean useMaster111,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader112)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[11].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadataEx");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    metadataHave110, useMaster111, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetMetadataEx")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader112 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader112 = toOM(requestHeader112,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetMetadataEx")));
                addHeader(omElementrequestHeader112, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetMetadataEx2
     * @param getMetadataEx2114
     * @param requestHeader117
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave115,
        boolean useMaster116,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader117)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[12].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadataEx2");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    metadataHave115, useMaster116, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetMetadataEx2")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader117 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader117 = toOM(requestHeader117,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetMetadataEx2")));
                addHeader(omElementrequestHeader117, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#Update
     * @param update119
     * @param requestHeader122
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 _package120,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave121,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader122)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[13].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/Update");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    _package120, metadataHave121, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "Update")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader122 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader122 = toOM(requestHeader122,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "Update")));
                addHeader(omElementrequestHeader122, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#BulkUpdate
     * @param bulkUpdate124
     * @param requestHeader127
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 _package125,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave126,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader127)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[14].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/BulkUpdate");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    _package125, metadataHave126, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "BulkUpdate")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader127 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader127 = toOM(requestHeader127,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "BulkUpdate")));
                addHeader(omElementrequestHeader127, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetStoredQuery
     * @param getStoredQuery129
     * @param requestHeader131
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 GetStoredQuery(
        com.microsoft.wsdl.types.Guid queryId130,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader131)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[15].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQuery");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    queryId130, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetStoredQuery")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader131 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader131 = toOM(requestHeader131,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetStoredQuery")));
                addHeader(omElementrequestHeader131, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetStoredQueryResponseQueryPayload((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetStoredQueries
     * @param getStoredQueries134
     * @param requestHeader137
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 GetStoredQueries(
        long rowVersion135, int projectId136,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader137)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[16].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQueries");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    rowVersion135, projectId136, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetStoredQueries")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader137 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader137 = toOM(requestHeader137,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetStoredQueries")));
                addHeader(omElementrequestHeader137, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetStoredQueriesResponseQueriesPayload((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#SyncExternalStructures
     * @param syncExternalStructures140
     * @param requestHeader142
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(
        java.lang.String projectURI141,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader142)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[17].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncExternalStructures");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectURI141, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "SyncExternalStructures")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader142 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader142 = toOM(requestHeader142,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "SyncExternalStructures")));
                addHeader(omElementrequestHeader142, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#SyncAccessControlLists
     * @param syncAccessControlLists144
     * @param requestHeader146
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(
        java.lang.String projectURI145,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader146)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[18].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncAccessControlLists");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectURI145, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "SyncAccessControlLists")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader146 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader146 = toOM(requestHeader146,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "SyncAccessControlLists")));
                addHeader(omElementrequestHeader146, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#SyncBisGroupsAndUsers
     * @param syncBisGroupsAndUsers148
     * @param requestHeader150
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(
        java.lang.String projectUri149,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader150)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[19].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncBisGroupsAndUsers");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri149, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "SyncBisGroupsAndUsers")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader150 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader150 = toOM(requestHeader150,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "SyncBisGroupsAndUsers")));
                addHeader(omElementrequestHeader150, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#RequestCancel
     * @param requestCancel152
     * @param requestHeader154
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(
        java.lang.String requestIdToCancel153,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader154)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[20].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/RequestCancel");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    requestIdToCancel153, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "RequestCancel")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader154 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader154 = toOM(requestHeader154,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "RequestCancel")));
                addHeader(omElementrequestHeader154, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     *  A utility method that copies the namepaces from the SOAPEnvelope
     */
    private java.util.Map getEnvelopeNamespaces(
        org.apache.axiom.soap.SOAPEnvelope env) {
        java.util.Map returnMap = new java.util.HashMap();
        java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();

        while (namespaceIterator.hasNext()) {
            org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator.next();
            returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
        }

        return returnMap;
    }

    private boolean optimizeContent(javax.xml.namespace.QName opName) {
        if (opNameArray == null) {
            return false;
        }

        for (int i = 0; i < opNameArray.length; i++) {
            if (opName.equals(opNameArray[i])) {
                return true;
            }
        }

        return false;
    }

    //http://wmw-2003-01:8080/WorkItemTracking/v1.0/ClientService.asmx
    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, int param1, int param2,
        int param3, java.util.Calendar param4, boolean param5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param6,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem();

            wrappedType.setWorkItemId(param1);

            wrappedType.setRevisionId(param2);

            wrappedType.setMinimumRevisionId(param3);

            wrappedType.setAsOfDate(param4);

            wrappedType.setUseMaster(param5);

            wrappedType.setMetadataHave(param6);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf();

            wrappedType.setUserName(param1);

            wrappedType.setQuery(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private int getQueryWorkitemCountOnBehalfOfResponseCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse wrappedType) {
        return wrappedType.getCount();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx();

            wrappedType.setMetadataHave(param1);

            wrappedType.setUseMaster(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems();

            wrappedType.setPsQuery(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, long param1, int param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries();

            wrappedType.setRowVersion(param1);

            wrappedType.setProjectId(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 getGetStoredQueriesResponseQueriesPayload(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse wrappedType) {
        return wrappedType.getQueriesPayload();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists();

            wrappedType.setProjectURI(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param3,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount();

            wrappedType.setPsQuery(param1);

            wrappedType.setUseMaster(param2);

            wrappedType.setMetadataHave(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata();

            wrappedType.setMetadataHave(param1);

            wrappedType.setUseMaster(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString param3,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf();

            wrappedType.setUserName(param1);

            wrappedType.setIds(param2);

            wrappedType.setColumns(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 getPageItemsOnBehalfOfResponseItems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse wrappedType) {
        return wrappedType.getItems();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2();

            wrappedType.setMetadataHave(param1);

            wrappedType.setUseMaster(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures();

            wrappedType.setProjectURI(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel();

            wrappedType.setRequestIdToCancel(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate();

            wrappedType.set_package(param1);

            wrappedType.setMetadataHave(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param3,
        java.util.Calendar param4, boolean param5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param6,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds();

            wrappedType.setIds(param1);

            wrappedType.setColumns(param2);

            wrappedType.setLongTextColumns(param3);

            wrappedType.setAsOfDate(param4);

            wrappedType.setUseMaster(param5);

            wrappedType.setMetadataHave(param6);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris();

            wrappedType.setArtifactUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString getGetReferencingWorkitemUrisResponseGetReferencingWorkitemUrisResult(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse wrappedType) {
        return wrappedType.getGetReferencingWorkitemUrisResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param3,
        java.util.Calendar param4, boolean param5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs();

            wrappedType.setPairs(param1);

            wrappedType.setColumns(param2);

            wrappedType.setLongTextColumns(param3);

            wrappedType.setAsOfDate(param4);

            wrappedType.setUseMaster(param5);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update();

            wrappedType.set_package(param1);

            wrappedType.setMetadataHave(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private java.lang.String getGetWorkitemTrackingVersionResponseGetWorkitemTrackingVersionResult(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse wrappedType) {
        return wrappedType.getGetWorkitemTrackingVersionResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        com.microsoft.wsdl.types.Guid param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery();

            wrappedType.setQueryId(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 getGetStoredQueryResponseQueryPayload(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse wrappedType) {
        return wrappedType.getQueryPayload();
    }

    /**
     *  get the default envelope
     */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory) {
        return factory.getDefaultEnvelope();
    }

    private java.lang.Object fromOM(org.apache.axiom.om.OMElement param,
        java.lang.Class type, java.util.Map extraNamespaces)
        throws org.apache.axis2.AxisFault {
        try {
            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

        return null;
    }
}
