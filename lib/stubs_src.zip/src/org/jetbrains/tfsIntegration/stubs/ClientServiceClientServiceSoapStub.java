/**
 * ClientServiceClientServiceSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClientServiceClientServiceSoapStub java implementation
 */
public class ClientServiceClientServiceSoapStub extends org.apache.axis2.client.Stub
    implements ClientServiceClientServiceSoap {
    protected org.apache.axis2.description.AxisOperation[] _operations;

    //hashmaps to keep the fault mapping
    private java.util.HashMap faultExceptionNameMap = new java.util.HashMap();
    private java.util.HashMap faultExceptionClassNameMap = new java.util.HashMap();
    private java.util.HashMap faultMessageMap = new java.util.HashMap();
    private javax.xml.namespace.QName[] opNameArray = null;

    /**
     *Constructor that takes in a configContext
     */
    public ClientServiceClientServiceSoapStub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(configurationContext, targetEndpoint, false);
    }

    /**
     * Constructor that takes in a configContext  and useseperate listner
     */
    public ClientServiceClientServiceSoapStub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint, boolean useSeparateListener)
        throws org.apache.axis2.AxisFault {
        //To populate AxisService
        populateAxisService();
        populateFaults();

        _serviceClient = new org.apache.axis2.client.ServiceClient(configurationContext,
                _service);

        configurationContext = _serviceClient.getServiceContext()
                                             .getConfigurationContext();

        _serviceClient.getOptions()
                      .setTo(new org.apache.axis2.addressing.EndpointReference(
                targetEndpoint));
        _serviceClient.getOptions().setUseSeparateListener(useSeparateListener);
    }

    /**
     * Default Constructor
     */
    public ClientServiceClientServiceSoapStub(
        org.apache.axis2.context.ConfigurationContext configurationContext)
        throws org.apache.axis2.AxisFault {
        this(configurationContext,
            "http://wmw-2003-01:8080/WorkItemTracking/v1.0/ClientService.asmx");
    }

    /**
     * Default Constructor
     */
    public ClientServiceClientServiceSoapStub()
        throws org.apache.axis2.AxisFault {
        this("http://wmw-2003-01:8080/WorkItemTracking/v1.0/ClientService.asmx");
    }

    /**
     * Constructor taking the target endpoint
     */
    public ClientServiceClientServiceSoapStub(java.lang.String targetEndpoint)
        throws org.apache.axis2.AxisFault {
        this(null, targetEndpoint);
    }

    private void populateAxisService() throws org.apache.axis2.AxisFault {
        //creating the Service with a unique name
        _service = new org.apache.axis2.description.AxisService("ClientService" +
                this.hashCode());

        //creating the operations
        org.apache.axis2.description.AxisOperation __operation;

        _operations = new org.apache.axis2.description.AxisOperation[21];

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetWorkitemTrackingVersion"));
        _service.addOperation(__operation);

        _operations[0] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "StampWorkitemCache"));
        _service.addOperation(__operation);

        _operations[1] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetReferencingWorkitemUris"));
        _service.addOperation(__operation);

        _operations[2] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetWorkItem"));
        _service.addOperation(__operation);

        _operations[3] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "QueryWorkitems"));
        _service.addOperation(__operation);

        _operations[4] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "PageWorkitemsByIds"));
        _service.addOperation(__operation);

        _operations[5] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "PageWorkitemsByIdRevs"));
        _service.addOperation(__operation);

        _operations[6] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "PageItemsOnBehalfOf"));
        _service.addOperation(__operation);

        _operations[7] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "QueryWorkitemCount"));
        _service.addOperation(__operation);

        _operations[8] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "QueryWorkitemCountOnBehalfOf"));
        _service.addOperation(__operation);

        _operations[9] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetMetadata"));
        _service.addOperation(__operation);

        _operations[10] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetMetadataEx"));
        _service.addOperation(__operation);

        _operations[11] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetMetadataEx2"));
        _service.addOperation(__operation);

        _operations[12] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "Update"));
        _service.addOperation(__operation);

        _operations[13] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "BulkUpdate"));
        _service.addOperation(__operation);

        _operations[14] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetStoredQuery"));
        _service.addOperation(__operation);

        _operations[15] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "GetStoredQueries"));
        _service.addOperation(__operation);

        _operations[16] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "SyncExternalStructures"));
        _service.addOperation(__operation);

        _operations[17] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "SyncAccessControlLists"));
        _service.addOperation(__operation);

        _operations[18] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "SyncBisGroupsAndUsers"));
        _service.addOperation(__operation);

        _operations[19] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                "RequestCancel"));
        _service.addOperation(__operation);

        _operations[20] = __operation;
    }

    //populates the faults
    private void populateFaults() {
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetWorkitemTrackingVersion
     * @param getWorkitemTrackingVersion45
     * @param requestHeader46
     */
    public java.lang.String GetWorkitemTrackingVersion(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion45,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader46)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[0].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetWorkitemTrackingVersion");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    getWorkitemTrackingVersion45,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetWorkitemTrackingVersion")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader46 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader46 = toOM(requestHeader46,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetWorkitemTrackingVersion")));
                addHeader(omElementrequestHeader46, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetWorkitemTrackingVersionResponseGetWorkitemTrackingVersionResult((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#StampWorkitemCache
     * @param stampWorkitemCache49
     * @param requestHeader50
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache49,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader50)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[1].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/StampWorkitemCache");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    stampWorkitemCache49,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "StampWorkitemCache")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader50 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader50 = toOM(requestHeader50,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "StampWorkitemCache")));
                addHeader(omElementrequestHeader50, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetReferencingWorkitemUris
     * @param getReferencingWorkitemUris52
     * @param requestHeader54
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString GetReferencingWorkitemUris(
        java.lang.String artifactUri53,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader54)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[2].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetReferencingWorkitemUris");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    artifactUri53, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetReferencingWorkitemUris")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader54 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader54 = toOM(requestHeader54,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetReferencingWorkitemUris")));
                addHeader(omElementrequestHeader54, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetReferencingWorkitemUrisResponseGetReferencingWorkitemUrisResult((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetWorkItem
     * @param getWorkItem57
     * @param requestHeader64
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(
        int workItemId58, int revisionId59, int minimumRevisionId60,
        java.util.Calendar asOfDate61, boolean useMaster62,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave63,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader64)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[3].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetWorkItem");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    workItemId58, revisionId59, minimumRevisionId60,
                    asOfDate61, useMaster62, metadataHave63, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetWorkItem")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader64 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader64 = toOM(requestHeader64,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetWorkItem")));
                addHeader(omElementrequestHeader64, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#QueryWorkitems
     * @param queryWorkitems66
     * @param requestHeader71
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 psQuery67,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfQuerySortOrderEntry sort68,
        boolean useMaster69,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave70,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader71)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[4].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitems");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    psQuery67, sort68, useMaster69, metadataHave70,
                    dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "QueryWorkitems")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader71 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader71 = toOM(requestHeader71,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "QueryWorkitems")));
                addHeader(omElementrequestHeader71, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#PageWorkitemsByIds
     * @param pageWorkitemsByIds73
     * @param requestHeader80
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids74,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns75,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns76,
        java.util.Calendar asOfDate77, boolean useMaster78,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave79,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader80)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[5].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageWorkitemsByIds");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    ids74, columns75, longTextColumns76, asOfDate77,
                    useMaster78, metadataHave79, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "PageWorkitemsByIds")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader80 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader80 = toOM(requestHeader80,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "PageWorkitemsByIds")));
                addHeader(omElementrequestHeader80, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#PageWorkitemsByIdRevs
     * @param pageWorkitemsByIdRevs82
     * @param requestHeader88
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair pairs83,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns84,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns85,
        java.util.Calendar asOfDate86, boolean useMaster87,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader88)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[6].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageWorkitemsByIdRevs");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    pairs83, columns84, longTextColumns85, asOfDate86,
                    useMaster87, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "PageWorkitemsByIdRevs")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader88 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader88 = toOM(requestHeader88,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "PageWorkitemsByIdRevs")));
                addHeader(omElementrequestHeader88, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#PageItemsOnBehalfOf
     * @param pageItemsOnBehalfOf90
     * @param requestHeader94
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 PageItemsOnBehalfOf(
        java.lang.String userName91,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids92,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns93,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader94)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[7].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageItemsOnBehalfOf");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    userName91, ids92, columns93, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "PageItemsOnBehalfOf")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader94 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader94 = toOM(requestHeader94,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "PageItemsOnBehalfOf")));
                addHeader(omElementrequestHeader94, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getPageItemsOnBehalfOfResponseItems((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#QueryWorkitemCount
     * @param queryWorkitemCount97
     * @param requestHeader101
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 psQuery98,
        boolean useMaster99,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave100,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader101)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[8].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitemCount");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    psQuery98, useMaster99, metadataHave100, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "QueryWorkitemCount")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader101 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader101 = toOM(requestHeader101,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "QueryWorkitemCount")));
                addHeader(omElementrequestHeader101, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#QueryWorkitemCountOnBehalfOf
     * @param queryWorkitemCountOnBehalfOf103
     * @param requestHeader106
     */
    public int QueryWorkitemCountOnBehalfOf(java.lang.String userName104,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 query105,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader106)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[9].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitemCountOnBehalfOf");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    userName104, query105, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "QueryWorkitemCountOnBehalfOf")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader106 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader106 = toOM(requestHeader106,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "QueryWorkitemCountOnBehalfOf")));
                addHeader(omElementrequestHeader106, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getQueryWorkitemCountOnBehalfOfResponseCount((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetMetadata
     * @param getMetadata109
     * @param requestHeader112
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave110,
        boolean useMaster111,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader112)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[10].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadata");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    metadataHave110, useMaster111, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetMetadata")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader112 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader112 = toOM(requestHeader112,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetMetadata")));
                addHeader(omElementrequestHeader112, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetMetadataEx
     * @param getMetadataEx114
     * @param requestHeader117
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave115,
        boolean useMaster116,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader117)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[11].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadataEx");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    metadataHave115, useMaster116, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetMetadataEx")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader117 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader117 = toOM(requestHeader117,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetMetadataEx")));
                addHeader(omElementrequestHeader117, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetMetadataEx2
     * @param getMetadataEx2119
     * @param requestHeader122
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave120,
        boolean useMaster121,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader122)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[12].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadataEx2");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    metadataHave120, useMaster121, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetMetadataEx2")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader122 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader122 = toOM(requestHeader122,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetMetadataEx2")));
                addHeader(omElementrequestHeader122, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#Update
     * @param update124
     * @param requestHeader127
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 _package125,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave126,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader127)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[13].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/Update");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    _package125, metadataHave126, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "Update")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader127 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader127 = toOM(requestHeader127,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "Update")));
                addHeader(omElementrequestHeader127, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#BulkUpdate
     * @param bulkUpdate129
     * @param requestHeader132
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 _package130,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave131,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader132)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[14].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/BulkUpdate");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    _package130, metadataHave131, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "BulkUpdate")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader132 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader132 = toOM(requestHeader132,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "BulkUpdate")));
                addHeader(omElementrequestHeader132, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetStoredQuery
     * @param getStoredQuery134
     * @param requestHeader136
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 GetStoredQuery(
        com.microsoft.wsdl.types.Guid queryId135,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader136)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[15].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQuery");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    queryId135, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetStoredQuery")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader136 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader136 = toOM(requestHeader136,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetStoredQuery")));
                addHeader(omElementrequestHeader136, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetStoredQueryResponseQueryPayload((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#GetStoredQueries
     * @param getStoredQueries139
     * @param requestHeader142
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 GetStoredQueries(
        long rowVersion140, int projectId141,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader142)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[16].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQueries");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    rowVersion140, projectId141, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "GetStoredQueries")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader142 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader142 = toOM(requestHeader142,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "GetStoredQueries")));
                addHeader(omElementrequestHeader142, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetStoredQueriesResponseQueriesPayload((org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#SyncExternalStructures
     * @param syncExternalStructures145
     * @param requestHeader147
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(
        java.lang.String projectURI146,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader147)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[17].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncExternalStructures");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectURI146, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "SyncExternalStructures")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader147 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader147 = toOM(requestHeader147,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "SyncExternalStructures")));
                addHeader(omElementrequestHeader147, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#SyncAccessControlLists
     * @param syncAccessControlLists149
     * @param requestHeader151
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(
        java.lang.String projectURI150,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader151)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[18].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncAccessControlLists");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectURI150, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "SyncAccessControlLists")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader151 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader151 = toOM(requestHeader151,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "SyncAccessControlLists")));
                addHeader(omElementrequestHeader151, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#SyncBisGroupsAndUsers
     * @param syncBisGroupsAndUsers153
     * @param requestHeader155
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(
        java.lang.String projectUri154,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader155)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[19].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncBisGroupsAndUsers");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri154, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "SyncBisGroupsAndUsers")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader155 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader155 = toOM(requestHeader155,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "SyncBisGroupsAndUsers")));
                addHeader(omElementrequestHeader155, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClientServiceClientServiceSoap#RequestCancel
     * @param requestCancel157
     * @param requestHeader159
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(
        java.lang.String requestIdToCancel158,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader159)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[20].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/RequestCancel");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    requestIdToCancel158, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                            "RequestCancel")));

            env.build();

            // add the children only if the parameter is not null
            if (requestHeader159 != null) {
                org.apache.axiom.om.OMElement omElementrequestHeader159 = toOM(requestHeader159,
                        optimizeContent(
                            new javax.xml.namespace.QName(
                                "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                "RequestCancel")));
                addHeader(omElementrequestHeader159, env);
            }

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     *  A utility method that copies the namepaces from the SOAPEnvelope
     */
    private java.util.Map getEnvelopeNamespaces(
        org.apache.axiom.soap.SOAPEnvelope env) {
        java.util.Map returnMap = new java.util.HashMap();
        java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();

        while (namespaceIterator.hasNext()) {
            org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator.next();
            returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
        }

        return returnMap;
    }

    private boolean optimizeContent(javax.xml.namespace.QName opName) {
        if (opNameArray == null) {
            return false;
        }

        for (int i = 0; i < opNameArray.length; i++) {
            if (opName.equals(opNameArray[i])) {
                return true;
            }
        }

        return false;
    }

    //http://wmw-2003-01:8080/WorkItemTracking/v1.0/ClientService.asmx
    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, int param1, int param2,
        int param3, java.util.Calendar param4, boolean param5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param6,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem();

            wrappedType.setWorkItemId(param1);

            wrappedType.setRevisionId(param2);

            wrappedType.setMinimumRevisionId(param3);

            wrappedType.setAsOfDate(param4);

            wrappedType.setUseMaster(param5);

            wrappedType.setMetadataHave(param6);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf();

            wrappedType.setUserName(param1);

            wrappedType.setQuery(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private int getQueryWorkitemCountOnBehalfOfResponseCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse wrappedType) {
        return wrappedType.getCount();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx();

            wrappedType.setMetadataHave(param1);

            wrappedType.setUseMaster(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfQuerySortOrderEntry param2,
        boolean param3,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param4,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems();

            wrappedType.setPsQuery(param1);

            wrappedType.setSort(param2);

            wrappedType.setUseMaster(param3);

            wrappedType.setMetadataHave(param4);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, long param1, int param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries();

            wrappedType.setRowVersion(param1);

            wrappedType.setProjectId(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 getGetStoredQueriesResponseQueriesPayload(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse wrappedType) {
        return wrappedType.getQueriesPayload();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists();

            wrappedType.setProjectURI(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param3,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount();

            wrappedType.setPsQuery(param1);

            wrappedType.setUseMaster(param2);

            wrappedType.setMetadataHave(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata();

            wrappedType.setMetadataHave(param1);

            wrappedType.setUseMaster(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString param3,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf();

            wrappedType.setUserName(param1);

            wrappedType.setIds(param2);

            wrappedType.setColumns(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 getPageItemsOnBehalfOfResponseItems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse wrappedType) {
        return wrappedType.getItems();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2();

            wrappedType.setMetadataHave(param1);

            wrappedType.setUseMaster(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures();

            wrappedType.setProjectURI(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel();

            wrappedType.setRequestIdToCancel(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate();

            wrappedType.set_package(param1);

            wrappedType.setMetadataHave(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param3,
        java.util.Calendar param4, boolean param5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param6,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds();

            wrappedType.setIds(param1);

            wrappedType.setColumns(param2);

            wrappedType.setLongTextColumns(param3);

            wrappedType.setAsOfDate(param4);

            wrappedType.setUseMaster(param5);

            wrappedType.setMetadataHave(param6);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris();

            wrappedType.setArtifactUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString getGetReferencingWorkitemUrisResponseGetReferencingWorkitemUrisResult(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse wrappedType) {
        return wrappedType.getGetReferencingWorkitemUrisResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt param3,
        java.util.Calendar param4, boolean param5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs();

            wrappedType.setPairs(param1);

            wrappedType.setColumns(param2);

            wrappedType.setLongTextColumns(param3);

            wrappedType.setAsOfDate(param4);

            wrappedType.setUseMaster(param5);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry param2,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update();

            wrappedType.set_package(param1);

            wrappedType.setMetadataHave(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private java.lang.String getGetWorkitemTrackingVersionResponseGetWorkitemTrackingVersionResult(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse wrappedType) {
        return wrappedType.getGetWorkitemTrackingVersionResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        com.microsoft.wsdl.types.Guid param1,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery wrappedType =
                new org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery();

            wrappedType.setQueryId(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 getGetStoredQueryResponseQueryPayload(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse wrappedType) {
        return wrappedType.getQueryPayload();
    }

    /**
     *  get the default envelope
     */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory) {
        return factory.getDefaultEnvelope();
    }

    private java.lang.Object fromOM(org.apache.axiom.om.OMElement param,
        java.lang.Class type, java.util.Map extraNamespaces)
        throws org.apache.axis2.AxisFault {
        try {
            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

        return null;
    }
}
