/**
 * RepositoryRepositorySoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  RepositorySoap java interface
 */
public interface RepositorySoap {
    /**
     * Auto generated method signature
     * @param addConflict
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflictResponse AddConflict(
        java.lang.String workspaceName, java.lang.String ownerName,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType conflictType,
        int itemId, int versionFrom, int pendingChangeId,
        java.lang.String sourceLocalItem, java.lang.String targetLocalItem,
        int reason) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkAuthentication
     */
    public java.lang.String CheckAuthentication(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthentication checkAuthentication)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkIn
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckInResponse CheckIn(
        java.lang.String workspaceName0, java.lang.String ownerName1,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset info,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNotificationInfo checkinNotificationInfo,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinOptions checkinOptions)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkPendingChanges
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure CheckPendingChanges(
        java.lang.String workspaceName2, java.lang.String ownerName3,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems4)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createAnnotation
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotationResponse CreateAnnotation(
        java.lang.String annotationName, java.lang.String annotatedItem,
        int version, java.lang.String annotationValue,
        java.lang.String comment, boolean overwrite)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createCheckinNoteDefinition
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinitionResponse CreateCheckinNoteDefinition(
        java.lang.String associatedServerItem,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition checkinNoteFields)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createWorkspace
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace CreateWorkspace(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace workspace)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteAnnotation
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotationResponse DeleteAnnotation(
        java.lang.String annotationName5, java.lang.String annotatedItem6,
        int version7, java.lang.String annotationValue8)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteLabel
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelResult DeleteLabel(
        java.lang.String labelName, java.lang.String labelScope)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteShelveset
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelvesetResponse DeleteShelveset(
        java.lang.String shelvesetName, java.lang.String ownerName9)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteWorkspace
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspaceResponse DeleteWorkspace(
        java.lang.String workspaceName10, java.lang.String ownerName11)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param get
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfGetOperation Get(
        java.lang.String workspaceName12, java.lang.String ownerName13,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfGetRequest requests,
        boolean force, boolean noGet) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getRepositoryProperties
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RepositoryProperties GetRepositoryProperties(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryProperties getRepositoryProperties)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param labelItem
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItemResponse LabelItem(
        java.lang.String workspaceName14, java.lang.String workspaceOwner,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionControlLabel label,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelItemSpec labelSpecs,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelChildOption children)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param merge
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeResponse Merge(
        java.lang.String workspaceName15, java.lang.String workspaceOwner16,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec from,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec to,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeOptions options,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel lockLevel)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pendChanges
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChangesResponse PendChanges(
        java.lang.String workspaceName17, java.lang.String ownerName18,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeRequest changes)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryAnnotation
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfAnnotation QueryAnnotation(
        java.lang.String annotationName19, java.lang.String annotatedItem20,
        int version21) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryBranches
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfBranchRelative QueryBranches(
        java.lang.String workspaceName22, java.lang.String workspaceOwner23,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version24)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryChangeset
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset QueryChangeset(
        int changesetId, boolean includeChanges, boolean generateDownloadUrls)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryCheckinNoteDefinition
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition QueryCheckinNoteDefinition(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString associatedServerItem25)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryCheckinNoteFieldNames
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryCheckinNoteFieldNames(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNames queryCheckinNoteFieldNames)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryConflicts
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfConflict QueryConflicts(
        java.lang.String workspaceName26, java.lang.String ownerName27,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items28)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryEffectiveGlobalPermissions
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryEffectiveGlobalPermissions(
        java.lang.String identityName) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryEffectiveItemPermissions
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryEffectiveItemPermissions(
        java.lang.String workspaceName29, java.lang.String workspaceOwner30,
        java.lang.String item, java.lang.String identityName31)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryFileTypes
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType QueryFileTypes(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypes queryFileTypes)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryGlobalPermissions
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GlobalSecurity QueryGlobalPermissions(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString identityNames)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryHistory
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeset QueryHistory(
        java.lang.String workspaceName32, java.lang.String workspaceOwner33,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec itemSpec,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionItem,
        java.lang.String user,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom34,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo,
        int maxCount, boolean includeFiles, boolean generateDownloadUrls35,
        boolean slotMode) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItems
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSet QueryItems(
        java.lang.String workspaceName36, java.lang.String workspaceOwner37,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items38,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version39,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState deletedState,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType itemType,
        boolean generateDownloadUrls40) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemsExtended
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfExtendedItem QueryItemsExtended(
        java.lang.String workspaceName41, java.lang.String workspaceOwner42,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items43,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState deletedState44,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType itemType45)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemPermissions
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissionsResponse QueryItemPermissions(
        java.lang.String workspaceName46, java.lang.String workspaceOwner47,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString identityNames48)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryLabels
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfVersionControlLabel QueryLabels(
        java.lang.String workspaceName49, java.lang.String workspaceOwner50,
        java.lang.String labelName51, java.lang.String labelScope52,
        java.lang.String owner, java.lang.String filterItem,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFilterItem,
        boolean includeItems, boolean generateDownloadUrls53)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMergeCandidates
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfMergeCandidate QueryMergeCandidates(
        java.lang.String workspaceName54, java.lang.String workspaceOwner55,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source56,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target57)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMerges
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesResponse QueryMerges(
        java.lang.String workspaceName58, java.lang.String workspaceOwner59,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source60,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionSource,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target61,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTarget,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom62,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo63,
        int maxChangesets) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryPendingSets
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSetsResponse QueryPendingSets(
        java.lang.String localWorkspaceName,
        java.lang.String localWorkspaceOwner,
        java.lang.String queryWorkspaceName, java.lang.String ownerName64,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs65,
        boolean generateDownloadUrls66) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryShelvedChanges
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChangesResponse QueryShelvedChanges(
        java.lang.String localWorkspaceName67,
        java.lang.String localWorkspaceOwner68,
        java.lang.String shelvesetName69, java.lang.String ownerName70,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs71,
        boolean generateDownloadUrls72) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryShelvesets
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfShelveset QueryShelvesets(
        java.lang.String shelvesetName73, java.lang.String ownerName74)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkspace
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace QueryWorkspace(
        java.lang.String workspaceName75, java.lang.String ownerName76)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkspaces
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWorkspace QueryWorkspaces(
        java.lang.String ownerName77, java.lang.String computer)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param refreshIdentityDisplayName
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayNameResponse RefreshIdentityDisplayName(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayName refreshIdentityDisplayName)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param removeLocalConflict
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflictResponse RemoveLocalConflict(
        java.lang.String workspaceName78, java.lang.String ownerName79,
        int conflictId) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param resolve
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ResolveResponse Resolve(
        java.lang.String workspaceName80, java.lang.String ownerName81,
        int conflictId82,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution resolution,
        java.lang.String newPath, int encoding,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel lockLevel83)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param setFileTypes
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypesResponse SetFileTypes(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType fileTypes)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param shelve
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure Shelve(
        java.lang.String workspaceName84, java.lang.String workspaceOwner85,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems86,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Shelveset shelveset,
        boolean replace) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param undoPendingChanges
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChangesResponse UndoPendingChanges(
        java.lang.String workspaceName87, java.lang.String ownerName88,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items89)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param unlabelItem
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItemResponse UnlabelItem(
        java.lang.String workspaceName90, java.lang.String workspaceOwner91,
        java.lang.String labelName92, java.lang.String labelScope93,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items94,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version95)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param unshelve
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnshelveResponse Unshelve(
        java.lang.String shelvesetName96, java.lang.String shelvesetOwner,
        java.lang.String workspaceName97, java.lang.String workspaceOwner98,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items99)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateChangeset
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangesetResponse UpdateChangeset(
        int changeset, java.lang.String comment100,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote checkinNote)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateCheckinNoteFieldName
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldNameResponse UpdateCheckinNoteFieldName(
        java.lang.String path, java.lang.String existingFieldName,
        java.lang.String newFieldName) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateGlobalSecurity
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurityResponse UpdateGlobalSecurity(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPermissionChange changes101)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateItemSecurity
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurityResponse UpdateItemSecurity(
        java.lang.String workspaceName102, java.lang.String workspaceOwner103,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfSecurityChange changes104)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateLocalVersion
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersionResponse UpdateLocalVersion(
        java.lang.String workspaceName105, java.lang.String ownerName106,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLocalVersionUpdate updates)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updatePendingState
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingStateResponse UpdatePendingState(
        java.lang.String workspaceName107, java.lang.String workspaceOwner108,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingState updates109)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateWorkspace
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace UpdateWorkspace(
        java.lang.String oldWorkspaceName, java.lang.String ownerName110,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace newWorkspace)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryPendingChangesById
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingChange QueryPendingChangesById(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt pendingChangeIds,
        boolean generateDownloadUrls111) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemsById
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItem QueryItemsById(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt itemIds,
        int changeSet, boolean generateDownloadUrls112)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createTeamProjectFolder
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolderResponse CreateTeamProjectFolder(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.TeamProjectFolderOptions teamProjectOptions)
        throws java.rmi.RemoteException;

    //
}
