package org.jetbrains.tfsIntegration.stubs.org.jetbrains.tfsIntegration.stubs.exceptions;


public abstract class TfsException extends Exception {

	private static final long serialVersionUID = 1L;

	public TfsException(final Throwable cause) {
		super(cause.getMessage(), cause);
	}

	public TfsException() {
		super();
	}
	
}
