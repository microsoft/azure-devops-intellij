package org.jetbrains.tfsIntegration.stubs.org.jetbrains.tfsIntegration.stubs.exceptions;

import org.apache.axis2.AxisFault;

public class UnauthorizedException extends TfsException {

	private static final long serialVersionUID = 1L;

	public UnauthorizedException(AxisFault cause) {
		super(cause);
	}

}
