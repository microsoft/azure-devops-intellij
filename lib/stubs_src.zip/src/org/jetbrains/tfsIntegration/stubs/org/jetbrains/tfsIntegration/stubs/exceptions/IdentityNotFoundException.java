package org.jetbrains.tfsIntegration.stubs.org.jetbrains.tfsIntegration.stubs.exceptions;

import javax.xml.namespace.QName;

import org.apache.axis2.AxisFault;

public class IdentityNotFoundException extends TfsException {

	private static final long serialVersionUID = 1L;

	public static final String CODE = "IdentityNotFoundException";

	private final String myIdentityName;

	public IdentityNotFoundException(AxisFault cause) {
		super(cause);
		if (cause.getDetail() != null) {
			myIdentityName = cause.getDetail().getAttributeValue(new QName("IdentityName"));
		} else {
			myIdentityName = null;
		}
	}
	
	public String getIdentityName() {
		return myIdentityName;
	}

}
