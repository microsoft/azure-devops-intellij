/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice;


/**
 *  ExtensionMapper class
 */
public class ExtensionMapper {
    public static java.lang.Object getTypeObject(
        java.lang.String namespaceURI, java.lang.String typeName,
        javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) &&
                "ApplicationGroupProperty".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupProperty.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) && "QueryMembership".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.QueryMembership.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) && "ArrayOfString".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) &&
                "ApplicationGroupSpecialType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupSpecialType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) && "Identity".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.Identity.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03".equals(
                    namespaceURI) && "ArrayOfIdentity".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ArrayOfIdentity.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) && "SearchFactor".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03".equals(
                    namespaceURI) && "IdentityType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.authorization.IdentityType.Factory.parse(reader);
        }

        throw new org.apache.axis2.databinding.ADBException("Unsupported type " +
            namespaceURI + " " + typeName);
    }
}
