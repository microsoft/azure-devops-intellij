/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.services.serverstatus;


/**
 *  ExtensionMapper class
 */
public class ExtensionMapper {
    public static java.lang.Object getTypeObject(
        java.lang.String namespaceURI, java.lang.String typeName,
        javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/ServerStatus/03".equals(
                    namespaceURI) && "DataChanged".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.serverstatus.DataChanged.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/ServerStatus/03".equals(
                    namespaceURI) && "ArrayOfDataChanged".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.serverstatus.ArrayOfDataChanged.Factory.parse(reader);
        }

        throw new org.apache.axis2.databinding.ADBException("Unsupported type " +
            namespaceURI + " " + typeName);
    }
}
