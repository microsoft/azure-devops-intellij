/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.services.commonstructureservice;


/**
 *  ExtensionMapper class
 */
public class ExtensionMapper {
    public static java.lang.Object getTypeObject(
        java.lang.String namespaceURI, java.lang.String typeName,
        javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "NodeInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "structure_type0".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.Structure_type0.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) &&
                "GetNodesXmlResult_type0".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResult_type0.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ProjectInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) &&
                "GetDeletedNodesXmlResult_type0".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResult_type0.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ArrayOfProjectInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ArrayOfString".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ProjectState".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectState.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ArrayOfProperty".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProperty.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "Property".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.Property.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ArrayOfProjectProperty".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectProperty.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ProjectProperty".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectProperty.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(
                    namespaceURI) && "ArrayOfNodeInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfNodeInfo.Factory.parse(reader);
        }

        throw new org.apache.axis2.databinding.ADBException("Unsupported type " +
            namespaceURI + " " + typeName);
    }
}
