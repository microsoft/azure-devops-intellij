/**
 * Identity.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.services.authorization;


/**
 *  Identity bean class
 */
public class Identity implements org.apache.axis2.databinding.ADBBean {
    /**
     * field for Type
     */
    protected org.jetbrains.tfsIntegration.stubs.services.authorization.IdentityType localType;

    /**
     * field for Sid
     */
    protected java.lang.String localSid;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSidTracker = false;

    /**
     * field for DisplayName
     */
    protected java.lang.String localDisplayName;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDisplayNameTracker = false;

    /**
     * field for Description
     */
    protected java.lang.String localDescription;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDescriptionTracker = false;

    /**
     * field for Domain
     */
    protected java.lang.String localDomain;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDomainTracker = false;

    /**
     * field for AccountName
     */
    protected java.lang.String localAccountName;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAccountNameTracker = false;

    /**
     * field for DistinguishedName
     */
    protected java.lang.String localDistinguishedName;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDistinguishedNameTracker = false;

    /**
     * field for MailAddress
     */
    protected java.lang.String localMailAddress;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMailAddressTracker = false;

    /**
     * field for SpecialType
     */
    protected org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupSpecialType localSpecialType;

    /**
     * field for Deleted
     */
    protected boolean localDeleted;

    /**
     * field for Members
     */
    protected org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString localMembers;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMembersTracker = false;

    /**
     * field for MemberOf
     */
    protected org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString localMemberOf;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMemberOfTracker = false;

    /**
     * field for SecurityGroup
     */
    protected boolean localSecurityGroup;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSecurityGroupTracker = false;

    /* This type was generated from the piece of schema that had
       name = Identity
       Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03
       Namespace Prefix =
     */
    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03")) {
            return "";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.services.authorization.IdentityType
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.IdentityType getType() {
        return localType;
    }

    /**
     * Auto generated setter method
     * @param param Type
     */
    public void setType(
        org.jetbrains.tfsIntegration.stubs.services.authorization.IdentityType param) {
        this.localType = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getSid() {
        return localSid;
    }

    /**
     * Auto generated setter method
     * @param param Sid
     */
    public void setSid(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localSidTracker = true;
        } else {
            localSidTracker = false;
        }

        this.localSid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getDisplayName() {
        return localDisplayName;
    }

    /**
     * Auto generated setter method
     * @param param DisplayName
     */
    public void setDisplayName(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localDisplayNameTracker = true;
        } else {
            localDisplayNameTracker = false;
        }

        this.localDisplayName = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getDescription() {
        return localDescription;
    }

    /**
     * Auto generated setter method
     * @param param Description
     */
    public void setDescription(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localDescriptionTracker = true;
        } else {
            localDescriptionTracker = false;
        }

        this.localDescription = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getDomain() {
        return localDomain;
    }

    /**
     * Auto generated setter method
     * @param param Domain
     */
    public void setDomain(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localDomainTracker = true;
        } else {
            localDomainTracker = false;
        }

        this.localDomain = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getAccountName() {
        return localAccountName;
    }

    /**
     * Auto generated setter method
     * @param param AccountName
     */
    public void setAccountName(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localAccountNameTracker = true;
        } else {
            localAccountNameTracker = false;
        }

        this.localAccountName = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getDistinguishedName() {
        return localDistinguishedName;
    }

    /**
     * Auto generated setter method
     * @param param DistinguishedName
     */
    public void setDistinguishedName(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localDistinguishedNameTracker = true;
        } else {
            localDistinguishedNameTracker = false;
        }

        this.localDistinguishedName = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getMailAddress() {
        return localMailAddress;
    }

    /**
     * Auto generated setter method
     * @param param MailAddress
     */
    public void setMailAddress(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localMailAddressTracker = true;
        } else {
            localMailAddressTracker = false;
        }

        this.localMailAddress = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupSpecialType
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupSpecialType getSpecialType() {
        return localSpecialType;
    }

    /**
     * Auto generated setter method
     * @param param SpecialType
     */
    public void setSpecialType(
        org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupSpecialType param) {
        this.localSpecialType = param;
    }

    /**
     * Auto generated getter method
     * @return boolean
     */
    public boolean getDeleted() {
        return localDeleted;
    }

    /**
     * Auto generated setter method
     * @param param Deleted
     */
    public void setDeleted(boolean param) {
        this.localDeleted = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString getMembers() {
        return localMembers;
    }

    /**
     * Auto generated setter method
     * @param param Members
     */
    public void setMembers(
        org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString param) {
        if (param != null) {
            //update the setting tracker
            localMembersTracker = true;
        } else {
            localMembersTracker = false;
        }

        this.localMembers = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString getMemberOf() {
        return localMemberOf;
    }

    /**
     * Auto generated setter method
     * @param param MemberOf
     */
    public void setMemberOf(
        org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString param) {
        if (param != null) {
            //update the setting tracker
            localMemberOfTracker = true;
        } else {
            localMemberOfTracker = false;
        }

        this.localMemberOf = param;
    }

    /**
     * Auto generated getter method
     * @return boolean
     */
    public boolean getSecurityGroup() {
        return localSecurityGroup;
    }

    /**
     * Auto generated setter method
     * @param param SecurityGroup
     */
    public void setSecurityGroup(boolean param) {
        // setting primitive attribute tracker to true
        if (false) {
            localSecurityGroupTracker = false;
        } else {
            localSecurityGroupTracker = true;
        }

        this.localSecurityGroup = param;
    }

    /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
    public static boolean isReaderMTOMAware(
        javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;

        try {
            isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(
                        org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        } catch (java.lang.IllegalArgumentException e) {
            isReaderMTOMAware = false;
        }

        return isReaderMTOMAware;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        org.apache.axiom.om.OMDataSource dataSource = new org.apache.axis2.databinding.ADBDataSource(this,
                parentQName) {
                public void serialize(
                    org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                    throws javax.xml.stream.XMLStreamException {
                    Identity.this.serialize(parentQName, factory, xmlWriter);
                }
            };

        return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(parentQName,
            factory, dataSource);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory,
        org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();

        if (namespace != null) {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace,
                    parentQName.getLocalPart());
            } else {
                if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(),
                    namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        } else {
            xmlWriter.writeStartElement(parentQName.getLocalPart());
        }

        if (localType == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "Type cannot be null!!");
        }

        localType.serialize(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                "Type"), factory, xmlWriter);

        if (localSidTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "Sid", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "Sid");
                }
            } else {
                xmlWriter.writeStartElement("Sid");
            }

            if (localSid == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "Sid cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localSid);
            }

            xmlWriter.writeEndElement();
        }

        if (localDisplayNameTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "DisplayName", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "DisplayName");
                }
            } else {
                xmlWriter.writeStartElement("DisplayName");
            }

            if (localDisplayName == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "DisplayName cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localDisplayName);
            }

            xmlWriter.writeEndElement();
        }

        if (localDescriptionTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "Description", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "Description");
                }
            } else {
                xmlWriter.writeStartElement("Description");
            }

            if (localDescription == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "Description cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localDescription);
            }

            xmlWriter.writeEndElement();
        }

        if (localDomainTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "Domain", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "Domain");
                }
            } else {
                xmlWriter.writeStartElement("Domain");
            }

            if (localDomain == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "Domain cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localDomain);
            }

            xmlWriter.writeEndElement();
        }

        if (localAccountNameTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "AccountName", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "AccountName");
                }
            } else {
                xmlWriter.writeStartElement("AccountName");
            }

            if (localAccountName == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "AccountName cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localAccountName);
            }

            xmlWriter.writeEndElement();
        }

        if (localDistinguishedNameTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "DistinguishedName",
                        namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "DistinguishedName");
                }
            } else {
                xmlWriter.writeStartElement("DistinguishedName");
            }

            if (localDistinguishedName == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "DistinguishedName cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localDistinguishedName);
            }

            xmlWriter.writeEndElement();
        }

        if (localMailAddressTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "MailAddress", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "MailAddress");
                }
            } else {
                xmlWriter.writeStartElement("MailAddress");
            }

            if (localMailAddress == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "MailAddress cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localMailAddress);
            }

            xmlWriter.writeEndElement();
        }

        if (localSpecialType == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "SpecialType cannot be null!!");
        }

        localSpecialType.serialize(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                "SpecialType"), factory, xmlWriter);

        namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

        if (!namespace.equals("")) {
            prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null) {
                prefix = generatePrefix(namespace);

                xmlWriter.writeStartElement(prefix, "Deleted", namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            } else {
                xmlWriter.writeStartElement(namespace, "Deleted");
            }
        } else {
            xmlWriter.writeStartElement("Deleted");
        }

        if (false) {
            throw new org.apache.axis2.databinding.ADBException(
                "Deleted cannot be null!!");
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localDeleted));
        }

        xmlWriter.writeEndElement();

        if (localMembersTracker) {
            if (localMembers == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Members cannot be null!!");
            }

            localMembers.serialize(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "Members"), factory, xmlWriter);
        }

        if (localMemberOfTracker) {
            if (localMemberOf == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MemberOf cannot be null!!");
            }

            localMemberOf.serialize(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "MemberOf"), factory, xmlWriter);
        }

        if (localSecurityGroupTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "SecurityGroup",
                        namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "SecurityGroup");
                }
            } else {
                xmlWriter.writeStartElement("SecurityGroup");
            }

            if (false) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SecurityGroup cannot be null!!");
            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localSecurityGroup));
            }

            xmlWriter.writeEndElement();
        }

        xmlWriter.writeEndElement();
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     * databinding method to get an XML representation of this object
     *
     */
    public javax.xml.stream.XMLStreamReader getPullParser(
        javax.xml.namespace.QName qName)
        throws org.apache.axis2.databinding.ADBException {
        java.util.ArrayList elementList = new java.util.ArrayList();
        java.util.ArrayList attribList = new java.util.ArrayList();

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                "Type"));

        if (localType == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "Type cannot be null!!");
        }

        elementList.add(localType);

        if (localSidTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "Sid"));

            if (localSid != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localSid));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "Sid cannot be null!!");
            }
        }

        if (localDisplayNameTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "DisplayName"));

            if (localDisplayName != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localDisplayName));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "DisplayName cannot be null!!");
            }
        }

        if (localDescriptionTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "Description"));

            if (localDescription != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localDescription));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "Description cannot be null!!");
            }
        }

        if (localDomainTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "Domain"));

            if (localDomain != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localDomain));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "Domain cannot be null!!");
            }
        }

        if (localAccountNameTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "AccountName"));

            if (localAccountName != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localAccountName));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "AccountName cannot be null!!");
            }
        }

        if (localDistinguishedNameTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "DistinguishedName"));

            if (localDistinguishedName != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localDistinguishedName));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "DistinguishedName cannot be null!!");
            }
        }

        if (localMailAddressTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "MailAddress"));

            if (localMailAddress != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localMailAddress));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "MailAddress cannot be null!!");
            }
        }

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                "SpecialType"));

        if (localSpecialType == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "SpecialType cannot be null!!");
        }

        elementList.add(localSpecialType);

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                "Deleted"));

        elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localDeleted));

        if (localMembersTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "Members"));

            if (localMembers == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Members cannot be null!!");
            }

            elementList.add(localMembers);
        }

        if (localMemberOfTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "MemberOf"));

            if (localMemberOf == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MemberOf cannot be null!!");
            }

            elementList.add(localMemberOf);
        }

        if (localSecurityGroupTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                    "SecurityGroup"));

            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localSecurityGroup));
        }

        return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
            elementList.toArray(), attribList.toArray());
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static Identity parse(javax.xml.stream.XMLStreamReader reader)
            throws java.lang.Exception {
            Identity object = new Identity();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"Identity".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (Identity) org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "Type").equals(reader.getName())) {
                    object.setType(org.jetbrains.tfsIntegration.stubs.services.authorization.IdentityType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "Sid").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setSid(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "DisplayName").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setDisplayName(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "Description").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setDescription(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "Domain").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setDomain(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "AccountName").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setAccountName(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "DistinguishedName").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setDistinguishedName(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "MailAddress").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setMailAddress(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "SpecialType").equals(reader.getName())) {
                    object.setSpecialType(org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupSpecialType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "Deleted").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setDeleted(org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "Members").equals(reader.getName())) {
                    object.setMembers(org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "MemberOf").equals(reader.getName())) {
                    object.setMemberOf(org.jetbrains.tfsIntegration.stubs.services.authorization.ArrayOfString.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Authorization/03",
                            "SecurityGroup").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setSecurityGroup(org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
