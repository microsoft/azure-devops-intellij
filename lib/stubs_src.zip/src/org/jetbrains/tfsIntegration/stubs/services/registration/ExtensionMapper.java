
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */

            package org.jetbrains.tfsIntegration.stubs.services.registration;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfArtifactType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfArtifactType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ServiceInterface".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ServiceInterface.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationExtendedAttribute".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.RegistrationExtendedAttribute.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationExtendedAttribute".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfRegistrationExtendedAttribute.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfDatabase".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfDatabase.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfEventType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfEventType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfServiceInterface".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfServiceInterface.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArtifactType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArtifactType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationEntry".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.RegistrationEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfOutboundLinkType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfOutboundLinkType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "Database".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.Database.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationEntry".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfRegistrationEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "EventType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.EventType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ChangeType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.ChangeType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "OutboundLinkType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.services.registration.OutboundLinkType.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    