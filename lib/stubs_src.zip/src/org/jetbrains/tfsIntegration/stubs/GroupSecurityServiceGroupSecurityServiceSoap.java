/**
 * GroupSecurityServiceGroupSecurityServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  GroupSecurityServiceGroupSecurityServiceSoap java interface
 */
public interface GroupSecurityServiceGroupSecurityServiceSoap {
    /**
     * Auto generated method signature
     * @param readIdentity113
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.Identity ReadIdentity(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor114,
        java.lang.String factorValue115,
        org.jetbrains.tfsIntegration.stubs.services.authorization.QueryMembership queryMembership116)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param readIdentityFromSource119
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.Identity ReadIdentityFromSource(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor120,
        java.lang.String factorValue121) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param isIdentityCached124
     */
    public boolean IsIdentityCached(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor125,
        java.lang.String factorValue126) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getChangedIdentities129
     */
    public java.lang.String GetChangedIdentities(int sequence_id130)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createApplicationGroup133
     */
    public java.lang.String CreateApplicationGroup(
        java.lang.String projectUri134, java.lang.String groupName135,
        java.lang.String groupDescription136) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listApplicationGroups139
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ArrayOfIdentity ListApplicationGroups(
        java.lang.String projectUri140) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateApplicationGroup143
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse UpdateApplicationGroup(
        java.lang.String groupSid144,
        org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupProperty property145,
        java.lang.String newValue146) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteApplicationGroup148
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse DeleteApplicationGroup(
        java.lang.String groupSid149) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param addMemberToApplicationGroup151
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse AddMemberToApplicationGroup(
        java.lang.String groupSid152, java.lang.String identitySid153)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param removeMemberFromApplicationGroup155
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse RemoveMemberFromApplicationGroup(
        java.lang.String groupSid156, java.lang.String identitySid157)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param isMember159
     */
    public boolean IsMember(java.lang.String groupSid160,
        java.lang.String identitySid161) throws java.rmi.RemoteException;

    //
}
