

/**
 * GroupSecurityServiceGroupSecurityServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  GroupSecurityServiceGroupSecurityServiceSoap java interface
     */

    public interface GroupSecurityServiceGroupSecurityServiceSoap {
          

        /**
          * Auto generated method signature
          * 
                    * @param createApplicationGroup44
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse CreateApplicationGroup(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup createApplicationGroup44)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getChangedIdentities46
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse GetChangedIdentities(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities getChangedIdentities46)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateApplicationGroup48
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse UpdateApplicationGroup(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup updateApplicationGroup48)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteApplicationGroup50
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse DeleteApplicationGroup(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup deleteApplicationGroup50)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeMemberFromApplicationGroup52
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse RemoveMemberFromApplicationGroup(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup removeMemberFromApplicationGroup52)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param addMemberToApplicationGroup54
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse AddMemberToApplicationGroup(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup addMemberToApplicationGroup54)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param readIdentity56
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse ReadIdentity(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity readIdentity56)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param readIdentityFromSource58
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse ReadIdentityFromSource(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource readIdentityFromSource58)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param isIdentityCached60
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse IsIdentityCached(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached isIdentityCached60)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param isMember62
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse IsMember(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember isMember62)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listApplicationGroups64
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse ListApplicationGroups(

                        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups listApplicationGroups64)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    