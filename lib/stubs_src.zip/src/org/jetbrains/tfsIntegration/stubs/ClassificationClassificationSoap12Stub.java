/**
 * ClassificationClassificationSoap12Stub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClassificationClassificationSoap12Stub java implementation
 */
public class ClassificationClassificationSoap12Stub extends org.apache.axis2.client.Stub
    implements ClassificationClassificationSoap12 {
    protected org.apache.axis2.description.AxisOperation[] _operations;

    //hashmaps to keep the fault mapping
    private java.util.HashMap faultExceptionNameMap = new java.util.HashMap();
    private java.util.HashMap faultExceptionClassNameMap = new java.util.HashMap();
    private java.util.HashMap faultMessageMap = new java.util.HashMap();
    private javax.xml.namespace.QName[] opNameArray = null;

    /**
     *Constructor that takes in a configContext
     */
    public ClassificationClassificationSoap12Stub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(configurationContext, targetEndpoint, false);
    }

    /**
     * Constructor that takes in a configContext  and useseperate listner
     */
    public ClassificationClassificationSoap12Stub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint, boolean useSeparateListener)
        throws org.apache.axis2.AxisFault {
        //To populate AxisService
        populateAxisService();
        populateFaults();

        _serviceClient = new org.apache.axis2.client.ServiceClient(configurationContext,
                _service);

        configurationContext = _serviceClient.getServiceContext()
                                             .getConfigurationContext();

        _serviceClient.getOptions()
                      .setTo(new org.apache.axis2.addressing.EndpointReference(
                targetEndpoint));
        _serviceClient.getOptions().setUseSeparateListener(useSeparateListener);

        //Set the soap version
        _serviceClient.getOptions()
                      .setSoapVersionURI(org.apache.axiom.soap.SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI);
    }

    /**
     * Default Constructor
     */
    public ClassificationClassificationSoap12Stub(
        org.apache.axis2.context.ConfigurationContext configurationContext)
        throws org.apache.axis2.AxisFault {
        this(configurationContext,
            "http://tfs-2005-01:8080/Services/v1.0/CommonStructureService.asmx");
    }

    /**
     * Default Constructor
     */
    public ClassificationClassificationSoap12Stub()
        throws org.apache.axis2.AxisFault {
        this(
            "http://tfs-2005-01:8080/Services/v1.0/CommonStructureService.asmx");
    }

    /**
     * Constructor taking the target endpoint
     */
    public ClassificationClassificationSoap12Stub(
        java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(null, targetEndpoint);
    }

    private void populateAxisService() throws org.apache.axis2.AxisFault {
        //creating the Service with a unique name
        _service = new org.apache.axis2.description.AxisService(
                "Classification" + this.hashCode());

        //creating the operations
        org.apache.axis2.description.AxisOperation __operation;

        _operations = new org.apache.axis2.description.AxisOperation[19];

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "CreateProject"));
        _service.addOperation(__operation);

        _operations[0] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "DeleteProject"));
        _service.addOperation(__operation);

        _operations[1] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetProjectProperties"));
        _service.addOperation(__operation);

        _operations[2] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "UpdateProjectProperties"));
        _service.addOperation(__operation);

        _operations[3] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetProject"));
        _service.addOperation(__operation);

        _operations[4] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetProjectFromName"));
        _service.addOperation(__operation);

        _operations[5] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "ListProjects"));
        _service.addOperation(__operation);

        _operations[6] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "ListAllProjects"));
        _service.addOperation(__operation);

        _operations[7] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "ListStructures"));
        _service.addOperation(__operation);

        _operations[8] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetNodesXml"));
        _service.addOperation(__operation);

        _operations[9] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "CreateNode"));
        _service.addOperation(__operation);

        _operations[10] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "RenameNode"));
        _service.addOperation(__operation);

        _operations[11] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "MoveBranch"));
        _service.addOperation(__operation);

        _operations[12] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "ReorderNode"));
        _service.addOperation(__operation);

        _operations[13] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "DeleteBranches"));
        _service.addOperation(__operation);

        _operations[14] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetDeletedNodesXml"));
        _service.addOperation(__operation);

        _operations[15] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetNode"));
        _service.addOperation(__operation);

        _operations[16] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetNodeFromPath"));
        _service.addOperation(__operation);

        _operations[17] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                "GetChangedNodes"));
        _service.addOperation(__operation);

        _operations[18] = __operation;
    }

    //populates the faults
    private void populateFaults() {
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#CreateProject
     * @param createProject10
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo CreateProject(
        java.lang.String projectName11,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.Structure_type0 structure12)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[0].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/CreateProject");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectName11, structure12, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "CreateProject")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getCreateProjectResponseCreateProjectResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#DeleteProject
     * @param deleteProject15
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse DeleteProject(
        java.lang.String projectUri16) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[1].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/DeleteProject");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri16, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "DeleteProject")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetProjectProperties
     * @param getProjectProperties18
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse GetProjectProperties(
        java.lang.String projectUri19) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[2].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetProjectProperties");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri19, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetProjectProperties")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#UpdateProjectProperties
     * @param updateProjectProperties21
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse UpdateProjectProperties(
        java.lang.String projectUri22, java.lang.String state23,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectProperty properties24)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[3].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/UpdateProjectProperties");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri22, state23, properties24, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "UpdateProjectProperties")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetProject
     * @param getProject26
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo GetProject(
        java.lang.String projectUri27) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[4].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetProject");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri27, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetProject")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetProjectResponseGetProjectResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetProjectFromName
     * @param getProjectFromName30
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo GetProjectFromName(
        java.lang.String projectName31) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[5].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetProjectFromName");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectName31, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetProjectFromName")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetProjectFromNameResponseGetProjectFromNameResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#ListProjects
     * @param listProjects34
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo ListProjects(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects listProjects34)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[6].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/ListProjects");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    listProjects34,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "ListProjects")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getListProjectsResponseListProjectsResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#ListAllProjects
     * @param listAllProjects37
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo ListAllProjects(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects listAllProjects37)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[7].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/ListAllProjects");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    listAllProjects37,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "ListAllProjects")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getListAllProjectsResponseListAllProjectsResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#ListStructures
     * @param listStructures40
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfNodeInfo ListStructures(
        java.lang.String projectUri41) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[8].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/ListStructures");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri41, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "ListStructures")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getListStructuresResponseListStructuresResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetNodesXml
     * @param getNodesXml44
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResult_type0 GetNodesXml(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString nodeUris45,
        boolean childNodes46) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[9].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetNodesXml");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeUris45, childNodes46, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetNodesXml")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetNodesXmlResponseGetNodesXmlResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#CreateNode
     * @param createNode49
     */
    public java.lang.String CreateNode(java.lang.String nodeName50,
        java.lang.String parentNodeUri51) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[10].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/CreateNode");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeName50, parentNodeUri51, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "CreateNode")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getCreateNodeResponseCreateNodeResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#RenameNode
     * @param renameNode54
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse RenameNode(
        java.lang.String nodeUri55, java.lang.String newNodeName56)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[11].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/RenameNode");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeUri55, newNodeName56, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "RenameNode")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#MoveBranch
     * @param moveBranch58
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse MoveBranch(
        java.lang.String nodeUri59, java.lang.String newParentNodeUri60)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[12].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/MoveBranch");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeUri59, newParentNodeUri60, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "MoveBranch")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#ReorderNode
     * @param reorderNode62
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse ReorderNode(
        java.lang.String nodeUri63, int moveBy64)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[13].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/ReorderNode");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeUri63, moveBy64, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "ReorderNode")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#DeleteBranches
     * @param deleteBranches66
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse DeleteBranches(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString nodeUris67,
        java.lang.String reclassifyUri68) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[14].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/DeleteBranches");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeUris67, reclassifyUri68, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "DeleteBranches")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetDeletedNodesXml
     * @param getDeletedNodesXml70
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResult_type0 GetDeletedNodesXml(
        java.lang.String projectUri71, java.util.Calendar since72)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[15].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetDeletedNodesXml");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri71, since72, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetDeletedNodesXml")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetDeletedNodesXmlResponseGetDeletedNodesXmlResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetNode
     * @param getNode75
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo GetNode(
        java.lang.String nodeUri76) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[16].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetNode");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodeUri76, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetNode")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetNodeResponseGetNodeResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetNodeFromPath
     * @param getNodeFromPath79
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo GetNodeFromPath(
        java.lang.String nodePath80) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[17].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetNodeFromPath");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    nodePath80, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetNodeFromPath")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetNodeFromPathResponseGetNodeFromPathResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.ClassificationClassificationSoap12#GetChangedNodes
     * @param getChangedNodes83
     */
    public java.lang.String GetChangedNodes(int firstSequenceId84)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[18].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03/GetChangedNodes");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    firstSequenceId84, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03",
                            "GetChangedNodes")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetChangedNodesResponseGetChangedNodesResult((org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     *  A utility method that copies the namepaces from the SOAPEnvelope
     */
    private java.util.Map getEnvelopeNamespaces(
        org.apache.axiom.soap.SOAPEnvelope env) {
        java.util.Map returnMap = new java.util.HashMap();
        java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();

        while (namespaceIterator.hasNext()) {
            org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator.next();
            returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
        }

        return returnMap;
    }

    private boolean optimizeContent(javax.xml.namespace.QName opName) {
        if (opNameArray == null) {
            return false;
        }

        for (int i = 0; i < opNameArray.length; i++) {
            if (opName.equals(opNameArray[i])) {
                return true;
            }
        }

        return false;
    }

    //http://tfs-2005-01:8080/Services/v1.0/CommonStructureService.asmx
    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath();

            wrappedType.setNodePath(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo getGetNodeFromPathResponseGetNodeFromPathResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse wrappedType) {
        return wrappedType.getGetNodeFromPathResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode();

            wrappedType.setNodeUri(param1);

            wrappedType.setNewNodeName(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode();

            wrappedType.setNodeUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo getGetNodeResponseGetNodeResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse wrappedType) {
        return wrappedType.getGetNodeResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.util.Calendar param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml();

            wrappedType.setProjectUri(param1);

            wrappedType.setSince(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResult_type0 getGetDeletedNodesXmlResponseGetDeletedNodesXmlResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse wrappedType) {
        return wrappedType.getGetDeletedNodesXmlResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectProperty param3,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties();

            wrappedType.setProjectUri(param1);

            wrappedType.setState(param2);

            wrappedType.setProperties(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo getListProjectsResponseListProjectsResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse wrappedType) {
        return wrappedType.getListProjectsResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo getListAllProjectsResponseListAllProjectsResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse wrappedType) {
        return wrappedType.getListAllProjectsResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.Structure_type0 param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject();

            wrappedType.setProjectName(param1);

            wrappedType.setStructure(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo getCreateProjectResponseCreateProjectResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse wrappedType) {
        return wrappedType.getCreateProjectResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode();

            wrappedType.setNodeName(param1);

            wrappedType.setParentNodeUri(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private java.lang.String getCreateNodeResponseCreateNodeResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse wrappedType) {
        return wrappedType.getCreateNodeResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch();

            wrappedType.setNodeUri(param1);

            wrappedType.setNewParentNodeUri(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches();

            wrappedType.setNodeUris(param1);

            wrappedType.setReclassifyUri(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName();

            wrappedType.setProjectName(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo getGetProjectFromNameResponseGetProjectFromNameResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse wrappedType) {
        return wrappedType.getGetProjectFromNameResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfNodeInfo getListStructuresResponseListStructuresResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse wrappedType) {
        return wrappedType.getListStructuresResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, int param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes();

            wrappedType.setFirstSequenceId(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private java.lang.String getGetChangedNodesResponseGetChangedNodesResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse wrappedType) {
        return wrappedType.getGetChangedNodesResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString param1,
        boolean param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml();

            wrappedType.setNodeUris(param1);

            wrappedType.setChildNodes(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResult_type0 getGetNodesXmlResponseGetNodesXmlResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse wrappedType) {
        return wrappedType.getGetNodesXmlResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        int param2,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode();

            wrappedType.setNodeUri(param1);

            wrappedType.setMoveBy(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo getGetProjectResponseGetProjectResult(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse wrappedType) {
        return wrappedType.getGetProjectResult();
    }

    /**
     *  get the default envelope
     */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory) {
        return factory.getDefaultEnvelope();
    }

    private java.lang.Object fromOM(org.apache.axiom.om.OMElement param,
        java.lang.Class type, java.util.Map extraNamespaces)
        throws org.apache.axis2.AxisFault {
        try {
            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

        return null;
    }
}
