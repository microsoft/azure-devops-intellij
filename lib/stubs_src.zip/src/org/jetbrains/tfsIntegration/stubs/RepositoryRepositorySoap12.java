/**
 * RepositoryRepositorySoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  RepositoryRepositorySoap12 java interface
 */
public interface RepositoryRepositorySoap12 {
    /**
     * Auto generated method signature
     * @param addConflict826
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflictResponse AddConflict(
        java.lang.String workspaceName827, java.lang.String ownerName828,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType conflictType829,
        int itemId830, int versionFrom831, int pendingChangeId832,
        java.lang.String sourceLocalItem833,
        java.lang.String targetLocalItem834, int reason835)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkAuthentication837
     */
    public java.lang.String CheckAuthentication(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthentication checkAuthentication837)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkIn840
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckInResponse CheckIn(
        java.lang.String workspaceName841, java.lang.String ownerName842,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems843,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset info844,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNotificationInfo checkinNotificationInfo845,
        java.lang.String checkinOptions846) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkPendingChanges848
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure CheckPendingChanges(
        java.lang.String workspaceName849, java.lang.String ownerName850,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems851)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createAnnotation854
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotationResponse CreateAnnotation(
        java.lang.String annotationName855, java.lang.String annotatedItem856,
        int version857, java.lang.String annotationValue858,
        java.lang.String comment859, boolean overwrite860)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createCheckinNoteDefinition862
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinitionResponse CreateCheckinNoteDefinition(
        java.lang.String associatedServerItem863,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition checkinNoteFields864)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createWorkspace866
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace CreateWorkspace(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace workspace867)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteAnnotation870
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotationResponse DeleteAnnotation(
        java.lang.String annotationName871, java.lang.String annotatedItem872,
        int version873, java.lang.String annotationValue874)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteLabel876
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelResult DeleteLabel(
        java.lang.String labelName877, java.lang.String labelScope878)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteShelveset881
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelvesetResponse DeleteShelveset(
        java.lang.String shelvesetName882, java.lang.String ownerName883)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteWorkspace885
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspaceResponse DeleteWorkspace(
        java.lang.String workspaceName886, java.lang.String ownerName887)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param get889
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfGetOperation Get(
        java.lang.String workspaceName890, java.lang.String ownerName891,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfGetRequest requests892,
        boolean force893, boolean noGet894) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getRepositoryProperties897
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RepositoryProperties GetRepositoryProperties(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryProperties getRepositoryProperties897)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param labelItem900
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItemResponse LabelItem(
        java.lang.String workspaceName901, java.lang.String workspaceOwner902,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionControlLabel label903,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelItemSpec labelSpecs904,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelChildOption children905)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param merge907
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeResponse Merge(
        java.lang.String workspaceName908, java.lang.String workspaceOwner909,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source910,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target911,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec from912,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec to913,
        java.lang.String options914,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel lockLevel915)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pendChanges917
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChangesResponse PendChanges(
        java.lang.String workspaceName918, java.lang.String ownerName919,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeRequest changes920)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryAnnotation922
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfAnnotation QueryAnnotation(
        java.lang.String annotationName923, java.lang.String annotatedItem924,
        int version925) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryBranches928
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfBranchRelative QueryBranches(
        java.lang.String workspaceName929, java.lang.String workspaceOwner930,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items931,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version932)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryChangeset935
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset QueryChangeset(
        int changesetId936, boolean includeChanges937,
        boolean generateDownloadUrls938) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryCheckinNoteDefinition941
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition QueryCheckinNoteDefinition(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString associatedServerItem942)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryCheckinNoteFieldNames945
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryCheckinNoteFieldNames(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNames queryCheckinNoteFieldNames945)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryConflicts948
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfConflict QueryConflicts(
        java.lang.String workspaceName949, java.lang.String ownerName950,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items951)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryEffectiveGlobalPermissions954
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryEffectiveGlobalPermissions(
        java.lang.String identityName955) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryEffectiveItemPermissions958
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryEffectiveItemPermissions(
        java.lang.String workspaceName959, java.lang.String workspaceOwner960,
        java.lang.String item961, java.lang.String identityName962)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryFileTypes965
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType QueryFileTypes(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypes queryFileTypes965)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryGlobalPermissions968
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GlobalSecurity QueryGlobalPermissions(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString identityNames969)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryHistory972
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeset QueryHistory(
        java.lang.String workspaceName973, java.lang.String workspaceOwner974,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec itemSpec975,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionItem976,
        java.lang.String user977,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom978,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo979,
        int maxCount980, boolean includeFiles981,
        boolean generateDownloadUrls982, boolean slotMode983)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItems986
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSet QueryItems(
        java.lang.String workspaceName987, java.lang.String workspaceOwner988,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items989,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version990,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState deletedState991,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType itemType992,
        boolean generateDownloadUrls993) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemsExtended996
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfExtendedItem QueryItemsExtended(
        java.lang.String workspaceName997, java.lang.String workspaceOwner998,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items999,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState deletedState0,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType itemType1)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemPermissions4
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissionsResponse QueryItemPermissions(
        java.lang.String workspaceName5, java.lang.String workspaceOwner6,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs7,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString identityNames8)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryLabels10
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfVersionControlLabel QueryLabels(
        java.lang.String workspaceName11, java.lang.String workspaceOwner12,
        java.lang.String labelName13, java.lang.String labelScope14,
        java.lang.String owner15, java.lang.String filterItem16,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFilterItem17,
        boolean includeItems18, boolean generateDownloadUrls19)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMergeCandidates22
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfMergeCandidate QueryMergeCandidates(
        java.lang.String workspaceName23, java.lang.String workspaceOwner24,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source25,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target26)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMerges29
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesResponse QueryMerges(
        java.lang.String workspaceName30, java.lang.String workspaceOwner31,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source32,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionSource33,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target34,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTarget35,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom36,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo37,
        int maxChangesets38) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMergesWithDetails40
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ChangesetMergeDetails QueryMergesWithDetails(
        java.lang.String workspaceName41, java.lang.String workspaceOwner42,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source43,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionSource44,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target45,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTarget46,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom47,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo48,
        int maxChangesets49) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryPendingSets52
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSetsResponse QueryPendingSets(
        java.lang.String localWorkspaceName53,
        java.lang.String localWorkspaceOwner54,
        java.lang.String queryWorkspaceName55, java.lang.String ownerName56,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs57,
        boolean generateDownloadUrls58) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryShelvedChanges60
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChangesResponse QueryShelvedChanges(
        java.lang.String localWorkspaceName61,
        java.lang.String localWorkspaceOwner62,
        java.lang.String shelvesetName63, java.lang.String ownerName64,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs65,
        boolean generateDownloadUrls66) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryShelvesets68
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfShelveset QueryShelvesets(
        java.lang.String shelvesetName69, java.lang.String ownerName70)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkspace73
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace QueryWorkspace(
        java.lang.String workspaceName74, java.lang.String ownerName75)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkspaces78
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWorkspace QueryWorkspaces(
        java.lang.String ownerName79, java.lang.String computer80)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param refreshIdentityDisplayName83
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayNameResponse RefreshIdentityDisplayName(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayName refreshIdentityDisplayName83)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param removeLocalConflict85
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflictResponse RemoveLocalConflict(
        java.lang.String workspaceName86, java.lang.String ownerName87,
        int conflictId88) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param resolve90
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ResolveResponse Resolve(
        java.lang.String workspaceName91, java.lang.String ownerName92,
        int conflictId93,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution resolution94,
        java.lang.String newPath95, int encoding96,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel lockLevel97)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param setFileTypes99
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypesResponse SetFileTypes(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType fileTypes100)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param shelve102
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure Shelve(
        java.lang.String workspaceName103, java.lang.String workspaceOwner104,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems105,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Shelveset shelveset106,
        boolean replace107) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param undoPendingChanges110
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChangesResponse UndoPendingChanges(
        java.lang.String workspaceName111, java.lang.String ownerName112,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items113)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param unlabelItem115
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItemResponse UnlabelItem(
        java.lang.String workspaceName116, java.lang.String workspaceOwner117,
        java.lang.String labelName118, java.lang.String labelScope119,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items120,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version121)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param unshelve123
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnshelveResponse Unshelve(
        java.lang.String shelvesetName124, java.lang.String shelvesetOwner125,
        java.lang.String workspaceName126, java.lang.String workspaceOwner127,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items128)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateChangeset130
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangesetResponse UpdateChangeset(
        int changeset131, java.lang.String comment132,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote checkinNote133)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateCheckinNoteFieldName135
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldNameResponse UpdateCheckinNoteFieldName(
        java.lang.String path136, java.lang.String existingFieldName137,
        java.lang.String newFieldName138) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateGlobalSecurity140
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurityResponse UpdateGlobalSecurity(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPermissionChange changes141)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateItemSecurity143
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurityResponse UpdateItemSecurity(
        java.lang.String workspaceName144, java.lang.String workspaceOwner145,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfSecurityChange changes146)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateLocalVersion148
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersionResponse UpdateLocalVersion(
        java.lang.String workspaceName149, java.lang.String ownerName150,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLocalVersionUpdate updates151)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updatePendingState153
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingStateResponse UpdatePendingState(
        java.lang.String workspaceName154, java.lang.String workspaceOwner155,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingState updates156)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateWorkspace158
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace UpdateWorkspace(
        java.lang.String oldWorkspaceName159, java.lang.String ownerName160,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace newWorkspace161)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryPendingChangesById164
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingChange QueryPendingChangesById(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt pendingChangeIds165,
        boolean generateDownloadUrls166) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemsById169
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItem QueryItemsById(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt itemIds170,
        int changeSet171, boolean generateDownloadUrls172)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createTeamProjectFolder175
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolderResponse CreateTeamProjectFolder(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.TeamProjectFolderOptions teamProjectOptions176)
        throws java.rmi.RemoteException;

    //
}
