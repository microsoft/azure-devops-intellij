

/**
 * RepositoryRepositorySoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  RepositoryRepositorySoap12 java interface
     */

    public interface RepositoryRepositorySoap12 {
          

        /**
          * Auto generated method signature
          * 
                    * @param checkIn228
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckInResponse CheckIn(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckIn checkIn228)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryShelvesets230
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvesetsResponse QueryShelvesets(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvesets queryShelvesets230)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryFileTypes232
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypesResponse QueryFileTypes(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypes queryFileTypes232)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createTeamProjectFolder234
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolderResponse CreateTeamProjectFolder(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolder createTeamProjectFolder234)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingSets236
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSetsResponse QueryPendingSets(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSets queryPendingSets236)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getRepositoryProperties238
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryPropertiesResponse GetRepositoryProperties(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryProperties getRepositoryProperties238)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param resolve240
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ResolveResponse Resolve(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolve resolve240)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param setFileTypes242
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypesResponse SetFileTypes(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypes setFileTypes242)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryHistory244
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryHistoryResponse QueryHistory(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryHistory queryHistory244)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMerges246
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesResponse QueryMerges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMerges queryMerges246)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMergeCandidates248
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergeCandidatesResponse QueryMergeCandidates(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergeCandidates queryMergeCandidates248)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkspace250
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspaceResponse QueryWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspace queryWorkspace250)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param merge252
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeResponse Merge(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Merge merge252)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateGlobalSecurity254
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurityResponse UpdateGlobalSecurity(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurity updateGlobalSecurity254)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryAnnotation256
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryAnnotationResponse QueryAnnotation(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryAnnotation queryAnnotation256)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMergesWithDetails258
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesWithDetailsResponse QueryMergesWithDetails(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesWithDetails queryMergesWithDetails258)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryCheckinNoteDefinition260
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteDefinitionResponse QueryCheckinNoteDefinition(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteDefinition queryCheckinNoteDefinition260)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateItemSecurity262
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurityResponse UpdateItemSecurity(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurity updateItemSecurity262)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryChangeset264
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryChangesetResponse QueryChangeset(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryChangeset queryChangeset264)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateWorkspace266
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateWorkspaceResponse UpdateWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateWorkspace updateWorkspace266)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param unshelve268
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnshelveResponse Unshelve(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Unshelve unshelve268)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param addConflict270
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflictResponse AddConflict(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflict addConflict270)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteShelveset272
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelvesetResponse DeleteShelveset(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelveset deleteShelveset272)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteAnnotation274
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotationResponse DeleteAnnotation(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotation deleteAnnotation274)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param checkAuthentication276
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthenticationResponse CheckAuthentication(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthentication checkAuthentication276)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createAnnotation278
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotationResponse CreateAnnotation(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotation createAnnotation278)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingChangesById280
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingChangesByIdResponse QueryPendingChangesById(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingChangesById queryPendingChangesById280)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryConflicts282
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryConflictsResponse QueryConflicts(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryConflicts queryConflicts282)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryEffectiveItemPermissions284
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveItemPermissionsResponse QueryEffectiveItemPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveItemPermissions queryEffectiveItemPermissions284)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param get286
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetResponse Get(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Get get286)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemPermissions288
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissionsResponse QueryItemPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissions queryItemPermissions288)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param unlabelItem290
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItemResponse UnlabelItem(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItem unlabelItem290)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pendChanges292
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChangesResponse PendChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChanges pendChanges292)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateChangeset294
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangesetResponse UpdateChangeset(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangeset updateChangeset294)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryLabels296
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryLabelsResponse QueryLabels(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryLabels queryLabels296)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param checkPendingChanges298
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckPendingChangesResponse CheckPendingChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckPendingChanges checkPendingChanges298)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param refreshIdentityDisplayName300
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayNameResponse RefreshIdentityDisplayName(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayName refreshIdentityDisplayName300)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemsById302
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsByIdResponse QueryItemsById(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsById queryItemsById302)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param shelve304
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ShelveResponse Shelve(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Shelve shelve304)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryBranches306
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryBranchesResponse QueryBranches(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryBranches queryBranches306)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateCheckinNoteFieldName308
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldNameResponse UpdateCheckinNoteFieldName(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldName updateCheckinNoteFieldName308)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryShelvedChanges310
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChangesResponse QueryShelvedChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChanges queryShelvedChanges310)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteLabel312
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteLabelResponse DeleteLabel(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteLabel deleteLabel312)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createWorkspace314
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateWorkspaceResponse CreateWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateWorkspace createWorkspace314)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkspaces316
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspacesResponse QueryWorkspaces(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspaces queryWorkspaces316)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateLocalVersion318
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersionResponse UpdateLocalVersion(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersion updateLocalVersion318)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param undoPendingChanges320
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChangesResponse UndoPendingChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChanges undoPendingChanges320)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryCheckinNoteFieldNames322
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNamesResponse QueryCheckinNoteFieldNames(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNames queryCheckinNoteFieldNames322)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteWorkspace324
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspaceResponse DeleteWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspace deleteWorkspace324)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updatePendingState326
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingStateResponse UpdatePendingState(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingState updatePendingState326)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItems328
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsResponse QueryItems(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItems queryItems328)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemsExtended330
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsExtendedResponse QueryItemsExtended(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsExtended queryItemsExtended330)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createCheckinNoteDefinition332
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinitionResponse CreateCheckinNoteDefinition(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinition createCheckinNoteDefinition332)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryGlobalPermissions334
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryGlobalPermissionsResponse QueryGlobalPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryGlobalPermissions queryGlobalPermissions334)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeLocalConflict336
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflictResponse RemoveLocalConflict(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflict removeLocalConflict336)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryEffectiveGlobalPermissions338
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveGlobalPermissionsResponse QueryEffectiveGlobalPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveGlobalPermissions queryEffectiveGlobalPermissions338)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param labelItem340
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItemResponse LabelItem(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItem labelItem340)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    