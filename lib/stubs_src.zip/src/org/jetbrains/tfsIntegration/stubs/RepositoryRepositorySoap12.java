/**
 * RepositoryRepositorySoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  RepositoryRepositorySoap12 java interface
 */
public interface RepositoryRepositorySoap12 {
    /**
     * Auto generated method signature
     * @param addConflict793
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflictResponse AddConflict(
        java.lang.String workspaceName794, java.lang.String ownerName795,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType conflictType796,
        int itemId797, int versionFrom798, int pendingChangeId799,
        java.lang.String sourceLocalItem800,
        java.lang.String targetLocalItem801, int reason802)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkAuthentication804
     */
    public java.lang.String CheckAuthentication(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthentication checkAuthentication804)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkIn807
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckInResponse CheckIn(
        java.lang.String workspaceName808, java.lang.String ownerName809,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems810,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset info811,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNotificationInfo checkinNotificationInfo812,
        java.lang.String checkinOptions813) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkPendingChanges815
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure CheckPendingChanges(
        java.lang.String workspaceName816, java.lang.String ownerName817,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems818)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createAnnotation821
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotationResponse CreateAnnotation(
        java.lang.String annotationName822, java.lang.String annotatedItem823,
        int version824, java.lang.String annotationValue825,
        java.lang.String comment826, boolean overwrite827)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createCheckinNoteDefinition829
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinitionResponse CreateCheckinNoteDefinition(
        java.lang.String associatedServerItem830,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition checkinNoteFields831)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createWorkspace833
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace CreateWorkspace(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace workspace834)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteAnnotation837
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotationResponse DeleteAnnotation(
        java.lang.String annotationName838, java.lang.String annotatedItem839,
        int version840, java.lang.String annotationValue841)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteLabel843
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelResult DeleteLabel(
        java.lang.String labelName844, java.lang.String labelScope845)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteShelveset848
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelvesetResponse DeleteShelveset(
        java.lang.String shelvesetName849, java.lang.String ownerName850)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteWorkspace852
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspaceResponse DeleteWorkspace(
        java.lang.String workspaceName853, java.lang.String ownerName854)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param get856
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfGetOperation Get(
        java.lang.String workspaceName857, java.lang.String ownerName858,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfGetRequest requests859,
        boolean force860, boolean noGet861) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getRepositoryProperties864
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RepositoryProperties GetRepositoryProperties(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryProperties getRepositoryProperties864)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param labelItem867
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItemResponse LabelItem(
        java.lang.String workspaceName868, java.lang.String workspaceOwner869,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionControlLabel label870,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelItemSpec labelSpecs871,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelChildOption children872)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param merge874
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeResponse Merge(
        java.lang.String workspaceName875, java.lang.String workspaceOwner876,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source877,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target878,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec from879,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec to880,
        java.lang.String options881,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel lockLevel882)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pendChanges884
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChangesResponse PendChanges(
        java.lang.String workspaceName885, java.lang.String ownerName886,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeRequest changes887)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryAnnotation889
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfAnnotation QueryAnnotation(
        java.lang.String annotationName890, java.lang.String annotatedItem891,
        int version892) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryBranches895
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfBranchRelative QueryBranches(
        java.lang.String workspaceName896, java.lang.String workspaceOwner897,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items898,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version899)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryChangeset902
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset QueryChangeset(
        int changesetId903, boolean includeChanges904,
        boolean generateDownloadUrls905) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryCheckinNoteDefinition908
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition QueryCheckinNoteDefinition(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString associatedServerItem909)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryCheckinNoteFieldNames912
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryCheckinNoteFieldNames(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNames queryCheckinNoteFieldNames912)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryConflicts915
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfConflict QueryConflicts(
        java.lang.String workspaceName916, java.lang.String ownerName917,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items918)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryEffectiveGlobalPermissions921
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryEffectiveGlobalPermissions(
        java.lang.String identityName922) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryEffectiveItemPermissions925
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString QueryEffectiveItemPermissions(
        java.lang.String workspaceName926, java.lang.String workspaceOwner927,
        java.lang.String item928, java.lang.String identityName929)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryFileTypes932
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType QueryFileTypes(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypes queryFileTypes932)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryGlobalPermissions935
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GlobalSecurity QueryGlobalPermissions(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString identityNames936)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryHistory939
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeset QueryHistory(
        java.lang.String workspaceName940, java.lang.String workspaceOwner941,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec itemSpec942,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionItem943,
        java.lang.String user944,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom945,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo946,
        int maxCount947, boolean includeFiles948,
        boolean generateDownloadUrls949, boolean slotMode950)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItems953
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSet QueryItems(
        java.lang.String workspaceName954, java.lang.String workspaceOwner955,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items956,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version957,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState deletedState958,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType itemType959,
        boolean generateDownloadUrls960) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemsExtended963
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfExtendedItem QueryItemsExtended(
        java.lang.String workspaceName964, java.lang.String workspaceOwner965,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items966,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState deletedState967,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType itemType968)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemPermissions971
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissionsResponse QueryItemPermissions(
        java.lang.String workspaceName972, java.lang.String workspaceOwner973,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs974,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString identityNames975)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryLabels977
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfVersionControlLabel QueryLabels(
        java.lang.String workspaceName978, java.lang.String workspaceOwner979,
        java.lang.String labelName980, java.lang.String labelScope981,
        java.lang.String owner982, java.lang.String filterItem983,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFilterItem984,
        boolean includeItems985, boolean generateDownloadUrls986)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMergeCandidates989
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfMergeCandidate QueryMergeCandidates(
        java.lang.String workspaceName990, java.lang.String workspaceOwner991,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source992,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target993)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryMerges996
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesResponse QueryMerges(
        java.lang.String workspaceName997, java.lang.String workspaceOwner998,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec source999,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionSource0,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec target1,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTarget2,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionFrom3,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec versionTo4,
        int maxChangesets5) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryPendingSets7
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSetsResponse QueryPendingSets(
        java.lang.String localWorkspaceName8,
        java.lang.String localWorkspaceOwner9,
        java.lang.String queryWorkspaceName10, java.lang.String ownerName11,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs12,
        boolean generateDownloadUrls13) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryShelvedChanges15
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChangesResponse QueryShelvedChanges(
        java.lang.String localWorkspaceName16,
        java.lang.String localWorkspaceOwner17,
        java.lang.String shelvesetName18, java.lang.String ownerName19,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec itemSpecs20,
        boolean generateDownloadUrls21) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryShelvesets23
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfShelveset QueryShelvesets(
        java.lang.String shelvesetName24, java.lang.String ownerName25)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkspace28
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace QueryWorkspace(
        java.lang.String workspaceName29, java.lang.String ownerName30)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkspaces33
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWorkspace QueryWorkspaces(
        java.lang.String ownerName34, java.lang.String computer35)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param refreshIdentityDisplayName38
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayNameResponse RefreshIdentityDisplayName(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayName refreshIdentityDisplayName38)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param removeLocalConflict40
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflictResponse RemoveLocalConflict(
        java.lang.String workspaceName41, java.lang.String ownerName42,
        int conflictId43) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param resolve45
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ResolveResponse Resolve(
        java.lang.String workspaceName46, java.lang.String ownerName47,
        int conflictId48,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution resolution49,
        java.lang.String newPath50, int encoding51,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel lockLevel52)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param setFileTypes54
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypesResponse SetFileTypes(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType fileTypes55)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param shelve57
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure Shelve(
        java.lang.String workspaceName58, java.lang.String workspaceOwner59,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString serverItems60,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Shelveset shelveset61,
        boolean replace62) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param undoPendingChanges65
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChangesResponse UndoPendingChanges(
        java.lang.String workspaceName66, java.lang.String ownerName67,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items68)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param unlabelItem70
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItemResponse UnlabelItem(
        java.lang.String workspaceName71, java.lang.String workspaceOwner72,
        java.lang.String labelName73, java.lang.String labelScope74,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items75,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec version76)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param unshelve78
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnshelveResponse Unshelve(
        java.lang.String shelvesetName79, java.lang.String shelvesetOwner80,
        java.lang.String workspaceName81, java.lang.String workspaceOwner82,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec items83)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateChangeset85
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangesetResponse UpdateChangeset(
        int changeset86, java.lang.String comment87,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote checkinNote88)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateCheckinNoteFieldName90
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldNameResponse UpdateCheckinNoteFieldName(
        java.lang.String path91, java.lang.String existingFieldName92,
        java.lang.String newFieldName93) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateGlobalSecurity95
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurityResponse UpdateGlobalSecurity(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPermissionChange changes96)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateItemSecurity98
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurityResponse UpdateItemSecurity(
        java.lang.String workspaceName99, java.lang.String workspaceOwner100,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfSecurityChange changes101)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateLocalVersion103
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersionResponse UpdateLocalVersion(
        java.lang.String workspaceName104, java.lang.String ownerName105,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLocalVersionUpdate updates106)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updatePendingState108
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingStateResponse UpdatePendingState(
        java.lang.String workspaceName109, java.lang.String workspaceOwner110,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingState updates111)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateWorkspace113
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace UpdateWorkspace(
        java.lang.String oldWorkspaceName114, java.lang.String ownerName115,
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace newWorkspace116)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryPendingChangesById119
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingChange QueryPendingChangesById(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt pendingChangeIds120,
        boolean generateDownloadUrls121) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryItemsById124
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItem QueryItemsById(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt itemIds125,
        int changeSet126, boolean generateDownloadUrls127)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createTeamProjectFolder130
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolderResponse CreateTeamProjectFolder(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.TeamProjectFolderOptions teamProjectOptions131)
        throws java.rmi.RemoteException;

    //
}
