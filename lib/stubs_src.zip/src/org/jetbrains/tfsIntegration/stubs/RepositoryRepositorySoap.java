

/**
 * RepositoryRepositorySoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  RepositoryRepositorySoap java interface
     */

    public interface RepositoryRepositorySoap {
          

        /**
          * Auto generated method signature
          * 
                    * @param checkIn
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckInResponse CheckIn(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckIn checkIn)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryShelvesets
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvesetsResponse QueryShelvesets(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvesets queryShelvesets)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryFileTypes
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypesResponse QueryFileTypes(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryFileTypes queryFileTypes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createTeamProjectFolder
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolderResponse CreateTeamProjectFolder(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateTeamProjectFolder createTeamProjectFolder)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingSets
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSetsResponse QueryPendingSets(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingSets queryPendingSets)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getRepositoryProperties
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryPropertiesResponse GetRepositoryProperties(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRepositoryProperties getRepositoryProperties)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param resolve
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ResolveResponse Resolve(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolve resolve)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param setFileTypes
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypesResponse SetFileTypes(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SetFileTypes setFileTypes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryHistory
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryHistoryResponse QueryHistory(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryHistory queryHistory)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMerges
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesResponse QueryMerges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMerges queryMerges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMergeCandidates
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergeCandidatesResponse QueryMergeCandidates(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergeCandidates queryMergeCandidates)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkspace
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspaceResponse QueryWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspace queryWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param merge
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeResponse Merge(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Merge merge)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateGlobalSecurity
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurityResponse UpdateGlobalSecurity(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateGlobalSecurity updateGlobalSecurity)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryAnnotation
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryAnnotationResponse QueryAnnotation(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryAnnotation queryAnnotation)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMergesWithDetails
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesWithDetailsResponse QueryMergesWithDetails(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryMergesWithDetails queryMergesWithDetails)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryCheckinNoteDefinition
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteDefinitionResponse QueryCheckinNoteDefinition(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteDefinition queryCheckinNoteDefinition)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateItemSecurity
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurityResponse UpdateItemSecurity(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateItemSecurity updateItemSecurity)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryChangeset
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryChangesetResponse QueryChangeset(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryChangeset queryChangeset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateWorkspace
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateWorkspaceResponse UpdateWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateWorkspace updateWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param unshelve
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnshelveResponse Unshelve(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Unshelve unshelve)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param addConflict
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflictResponse AddConflict(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AddConflict addConflict)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteShelveset
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelvesetResponse DeleteShelveset(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteShelveset deleteShelveset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteAnnotation
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotationResponse DeleteAnnotation(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteAnnotation deleteAnnotation)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param checkAuthentication
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthenticationResponse CheckAuthentication(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckAuthentication checkAuthentication)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createAnnotation
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotationResponse CreateAnnotation(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateAnnotation createAnnotation)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingChangesById
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingChangesByIdResponse QueryPendingChangesById(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryPendingChangesById queryPendingChangesById)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryConflicts
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryConflictsResponse QueryConflicts(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryConflicts queryConflicts)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryEffectiveItemPermissions
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveItemPermissionsResponse QueryEffectiveItemPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveItemPermissions queryEffectiveItemPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param get
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetResponse Get(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Get get)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemPermissions
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissionsResponse QueryItemPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemPermissions queryItemPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param unlabelItem
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItemResponse UnlabelItem(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UnlabelItem unlabelItem)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pendChanges
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChangesResponse PendChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendChanges pendChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateChangeset
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangesetResponse UpdateChangeset(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateChangeset updateChangeset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryLabels
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryLabelsResponse QueryLabels(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryLabels queryLabels)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param checkPendingChanges
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckPendingChangesResponse CheckPendingChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckPendingChanges checkPendingChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param refreshIdentityDisplayName
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayNameResponse RefreshIdentityDisplayName(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RefreshIdentityDisplayName refreshIdentityDisplayName)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemsById
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsByIdResponse QueryItemsById(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsById queryItemsById)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param shelve
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ShelveResponse Shelve(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Shelve shelve)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryBranches
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryBranchesResponse QueryBranches(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryBranches queryBranches)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateCheckinNoteFieldName
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldNameResponse UpdateCheckinNoteFieldName(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateCheckinNoteFieldName updateCheckinNoteFieldName)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryShelvedChanges
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChangesResponse QueryShelvedChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryShelvedChanges queryShelvedChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteLabel
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteLabelResponse DeleteLabel(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteLabel deleteLabel)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createWorkspace
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateWorkspaceResponse CreateWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateWorkspace createWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkspaces
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspacesResponse QueryWorkspaces(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryWorkspaces queryWorkspaces)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateLocalVersion
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersionResponse UpdateLocalVersion(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdateLocalVersion updateLocalVersion)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param undoPendingChanges
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChangesResponse UndoPendingChanges(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UndoPendingChanges undoPendingChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryCheckinNoteFieldNames
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNamesResponse QueryCheckinNoteFieldNames(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryCheckinNoteFieldNames queryCheckinNoteFieldNames)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteWorkspace
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspaceResponse DeleteWorkspace(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeleteWorkspace deleteWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updatePendingState
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingStateResponse UpdatePendingState(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.UpdatePendingState updatePendingState)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItems
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsResponse QueryItems(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItems queryItems)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemsExtended
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsExtendedResponse QueryItemsExtended(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryItemsExtended queryItemsExtended)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createCheckinNoteDefinition
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinitionResponse CreateCheckinNoteDefinition(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CreateCheckinNoteDefinition createCheckinNoteDefinition)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryGlobalPermissions
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryGlobalPermissionsResponse QueryGlobalPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryGlobalPermissions queryGlobalPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeLocalConflict
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflictResponse RemoveLocalConflict(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RemoveLocalConflict removeLocalConflict)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryEffectiveGlobalPermissions
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveGlobalPermissionsResponse QueryEffectiveGlobalPermissions(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.QueryEffectiveGlobalPermissions queryEffectiveGlobalPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param labelItem
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItemResponse LabelItem(

                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItem labelItem)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    