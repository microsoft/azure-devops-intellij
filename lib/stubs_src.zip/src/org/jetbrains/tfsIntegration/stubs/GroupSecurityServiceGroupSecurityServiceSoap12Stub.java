/**
 * GroupSecurityServiceGroupSecurityServiceSoap12Stub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  GroupSecurityServiceGroupSecurityServiceSoap12Stub java implementation
 */
public class GroupSecurityServiceGroupSecurityServiceSoap12Stub extends org.apache.axis2.client.Stub
    implements GroupSecurityServiceGroupSecurityServiceSoap12 {
    protected org.apache.axis2.description.AxisOperation[] _operations;

    //hashmaps to keep the fault mapping
    private java.util.HashMap faultExceptionNameMap = new java.util.HashMap();
    private java.util.HashMap faultExceptionClassNameMap = new java.util.HashMap();
    private java.util.HashMap faultMessageMap = new java.util.HashMap();
    private javax.xml.namespace.QName[] opNameArray = null;

    /**
     *Constructor that takes in a configContext
     */
    public GroupSecurityServiceGroupSecurityServiceSoap12Stub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(configurationContext, targetEndpoint, false);
    }

    /**
     * Constructor that takes in a configContext  and useseperate listner
     */
    public GroupSecurityServiceGroupSecurityServiceSoap12Stub(
        org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint, boolean useSeparateListener)
        throws org.apache.axis2.AxisFault {
        //To populate AxisService
        populateAxisService();
        populateFaults();

        _serviceClient = new org.apache.axis2.client.ServiceClient(configurationContext,
                _service);

        configurationContext = _serviceClient.getServiceContext()
                                             .getConfigurationContext();

        _serviceClient.getOptions()
                      .setTo(new org.apache.axis2.addressing.EndpointReference(
                targetEndpoint));
        _serviceClient.getOptions().setUseSeparateListener(useSeparateListener);

        //Set the soap version
        _serviceClient.getOptions()
                      .setSoapVersionURI(org.apache.axiom.soap.SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI);
    }

    /**
     * Default Constructor
     */
    public GroupSecurityServiceGroupSecurityServiceSoap12Stub(
        org.apache.axis2.context.ConfigurationContext configurationContext)
        throws org.apache.axis2.AxisFault {
        this(configurationContext,
            "http://wmw-2003-01:8080/Services/v1.0/GroupSecurityService.asmx");
    }

    /**
     * Default Constructor
     */
    public GroupSecurityServiceGroupSecurityServiceSoap12Stub()
        throws org.apache.axis2.AxisFault {
        this("http://wmw-2003-01:8080/Services/v1.0/GroupSecurityService.asmx");
    }

    /**
     * Constructor taking the target endpoint
     */
    public GroupSecurityServiceGroupSecurityServiceSoap12Stub(
        java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(null, targetEndpoint);
    }

    private void populateAxisService() throws org.apache.axis2.AxisFault {
        //creating the Service with a unique name
        _service = new org.apache.axis2.description.AxisService(
                "GroupSecurityService" + this.hashCode());

        //creating the operations
        org.apache.axis2.description.AxisOperation __operation;

        _operations = new org.apache.axis2.description.AxisOperation[11];

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "ReadIdentity"));
        _service.addOperation(__operation);

        _operations[0] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "ReadIdentityFromSource"));
        _service.addOperation(__operation);

        _operations[1] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "IsIdentityCached"));
        _service.addOperation(__operation);

        _operations[2] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "GetChangedIdentities"));
        _service.addOperation(__operation);

        _operations[3] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "CreateApplicationGroup"));
        _service.addOperation(__operation);

        _operations[4] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "ListApplicationGroups"));
        _service.addOperation(__operation);

        _operations[5] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "UpdateApplicationGroup"));
        _service.addOperation(__operation);

        _operations[6] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "DeleteApplicationGroup"));
        _service.addOperation(__operation);

        _operations[7] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "AddMemberToApplicationGroup"));
        _service.addOperation(__operation);

        _operations[8] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "RemoveMemberFromApplicationGroup"));
        _service.addOperation(__operation);

        _operations[9] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                "IsMember"));
        _service.addOperation(__operation);

        _operations[10] = __operation;
    }

    //populates the faults
    private void populateFaults() {
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#ReadIdentity
     * @param readIdentity11
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.Identity ReadIdentity(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor12,
        java.lang.String factorValue13,
        org.jetbrains.tfsIntegration.stubs.services.authorization.QueryMembership queryMembership14)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[0].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/ReadIdentity");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    factor12, factorValue13, queryMembership14,
                    dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "ReadIdentity")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getReadIdentityResponseReadIdentityResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#ReadIdentityFromSource
     * @param readIdentityFromSource17
     */
    public org.jetbrains.tfsIntegration.stubs.services.authorization.Identity ReadIdentityFromSource(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor18,
        java.lang.String factorValue19) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[1].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/ReadIdentityFromSource");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    factor18, factorValue19, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "ReadIdentityFromSource")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getReadIdentityFromSourceResponseReadIdentityFromSourceResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#IsIdentityCached
     * @param isIdentityCached22
     */
    public boolean IsIdentityCached(
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor factor23,
        java.lang.String factorValue24) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[2].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/IsIdentityCached");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    factor23, factorValue24, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "IsIdentityCached")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getIsIdentityCachedResponseIsIdentityCachedResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#GetChangedIdentities
     * @param getChangedIdentities27
     */
    public java.lang.String GetChangedIdentities(int sequence_id28)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[3].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/GetChangedIdentities");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    sequence_id28, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "GetChangedIdentities")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getGetChangedIdentitiesResponseGetChangedIdentitiesResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#CreateApplicationGroup
     * @param createApplicationGroup31
     */
    public java.lang.String CreateApplicationGroup(
        java.lang.String projectUri32, java.lang.String groupName33,
        java.lang.String groupDescription34) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[4].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/CreateApplicationGroup");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri32, groupName33, groupDescription34,
                    dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "CreateApplicationGroup")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getCreateApplicationGroupResponseCreateApplicationGroupResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#ListApplicationGroups
     * @param listApplicationGroups37
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ArrayOfIdentity ListApplicationGroups(
        java.lang.String projectUri38) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[5].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/ListApplicationGroups");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    projectUri38, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "ListApplicationGroups")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getListApplicationGroupsResponseListApplicationGroupsResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#UpdateApplicationGroup
     * @param updateApplicationGroup41
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse UpdateApplicationGroup(
        java.lang.String groupSid42,
        org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupProperty property43,
        java.lang.String newValue44) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[6].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/UpdateApplicationGroup");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    groupSid42, property43, newValue44, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "UpdateApplicationGroup")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#DeleteApplicationGroup
     * @param deleteApplicationGroup46
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse DeleteApplicationGroup(
        java.lang.String groupSid47) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[7].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/DeleteApplicationGroup");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    groupSid47, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "DeleteApplicationGroup")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#AddMemberToApplicationGroup
     * @param addMemberToApplicationGroup49
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse AddMemberToApplicationGroup(
        java.lang.String groupSid50, java.lang.String identitySid51)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[8].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/AddMemberToApplicationGroup");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    groupSid50, identitySid51, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "AddMemberToApplicationGroup")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#RemoveMemberFromApplicationGroup
     * @param removeMemberFromApplicationGroup53
     */
    public org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse RemoveMemberFromApplicationGroup(
        java.lang.String groupSid54, java.lang.String identitySid55)
        throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[9].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/RemoveMemberFromApplicationGroup");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    groupSid54, identitySid55, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "RemoveMemberFromApplicationGroup")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse) object;
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     * Auto generated method signature
     * @see org.jetbrains.tfsIntegration.stubs.GroupSecurityServiceGroupSecurityServiceSoap12#IsMember
     * @param isMember57
     */
    public boolean IsMember(java.lang.String groupSid58,
        java.lang.String identitySid59) throws java.rmi.RemoteException {
        try {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[10].getName());
            _operationClient.getOptions()
                            .setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03/IsMember");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                "&");

            // create a message context
            org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember dummyWrappedType =
                null;
            env = toEnvelope(getFactory(_operationClient.getOptions()
                                                        .getSoapVersionURI()),
                    groupSid58, identitySid59, dummyWrappedType,
                    optimizeContent(
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/GroupSecurity/03",
                            "IsMember")));

            //adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            //execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(_returnEnv.getBody()
                                                       .getFirstElement(),
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse.class,
                    getEnvelopeNamespaces(_returnEnv));
            _messageContext.getTransportOut().getSender()
                           .cleanup(_messageContext);

            return getIsMemberResponseIsMemberResult((org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse) object);
        } catch (org.apache.axis2.AxisFault f) {
            org.apache.axiom.om.OMElement faultElt = f.getDetail();

            if (faultElt != null) {
                if (faultExceptionNameMap.containsKey(faultElt.getQName())) {
                    //make the fault by reflection
                    try {
                        java.lang.String exceptionClassName = (java.lang.String) faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex = (java.lang.Exception) exceptionClass.newInstance();

                        //message class
                        java.lang.String messageClassName = (java.lang.String) faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,
                                messageClass, null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                new java.lang.Class[] { messageClass });
                        m.invoke(ex, new java.lang.Object[] { messageObject });

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    } catch (java.lang.ClassCastException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                } else {
                    throw f;
                }
            } else {
                throw f;
            }
        }
    }

    /**
     *  A utility method that copies the namepaces from the SOAPEnvelope
     */
    private java.util.Map getEnvelopeNamespaces(
        org.apache.axiom.soap.SOAPEnvelope env) {
        java.util.Map returnMap = new java.util.HashMap();
        java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();

        while (namespaceIterator.hasNext()) {
            org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator.next();
            returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
        }

        return returnMap;
    }

    private boolean optimizeContent(javax.xml.namespace.QName opName) {
        if (opNameArray == null) {
            return false;
        }

        for (int i = 0; i < opNameArray.length; i++) {
            if (opName.equals(opNameArray[i])) {
                return true;
            }
        }

        return false;
    }

    //http://wmw-2003-01:8080/Services/v1.0/GroupSecurityService.asmx
    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.om.OMElement toOM(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            return param.getOMElement(org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse.MY_QNAME,
                org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, int param1,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities();

            wrappedType.setSequence_id(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private java.lang.String getGetChangedIdentitiesResponseGetChangedIdentitiesResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse wrappedType) {
        return wrappedType.getGetChangedIdentitiesResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup();

            wrappedType.setGroupSid(param1);

            wrappedType.setIdentitySid(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource();

            wrappedType.setFactor(param1);

            wrappedType.setFactorValue(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.authorization.Identity getReadIdentityFromSourceResponseReadIdentityFromSourceResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse wrappedType) {
        return wrappedType.getReadIdentityFromSourceResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2, java.lang.String param3,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup();

            wrappedType.setProjectUri(param1);

            wrappedType.setGroupName(param2);

            wrappedType.setGroupDescription(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private java.lang.String getCreateApplicationGroupResponseCreateApplicationGroupResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse wrappedType) {
        return wrappedType.getCreateApplicationGroupResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup();

            wrappedType.setGroupSid(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember();

            wrappedType.setGroupSid(param1);

            wrappedType.setIdentitySid(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private boolean getIsMemberResponseIsMemberResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse wrappedType) {
        return wrappedType.getIsMemberResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached();

            wrappedType.setFactor(param1);

            wrappedType.setFactorValue(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private boolean getIsIdentityCachedResponseIsIdentityCachedResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse wrappedType) {
        return wrappedType.getIsIdentityCachedResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.authorization.SearchFactor param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.authorization.QueryMembership param3,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity();

            wrappedType.setFactor(param1);

            wrappedType.setFactorValue(param2);

            wrappedType.setQueryMembership(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.authorization.Identity getReadIdentityResponseReadIdentityResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse wrappedType) {
        return wrappedType.getReadIdentityResult();
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.authorization.ApplicationGroupProperty param2,
        java.lang.String param3,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup();

            wrappedType.setGroupSid(param1);

            wrappedType.setProperty(param2);

            wrappedType.setNewValue(param3);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        java.lang.String param2,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup();

            wrappedType.setGroupSid(param1);

            wrappedType.setIdentitySid(param2);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory, java.lang.String param1,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups dummyWrappedType,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups wrappedType =
                new org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups();

            wrappedType.setProjectUri(param1);

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();

            emptyEnvelope.getBody()
                         .addChild(wrappedType.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory,
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups param,
        boolean optimizeContent) throws org.apache.axis2.AxisFault {
        try {
            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                         .addChild(param.getOMElement(
                    org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups.MY_QNAME,
                    factory));

            return emptyEnvelope;
        } catch (org.apache.axis2.databinding.ADBException e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
    }

    /* methods to provide back word compatibility */
    private org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ArrayOfIdentity getListApplicationGroupsResponseListApplicationGroupsResult(
        org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse wrappedType) {
        return wrappedType.getListApplicationGroupsResult();
    }

    /**
     *  get the default envelope
     */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(
        org.apache.axiom.soap.SOAPFactory factory) {
        return factory.getDefaultEnvelope();
    }

    private java.lang.Object fromOM(org.apache.axiom.om.OMElement param,
        java.lang.Class type, java.util.Map extraNamespaces)
        throws org.apache.axis2.AxisFault {
        try {
            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentities.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.GetChangedIdentitiesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroup.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.RemoveMemberFromApplicationGroupResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSource.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityFromSourceResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroup.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.CreateApplicationGroupResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroup.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.DeleteApplicationGroupResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMember.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsMemberResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCached.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.IsIdentityCachedResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentity.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ReadIdentityResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroup.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.UpdateApplicationGroupResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroup.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.AddMemberToApplicationGroupResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroups.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }

            if (org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse.class.equals(
                        type)) {
                return org.jetbrains.tfsIntegration.stubs.services.groupsecurityservice.ListApplicationGroupsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
            }
        } catch (java.lang.Exception e) {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

        return null;
    }
}
