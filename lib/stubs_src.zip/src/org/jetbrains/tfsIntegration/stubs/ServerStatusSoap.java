/**
 * ServerStatusServerStatusSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ServerStatusSoap java interface
 */
public interface ServerStatusSoap {
    /**
     * Auto generated method signature
     * @param getServerStatus18
     */
    public org.jetbrains.tfsIntegration.stubs.services.serverstatus.ArrayOfDataChanged GetServerStatus(
        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetServerStatus getServerStatus18)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkAuthentication21
     */
    public java.lang.String CheckAuthentication(
        org.jetbrains.tfsIntegration.stubs.services.serverstatus.CheckAuthentication checkAuthentication21)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getSupportedContractVersion24
     */
    public java.lang.String GetSupportedContractVersion(
        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetSupportedContractVersion getSupportedContractVersion24)
        throws java.rmi.RemoteException;

    //
}
