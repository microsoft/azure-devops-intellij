/**
 * PendingChange.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;


/**
 *  PendingChange bean class
 */
public class PendingChange implements org.apache.axis2.databinding.ADBBean {
    /**
     * field for Date
     * This was an Attribute!
     */
    protected java.util.Calendar localDate;

    /**
     * field for Did
     * This was an Attribute!
     */
    protected int localDid;

    /**
     * field for Type
     * This was an Attribute!
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localType;

    /**
     * field for Enc
     * This was an Attribute!
     */
    protected int localEnc;

    /**
     * field for Itemid
     * This was an Attribute!
     */
    protected int localItemid;

    /**
     * field for Local
     * This was an Attribute!
     */
    protected java.lang.String localLocal;

    /**
     * field for Lock
     * This was an Attribute!
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel localLock;

    /**
     * field for Item
     * This was an Attribute!
     */
    protected java.lang.String localItem;

    /**
     * field for Srclocal
     * This was an Attribute!
     */
    protected java.lang.String localSrclocal;

    /**
     * field for Srcitem
     * This was an Attribute!
     */
    protected java.lang.String localSrcitem;

    /**
     * field for Ver
     * This was an Attribute!
     */
    protected int localVer;

    /**
     * field for Hash
     * This was an Attribute!
     */
    protected javax.activation.DataHandler localHash;

    /**
     * field for Uhash
     * This was an Attribute!
     */
    protected javax.activation.DataHandler localUhash;

    /**
     * field for Pcid
     * This was an Attribute!
     */
    protected int localPcid;

    /**
     * field for Durl
     * This was an Attribute!
     */
    protected java.lang.String localDurl;

    /**
     * field for Shelvedurl
     * This was an Attribute!
     */
    protected java.lang.String localShelvedurl;

    /* This type was generated from the piece of schema that had
       name = PendingChange
       Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
       Namespace Prefix =
     */
    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")) {
            return "";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Auto generated getter method
     * @return java.util.Calendar
     */
    public java.util.Calendar getDate() {
        return localDate;
    }

    /**
     * Auto generated setter method
     * @param param Date
     */
    public void setDate(java.util.Calendar param) {
        this.localDate = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getDid() {
        return localDid;
    }

    /**
     * Auto generated setter method
     * @param param Did
     */
    public void setDid(int param) {
        this.localDid = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getType() {
        return localType;
    }

    /**
     * Auto generated setter method
     * @param param Type
     */
    public void setType(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param) {
        this.localType = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getEnc() {
        return localEnc;
    }

    /**
     * Auto generated setter method
     * @param param Enc
     */
    public void setEnc(int param) {
        this.localEnc = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getItemid() {
        return localItemid;
    }

    /**
     * Auto generated setter method
     * @param param Itemid
     */
    public void setItemid(int param) {
        this.localItemid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getLocal() {
        return localLocal;
    }

    /**
     * Auto generated setter method
     * @param param Local
     */
    public void setLocal(java.lang.String param) {
        this.localLocal = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel getLock() {
        return localLock;
    }

    /**
     * Auto generated setter method
     * @param param Lock
     */
    public void setLock(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel param) {
        this.localLock = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getItem() {
        return localItem;
    }

    /**
     * Auto generated setter method
     * @param param Item
     */
    public void setItem(java.lang.String param) {
        this.localItem = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getSrclocal() {
        return localSrclocal;
    }

    /**
     * Auto generated setter method
     * @param param Srclocal
     */
    public void setSrclocal(java.lang.String param) {
        this.localSrclocal = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getSrcitem() {
        return localSrcitem;
    }

    /**
     * Auto generated setter method
     * @param param Srcitem
     */
    public void setSrcitem(java.lang.String param) {
        this.localSrcitem = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getVer() {
        return localVer;
    }

    /**
     * Auto generated setter method
     * @param param Ver
     */
    public void setVer(int param) {
        this.localVer = param;
    }

    /**
     * Auto generated getter method
     * @return javax.activation.DataHandler
     */
    public javax.activation.DataHandler getHash() {
        return localHash;
    }

    /**
     * Auto generated setter method
     * @param param Hash
     */
    public void setHash(javax.activation.DataHandler param) {
        this.localHash = param;
    }

    /**
     * Auto generated getter method
     * @return javax.activation.DataHandler
     */
    public javax.activation.DataHandler getUhash() {
        return localUhash;
    }

    /**
     * Auto generated setter method
     * @param param Uhash
     */
    public void setUhash(javax.activation.DataHandler param) {
        this.localUhash = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getPcid() {
        return localPcid;
    }

    /**
     * Auto generated setter method
     * @param param Pcid
     */
    public void setPcid(int param) {
        this.localPcid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getDurl() {
        return localDurl;
    }

    /**
     * Auto generated setter method
     * @param param Durl
     */
    public void setDurl(java.lang.String param) {
        this.localDurl = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getShelvedurl() {
        return localShelvedurl;
    }

    /**
     * Auto generated setter method
     * @param param Shelvedurl
     */
    public void setShelvedurl(java.lang.String param) {
        this.localShelvedurl = param;
    }

    /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
    public static boolean isReaderMTOMAware(
        javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;

        try {
            isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(
                        org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        } catch (java.lang.IllegalArgumentException e) {
            isReaderMTOMAware = false;
        }

        return isReaderMTOMAware;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        org.apache.axiom.om.OMDataSource dataSource = new org.apache.axis2.databinding.ADBDataSource(this,
                parentQName) {
                public void serialize(
                    org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                    throws javax.xml.stream.XMLStreamException {
                    PendingChange.this.serialize(parentQName, factory, xmlWriter);
                }
            };

        return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(parentQName,
            factory, dataSource);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory,
        org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();

        if (namespace != null) {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace,
                    parentQName.getLocalPart());
            } else {
                if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(),
                    namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        } else {
            xmlWriter.writeStartElement(parentQName.getLocalPart());
        }

        if (localDate != null) {
            writeAttribute("", "date",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localDate), xmlWriter);
        } else {
            throw new org.apache.axis2.databinding.ADBException(
                "required attribute localDate is null");
        }

        if (localDid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "did",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localDid), xmlWriter);
        }

        if (localType != null) {
            writeAttribute("", "type", localType.toString(), xmlWriter);
        }

        if (localEnc != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "enc",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localEnc), xmlWriter);
        }

        if (localItemid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "itemid",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localItemid), xmlWriter);
        }

        if (localLocal != null) {
            writeAttribute("", "local",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localLocal), xmlWriter);
        }

        if (localLock != null) {
            writeAttribute("", "lock", localLock.toString(), xmlWriter);
        }

        if (localItem != null) {
            writeAttribute("", "item",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localItem), xmlWriter);
        }

        if (localSrclocal != null) {
            writeAttribute("", "srclocal",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localSrclocal), xmlWriter);
        }

        if (localSrcitem != null) {
            writeAttribute("", "srcitem",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localSrcitem), xmlWriter);
        }

        if (localVer != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "ver",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localVer), xmlWriter);
        }

        if (localHash != null) {
            writeAttribute("", "hash",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localHash), xmlWriter);
        }

        if (localUhash != null) {
            writeAttribute("", "uhash",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localUhash), xmlWriter);
        }

        if (localPcid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "pcid",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localPcid), xmlWriter);
        }

        if (localDurl != null) {
            writeAttribute("", "durl",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localDurl), xmlWriter);
        }

        if (localShelvedurl != null) {
            writeAttribute("", "shelvedurl",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localShelvedurl), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     * databinding method to get an XML representation of this object
     *
     */
    public javax.xml.stream.XMLStreamReader getPullParser(
        javax.xml.namespace.QName qName)
        throws org.apache.axis2.databinding.ADBException {
        java.util.ArrayList elementList = new java.util.ArrayList();
        java.util.ArrayList attribList = new java.util.ArrayList();

        attribList.add(new javax.xml.namespace.QName("", "date"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localDate));

        attribList.add(new javax.xml.namespace.QName("", "did"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localDid));

        attribList.add(new javax.xml.namespace.QName("", "type"));

        attribList.add(localType.toString());

        attribList.add(new javax.xml.namespace.QName("", "enc"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localEnc));

        attribList.add(new javax.xml.namespace.QName("", "itemid"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localItemid));

        attribList.add(new javax.xml.namespace.QName("", "local"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localLocal));

        attribList.add(new javax.xml.namespace.QName("", "lock"));

        attribList.add(localLock.toString());

        attribList.add(new javax.xml.namespace.QName("", "item"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localItem));

        attribList.add(new javax.xml.namespace.QName("", "srclocal"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localSrclocal));

        attribList.add(new javax.xml.namespace.QName("", "srcitem"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localSrcitem));

        attribList.add(new javax.xml.namespace.QName("", "ver"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localVer));

        attribList.add(new javax.xml.namespace.QName("", "hash"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localHash));

        attribList.add(new javax.xml.namespace.QName("", "uhash"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localUhash));

        attribList.add(new javax.xml.namespace.QName("", "pcid"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localPcid));

        attribList.add(new javax.xml.namespace.QName("", "durl"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localDurl));

        attribList.add(new javax.xml.namespace.QName("", "shelvedurl"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localShelvedurl));

        return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
            elementList.toArray(), attribList.toArray());
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static PendingChange parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            PendingChange object = new PendingChange();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"PendingChange".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (PendingChange) org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                // handle attribute "date"
                java.lang.String tempAttribDate = reader.getAttributeValue(null,
                        "date");

                if (tempAttribDate != null) {
                    java.lang.String content = tempAttribDate;

                    object.setDate(org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(
                            tempAttribDate));
                } else {
                    throw new org.apache.axis2.databinding.ADBException(
                        "Required attribute date is missing");
                }

                handledAttributes.add("date");

                // handle attribute "did"
                java.lang.String tempAttribDid = reader.getAttributeValue(null,
                        "did");

                if (tempAttribDid != null) {
                    java.lang.String content = tempAttribDid;

                    object.setDid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribDid));
                } else {
                    object.setDid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("did");

                // handle attribute "type"
                java.lang.String tempAttribType = reader.getAttributeValue(null,
                        "type");

                if (tempAttribType != null) {
                    java.lang.String content = tempAttribType;

                    if (tempAttribType.indexOf(":") > 0) {
                        // this seems to be a Qname so find the namespace and send
                        prefix = tempAttribType.substring(0,
                                tempAttribType.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object.setType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(
                                tempAttribType, namespaceuri));
                    } else {
                        // this seems to be not a qname send and empty namespace incase of it is
                        // check is done in fromString method
                        object.setType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(
                                tempAttribType, ""));
                    }
                } else {
                }

                handledAttributes.add("type");

                // handle attribute "enc"
                java.lang.String tempAttribEnc = reader.getAttributeValue(null,
                        "enc");

                if (tempAttribEnc != null) {
                    java.lang.String content = tempAttribEnc;

                    object.setEnc(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribEnc));
                } else {
                    object.setEnc(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("enc");

                // handle attribute "itemid"
                java.lang.String tempAttribItemid = reader.getAttributeValue(null,
                        "itemid");

                if (tempAttribItemid != null) {
                    java.lang.String content = tempAttribItemid;

                    object.setItemid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribItemid));
                } else {
                    object.setItemid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("itemid");

                // handle attribute "local"
                java.lang.String tempAttribLocal = reader.getAttributeValue(null,
                        "local");

                if (tempAttribLocal != null) {
                    java.lang.String content = tempAttribLocal;

                    object.setLocal(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribLocal));
                } else {
                }

                handledAttributes.add("local");

                // handle attribute "lock"
                java.lang.String tempAttribLock = reader.getAttributeValue(null,
                        "lock");

                if (tempAttribLock != null) {
                    java.lang.String content = tempAttribLock;

                    if (tempAttribLock.indexOf(":") > 0) {
                        // this seems to be a Qname so find the namespace and send
                        prefix = tempAttribLock.substring(0,
                                tempAttribLock.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object.setLock(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel.Factory.fromString(
                                tempAttribLock, namespaceuri));
                    } else {
                        // this seems to be not a qname send and empty namespace incase of it is
                        // check is done in fromString method
                        object.setLock(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel.Factory.fromString(
                                tempAttribLock, ""));
                    }
                } else {
                }

                handledAttributes.add("lock");

                // handle attribute "item"
                java.lang.String tempAttribItem = reader.getAttributeValue(null,
                        "item");

                if (tempAttribItem != null) {
                    java.lang.String content = tempAttribItem;

                    object.setItem(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribItem));
                } else {
                }

                handledAttributes.add("item");

                // handle attribute "srclocal"
                java.lang.String tempAttribSrclocal = reader.getAttributeValue(null,
                        "srclocal");

                if (tempAttribSrclocal != null) {
                    java.lang.String content = tempAttribSrclocal;

                    object.setSrclocal(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribSrclocal));
                } else {
                }

                handledAttributes.add("srclocal");

                // handle attribute "srcitem"
                java.lang.String tempAttribSrcitem = reader.getAttributeValue(null,
                        "srcitem");

                if (tempAttribSrcitem != null) {
                    java.lang.String content = tempAttribSrcitem;

                    object.setSrcitem(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribSrcitem));
                } else {
                }

                handledAttributes.add("srcitem");

                // handle attribute "ver"
                java.lang.String tempAttribVer = reader.getAttributeValue(null,
                        "ver");

                if (tempAttribVer != null) {
                    java.lang.String content = tempAttribVer;

                    object.setVer(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribVer));
                } else {
                    object.setVer(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("ver");

                // handle attribute "hash"
                java.lang.String tempAttribHash = reader.getAttributeValue(null,
                        "hash");

                if (tempAttribHash != null) {
                    java.lang.String content = tempAttribHash;

                    object.setHash(org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(
                            tempAttribHash));
                } else {
                }

                handledAttributes.add("hash");

                // handle attribute "uhash"
                java.lang.String tempAttribUhash = reader.getAttributeValue(null,
                        "uhash");

                if (tempAttribUhash != null) {
                    java.lang.String content = tempAttribUhash;

                    object.setUhash(org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(
                            tempAttribUhash));
                } else {
                }

                handledAttributes.add("uhash");

                // handle attribute "pcid"
                java.lang.String tempAttribPcid = reader.getAttributeValue(null,
                        "pcid");

                if (tempAttribPcid != null) {
                    java.lang.String content = tempAttribPcid;

                    object.setPcid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribPcid));
                } else {
                    object.setPcid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("pcid");

                // handle attribute "durl"
                java.lang.String tempAttribDurl = reader.getAttributeValue(null,
                        "durl");

                if (tempAttribDurl != null) {
                    java.lang.String content = tempAttribDurl;

                    object.setDurl(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribDurl));
                } else {
                }

                handledAttributes.add("durl");

                // handle attribute "shelvedurl"
                java.lang.String tempAttribShelvedurl = reader.getAttributeValue(null,
                        "shelvedurl");

                if (tempAttribShelvedurl != null) {
                    java.lang.String content = tempAttribShelvedurl;

                    object.setShelvedurl(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribShelvedurl));
                } else {
                }

                handledAttributes.add("shelvedurl");

                reader.next();
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
