/**
 * Failure.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;


/**
 *  Failure bean class
 */
public class Failure implements org.apache.axis2.databinding.ADBBean {
    /**
     * field for Warnings
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWarning localWarnings;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localWarningsTracker = false;

    /**
     * field for Message
     */
    protected java.lang.String localMessage;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMessageTracker = false;

    /**
     * field for Req
     * This was an Attribute!
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType localReq;

    /**
     * field for Code
     * This was an Attribute!
     */
    protected java.lang.String localCode;

    /**
     * field for Sev
     * This was an Attribute!
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType localSev;

    /**
     * field for Computer
     * This was an Attribute!
     */
    protected java.lang.String localComputer;

    /**
     * field for Ident
     * This was an Attribute!
     */
    protected java.lang.String localIdent;

    /**
     * field for Local
     * This was an Attribute!
     */
    protected java.lang.String localLocal;

    /**
     * field for Res
     * This was an Attribute!
     */
    protected java.lang.String localRes;

    /**
     * field for Item
     * This was an Attribute!
     */
    protected java.lang.String localItem;

    /**
     * field for Itemid
     * This was an Attribute!
     */
    protected int localItemid;

    /**
     * field for Ws
     * This was an Attribute!
     */
    protected java.lang.String localWs;

    /**
     * field for Owner
     * This was an Attribute!
     */
    protected java.lang.String localOwner;

    /* This type was generated from the piece of schema that had
       name = Failure
       Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
       Namespace Prefix =
     */
    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")) {
            return "";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWarning
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWarning getWarnings() {
        return localWarnings;
    }

    /**
     * Auto generated setter method
     * @param param Warnings
     */
    public void setWarnings(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWarning param) {
        if (param != null) {
            //update the setting tracker
            localWarningsTracker = true;
        } else {
            localWarningsTracker = false;
        }

        this.localWarnings = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getMessage() {
        return localMessage;
    }

    /**
     * Auto generated setter method
     * @param param Message
     */
    public void setMessage(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localMessageTracker = true;
        } else {
            localMessageTracker = false;
        }

        this.localMessage = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType getReq() {
        return localReq;
    }

    /**
     * Auto generated setter method
     * @param param Req
     */
    public void setReq(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType param) {
        this.localReq = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getCode() {
        return localCode;
    }

    /**
     * Auto generated setter method
     * @param param Code
     */
    public void setCode(java.lang.String param) {
        this.localCode = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType getSev() {
        return localSev;
    }

    /**
     * Auto generated setter method
     * @param param Sev
     */
    public void setSev(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType param) {
        this.localSev = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getComputer() {
        return localComputer;
    }

    /**
     * Auto generated setter method
     * @param param Computer
     */
    public void setComputer(java.lang.String param) {
        this.localComputer = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getIdent() {
        return localIdent;
    }

    /**
     * Auto generated setter method
     * @param param Ident
     */
    public void setIdent(java.lang.String param) {
        this.localIdent = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getLocal() {
        return localLocal;
    }

    /**
     * Auto generated setter method
     * @param param Local
     */
    public void setLocal(java.lang.String param) {
        this.localLocal = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getRes() {
        return localRes;
    }

    /**
     * Auto generated setter method
     * @param param Res
     */
    public void setRes(java.lang.String param) {
        this.localRes = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getItem() {
        return localItem;
    }

    /**
     * Auto generated setter method
     * @param param Item
     */
    public void setItem(java.lang.String param) {
        this.localItem = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getItemid() {
        return localItemid;
    }

    /**
     * Auto generated setter method
     * @param param Itemid
     */
    public void setItemid(int param) {
        this.localItemid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getWs() {
        return localWs;
    }

    /**
     * Auto generated setter method
     * @param param Ws
     */
    public void setWs(java.lang.String param) {
        this.localWs = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getOwner() {
        return localOwner;
    }

    /**
     * Auto generated setter method
     * @param param Owner
     */
    public void setOwner(java.lang.String param) {
        this.localOwner = param;
    }

    /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
    public static boolean isReaderMTOMAware(
        javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;

        try {
            isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(
                        org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        } catch (java.lang.IllegalArgumentException e) {
            isReaderMTOMAware = false;
        }

        return isReaderMTOMAware;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        org.apache.axiom.om.OMDataSource dataSource = new org.apache.axis2.databinding.ADBDataSource(this,
                parentQName) {
                public void serialize(
                    org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                    throws javax.xml.stream.XMLStreamException {
                    Failure.this.serialize(parentQName, factory, xmlWriter);
                }
            };

        return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(parentQName,
            factory, dataSource);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory,
        org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();

        if (namespace != null) {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace,
                    parentQName.getLocalPart());
            } else {
                if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(),
                    namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        } else {
            xmlWriter.writeStartElement(parentQName.getLocalPart());
        }

        if (localReq != null) {
            writeAttribute("", "req", localReq.toString(), xmlWriter);
        }

        if (localCode != null) {
            writeAttribute("", "code",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localCode), xmlWriter);
        }

        if (localSev != null) {
            writeAttribute("", "sev", localSev.toString(), xmlWriter);
        }

        if (localComputer != null) {
            writeAttribute("", "computer",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localComputer), xmlWriter);
        }

        if (localIdent != null) {
            writeAttribute("", "ident",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localIdent), xmlWriter);
        }

        if (localLocal != null) {
            writeAttribute("", "local",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localLocal), xmlWriter);
        }

        if (localRes != null) {
            writeAttribute("", "res",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localRes), xmlWriter);
        }

        if (localItem != null) {
            writeAttribute("", "item",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localItem), xmlWriter);
        }

        if (localItemid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "itemid",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localItemid), xmlWriter);
        }

        if (localWs != null) {
            writeAttribute("", "ws",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localWs), xmlWriter);
        }

        if (localOwner != null) {
            writeAttribute("", "owner",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localOwner), xmlWriter);
        }

        if (localWarningsTracker) {
            if (localWarnings == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Warnings cannot be null!!");
            }

            localWarnings.serialize(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "Warnings"), factory, xmlWriter);
        }

        if (localMessageTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "Message", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "Message");
                }
            } else {
                xmlWriter.writeStartElement("Message");
            }

            if (localMessage == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "Message cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localMessage);
            }

            xmlWriter.writeEndElement();
        }

        xmlWriter.writeEndElement();
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     * databinding method to get an XML representation of this object
     *
     */
    public javax.xml.stream.XMLStreamReader getPullParser(
        javax.xml.namespace.QName qName)
        throws org.apache.axis2.databinding.ADBException {
        java.util.ArrayList elementList = new java.util.ArrayList();
        java.util.ArrayList attribList = new java.util.ArrayList();

        if (localWarningsTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "Warnings"));

            if (localWarnings == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Warnings cannot be null!!");
            }

            elementList.add(localWarnings);
        }

        if (localMessageTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "Message"));

            if (localMessage != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localMessage));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "Message cannot be null!!");
            }
        }

        attribList.add(new javax.xml.namespace.QName("", "req"));

        attribList.add(localReq.toString());

        attribList.add(new javax.xml.namespace.QName("", "code"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localCode));

        attribList.add(new javax.xml.namespace.QName("", "sev"));

        attribList.add(localSev.toString());

        attribList.add(new javax.xml.namespace.QName("", "computer"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localComputer));

        attribList.add(new javax.xml.namespace.QName("", "ident"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localIdent));

        attribList.add(new javax.xml.namespace.QName("", "local"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localLocal));

        attribList.add(new javax.xml.namespace.QName("", "res"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localRes));

        attribList.add(new javax.xml.namespace.QName("", "item"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localItem));

        attribList.add(new javax.xml.namespace.QName("", "itemid"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localItemid));

        attribList.add(new javax.xml.namespace.QName("", "ws"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localWs));

        attribList.add(new javax.xml.namespace.QName("", "owner"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localOwner));

        return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
            elementList.toArray(), attribList.toArray());
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static Failure parse(javax.xml.stream.XMLStreamReader reader)
            throws java.lang.Exception {
            Failure object = new Failure();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"Failure".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (Failure) org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                // handle attribute "req"
                java.lang.String tempAttribReq = reader.getAttributeValue(null,
                        "req");

                if (tempAttribReq != null) {
                    java.lang.String content = tempAttribReq;

                    if (tempAttribReq.indexOf(":") > 0) {
                        // this seems to be a Qname so find the namespace and send
                        prefix = tempAttribReq.substring(0,
                                tempAttribReq.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object.setReq(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType.Factory.fromString(
                                tempAttribReq, namespaceuri));
                    } else {
                        // this seems to be not a qname send and empty namespace incase of it is
                        // check is done in fromString method
                        object.setReq(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType.Factory.fromString(
                                tempAttribReq, ""));
                    }
                } else {
                }

                handledAttributes.add("req");

                // handle attribute "code"
                java.lang.String tempAttribCode = reader.getAttributeValue(null,
                        "code");

                if (tempAttribCode != null) {
                    java.lang.String content = tempAttribCode;

                    object.setCode(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribCode));
                } else {
                }

                handledAttributes.add("code");

                // handle attribute "sev"
                java.lang.String tempAttribSev = reader.getAttributeValue(null,
                        "sev");

                if (tempAttribSev != null) {
                    java.lang.String content = tempAttribSev;

                    if (tempAttribSev.indexOf(":") > 0) {
                        // this seems to be a Qname so find the namespace and send
                        prefix = tempAttribSev.substring(0,
                                tempAttribSev.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object.setSev(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType.Factory.fromString(
                                tempAttribSev, namespaceuri));
                    } else {
                        // this seems to be not a qname send and empty namespace incase of it is
                        // check is done in fromString method
                        object.setSev(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType.Factory.fromString(
                                tempAttribSev, ""));
                    }
                } else {
                }

                handledAttributes.add("sev");

                // handle attribute "computer"
                java.lang.String tempAttribComputer = reader.getAttributeValue(null,
                        "computer");

                if (tempAttribComputer != null) {
                    java.lang.String content = tempAttribComputer;

                    object.setComputer(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribComputer));
                } else {
                }

                handledAttributes.add("computer");

                // handle attribute "ident"
                java.lang.String tempAttribIdent = reader.getAttributeValue(null,
                        "ident");

                if (tempAttribIdent != null) {
                    java.lang.String content = tempAttribIdent;

                    object.setIdent(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribIdent));
                } else {
                }

                handledAttributes.add("ident");

                // handle attribute "local"
                java.lang.String tempAttribLocal = reader.getAttributeValue(null,
                        "local");

                if (tempAttribLocal != null) {
                    java.lang.String content = tempAttribLocal;

                    object.setLocal(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribLocal));
                } else {
                }

                handledAttributes.add("local");

                // handle attribute "res"
                java.lang.String tempAttribRes = reader.getAttributeValue(null,
                        "res");

                if (tempAttribRes != null) {
                    java.lang.String content = tempAttribRes;

                    object.setRes(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribRes));
                } else {
                }

                handledAttributes.add("res");

                // handle attribute "item"
                java.lang.String tempAttribItem = reader.getAttributeValue(null,
                        "item");

                if (tempAttribItem != null) {
                    java.lang.String content = tempAttribItem;

                    object.setItem(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribItem));
                } else {
                }

                handledAttributes.add("item");

                // handle attribute "itemid"
                java.lang.String tempAttribItemid = reader.getAttributeValue(null,
                        "itemid");

                if (tempAttribItemid != null) {
                    java.lang.String content = tempAttribItemid;

                    object.setItemid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribItemid));
                } else {
                    object.setItemid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("itemid");

                // handle attribute "ws"
                java.lang.String tempAttribWs = reader.getAttributeValue(null,
                        "ws");

                if (tempAttribWs != null) {
                    java.lang.String content = tempAttribWs;

                    object.setWs(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribWs));
                } else {
                }

                handledAttributes.add("ws");

                // handle attribute "owner"
                java.lang.String tempAttribOwner = reader.getAttributeValue(null,
                        "owner");

                if (tempAttribOwner != null) {
                    java.lang.String content = tempAttribOwner;

                    object.setOwner(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribOwner));
                } else {
                }

                handledAttributes.add("owner");

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "Warnings").equals(reader.getName())) {
                    object.setWarnings(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWarning.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "Message").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setMessage(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
