
/**
 * Item.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */
            
                package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;
            

            /**
            *  Item bean class
            */
        
        public  class Item
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = Item
                Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for Cs
                        * This was an Attribute!
                        */

                        
                                    protected int localCs =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getCs(){
                               return localCs;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Cs
                               */
                               public void setCs(int param){
                            
                                            this.localCs=param;
                                    

                               }
                            

                        /**
                        * field for Date
                        * This was an Attribute!
                        */

                        
                                    protected java.util.Calendar localDate ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getDate(){
                               return localDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Date
                               */
                               public void setDate(java.util.Calendar param){
                            
                                            this.localDate=param;
                                    

                               }
                            

                        /**
                        * field for Did
                        * This was an Attribute!
                        */

                        
                                    protected int localDid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getDid(){
                               return localDid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Did
                               */
                               public void setDid(int param){
                            
                                            this.localDid=param;
                                    

                               }
                            

                        /**
                        * field for Enc
                        * This was an Attribute!
                        */

                        
                                    protected int localEnc =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("-2");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getEnc(){
                               return localEnc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Enc
                               */
                               public void setEnc(int param){
                            
                                            this.localEnc=param;
                                    

                               }
                            

                        /**
                        * field for Type
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localType ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getType(){
                               return localType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Type
                               */
                               public void setType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param){
                            
                                            this.localType=param;
                                    

                               }
                            

                        /**
                        * field for Itemid
                        * This was an Attribute!
                        */

                        
                                    protected int localItemid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getItemid(){
                               return localItemid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Itemid
                               */
                               public void setItemid(int param){
                            
                                            this.localItemid=param;
                                    

                               }
                            

                        /**
                        * field for Item
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localItem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getItem(){
                               return localItem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Item
                               */
                               public void setItem(java.lang.String param){
                            
                                            this.localItem=param;
                                    

                               }
                            

                        /**
                        * field for Tz
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localTz ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTz(){
                               return localTz;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tz
                               */
                               public void setTz(java.lang.String param){
                            
                                            this.localTz=param;
                                    

                               }
                            

                        /**
                        * field for Tzo
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localTzo ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTzo(){
                               return localTzo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tzo
                               */
                               public void setTzo(java.lang.String param){
                            
                                            this.localTzo=param;
                                    

                               }
                            

                        /**
                        * field for Hash
                        * This was an Attribute!
                        */

                        
                                    protected javax.activation.DataHandler localHash ;
                                

                           /**
                           * Auto generated getter method
                           * @return javax.activation.DataHandler
                           */
                           public  javax.activation.DataHandler getHash(){
                               return localHash;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Hash
                               */
                               public void setHash(javax.activation.DataHandler param){
                            
                                            this.localHash=param;
                                    

                               }
                            

                        /**
                        * field for Len
                        * This was an Attribute!
                        */

                        
                                    protected long localLen =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong("0");
                                

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getLen(){
                               return localLen;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Len
                               */
                               public void setLen(long param){
                            
                                            this.localLen=param;
                                    

                               }
                            

                        /**
                        * field for Durl
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localDurl ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getDurl(){
                               return localDurl;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Durl
                               */
                               public void setDurl(java.lang.String param){
                            
                                            this.localDurl=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       Item.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":Item",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "Item",
                           xmlWriter);
                   }

               
                   }
               
                                                   if (localCs!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "cs",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCs), xmlWriter);

                                            
                                      }
                                    
                                            if (localDate != null){
                                        
                                                writeAttribute("",
                                                         "date",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDate), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localDate is null");
                                      }
                                    
                                                   if (localDid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "did",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDid), xmlWriter);

                                            
                                      }
                                    
                                                   if (localEnc!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "enc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnc), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localType != null){
                                        writeAttribute("",
                                           "type",
                                           localType.toString(), xmlWriter);
                                    }
                                    
                                                   if (localItemid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "itemid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItemid), xmlWriter);

                                            
                                      }
                                    
                                            if (localItem != null){
                                        
                                                writeAttribute("",
                                                         "item",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItem), xmlWriter);

                                            
                                      }
                                    
                                            if (localTz != null){
                                        
                                                writeAttribute("",
                                                         "tz",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTz), xmlWriter);

                                            
                                      }
                                    
                                            if (localTzo != null){
                                        
                                                writeAttribute("",
                                                         "tzo",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTzo), xmlWriter);

                                            
                                      }
                                    
                                            if (localHash != null){
                                        
                                                writeAttribute("",
                                                         "hash",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localHash), xmlWriter);

                                            
                                      }
                                    
                                                   if (localLen!=java.lang.Long.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "len",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLen), xmlWriter);

                                            
                                      }
                                    
                                            if (localDurl != null){
                                        
                                                writeAttribute("",
                                                         "durl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDurl), xmlWriter);

                                            
                                      }
                                    
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                            attribList.add(
                            new javax.xml.namespace.QName("","cs"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCs));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","date"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDate));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","did"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","enc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","type"));
                            
                                      attribList.add(localType.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","itemid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItemid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","item"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tz"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTz));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tzo"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTzo));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","hash"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localHash));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","len"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLen));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","durl"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDurl));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static Item parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            Item object =
                new Item();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"Item".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (Item)org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "cs"
                    java.lang.String tempAttribCs =
                        
                                reader.getAttributeValue(null,"cs");
                            
                   if (tempAttribCs!=null){
                         java.lang.String content = tempAttribCs;
                        
                                                 object.setCs(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribCs));
                                            
                    } else {
                       
                                           object.setCs(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("cs");
                    
                    // handle attribute "date"
                    java.lang.String tempAttribDate =
                        
                                reader.getAttributeValue(null,"date");
                            
                   if (tempAttribDate!=null){
                         java.lang.String content = tempAttribDate;
                        
                                                 object.setDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(tempAttribDate));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute date is missing");
                           
                    }
                    handledAttributes.add("date");
                    
                    // handle attribute "did"
                    java.lang.String tempAttribDid =
                        
                                reader.getAttributeValue(null,"did");
                            
                   if (tempAttribDid!=null){
                         java.lang.String content = tempAttribDid;
                        
                                                 object.setDid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribDid));
                                            
                    } else {
                       
                                           object.setDid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("did");
                    
                    // handle attribute "enc"
                    java.lang.String tempAttribEnc =
                        
                                reader.getAttributeValue(null,"enc");
                            
                   if (tempAttribEnc!=null){
                         java.lang.String content = tempAttribEnc;
                        
                                                 object.setEnc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribEnc));
                                            
                    } else {
                       
                                           object.setEnc(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("enc");
                    
                    // handle attribute "type"
                    java.lang.String tempAttribType =
                        
                                reader.getAttributeValue(null,"type");
                            
                   if (tempAttribType!=null){
                         java.lang.String content = tempAttribType;
                        
                                                  object.setType(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(reader,tempAttribType));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("type");
                    
                    // handle attribute "itemid"
                    java.lang.String tempAttribItemid =
                        
                                reader.getAttributeValue(null,"itemid");
                            
                   if (tempAttribItemid!=null){
                         java.lang.String content = tempAttribItemid;
                        
                                                 object.setItemid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribItemid));
                                            
                    } else {
                       
                                           object.setItemid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("itemid");
                    
                    // handle attribute "item"
                    java.lang.String tempAttribItem =
                        
                                reader.getAttributeValue(null,"item");
                            
                   if (tempAttribItem!=null){
                         java.lang.String content = tempAttribItem;
                        
                                                 object.setItem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribItem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("item");
                    
                    // handle attribute "tz"
                    java.lang.String tempAttribTz =
                        
                                reader.getAttributeValue(null,"tz");
                            
                   if (tempAttribTz!=null){
                         java.lang.String content = tempAttribTz;
                        
                                                 object.setTz(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribTz));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("tz");
                    
                    // handle attribute "tzo"
                    java.lang.String tempAttribTzo =
                        
                                reader.getAttributeValue(null,"tzo");
                            
                   if (tempAttribTzo!=null){
                         java.lang.String content = tempAttribTzo;
                        
                                                 object.setTzo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribTzo));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("tzo");
                    
                    // handle attribute "hash"
                    java.lang.String tempAttribHash =
                        
                                reader.getAttributeValue(null,"hash");
                            
                   if (tempAttribHash!=null){
                         java.lang.String content = tempAttribHash;
                        
                                                 object.setHash(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(tempAttribHash));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("hash");
                    
                    // handle attribute "len"
                    java.lang.String tempAttribLen =
                        
                                reader.getAttributeValue(null,"len");
                            
                   if (tempAttribLen!=null){
                         java.lang.String content = tempAttribLen;
                        
                                                 object.setLen(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(tempAttribLen));
                                            
                    } else {
                       
                                           object.setLen(java.lang.Long.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("len");
                    
                    // handle attribute "durl"
                    java.lang.String tempAttribDurl =
                        
                                reader.getAttributeValue(null,"durl");
                            
                   if (tempAttribDurl!=null){
                         java.lang.String content = tempAttribDurl;
                        
                                                 object.setDurl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribDurl));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("durl");
                    
                    
                    reader.next();
                



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          