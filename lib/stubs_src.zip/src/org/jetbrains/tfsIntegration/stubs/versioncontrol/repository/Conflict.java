
/**
 * Conflict.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */
            
                package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;
            

            /**
            *  Conflict bean class
            */
        
        public  class Conflict
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = Conflict
                Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for Cid
                        * This was an Attribute!
                        */

                        
                                    protected int localCid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getCid(){
                               return localCid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Cid
                               */
                               public void setCid(int param){
                            
                                            this.localCid=param;
                                    

                               }
                            

                        /**
                        * field for Pcid
                        * This was an Attribute!
                        */

                        
                                    protected int localPcid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getPcid(){
                               return localPcid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Pcid
                               */
                               public void setPcid(int param){
                            
                                            this.localPcid=param;
                                    

                               }
                            

                        /**
                        * field for Ychg
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localYchg ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getYchg(){
                               return localYchg;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ychg
                               */
                               public void setYchg(java.lang.String param){
                            
                                            this.localYchg=param;
                                    

                               }
                            

                        /**
                        * field for Ysitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localYsitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getYsitem(){
                               return localYsitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ysitem
                               */
                               public void setYsitem(java.lang.String param){
                            
                                            this.localYsitem=param;
                                    

                               }
                            

                        /**
                        * field for Ysitemsrc
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localYsitemsrc ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getYsitemsrc(){
                               return localYsitemsrc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ysitemsrc
                               */
                               public void setYsitemsrc(java.lang.String param){
                            
                                            this.localYsitemsrc=param;
                                    

                               }
                            

                        /**
                        * field for Yenc
                        * This was an Attribute!
                        */

                        
                                    protected int localYenc ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getYenc(){
                               return localYenc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Yenc
                               */
                               public void setYenc(int param){
                            
                                            this.localYenc=param;
                                    

                               }
                            

                        /**
                        * field for Ytype
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localYtype ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getYtype(){
                               return localYtype;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ytype
                               */
                               public void setYtype(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param){
                            
                                            this.localYtype=param;
                                    

                               }
                            

                        /**
                        * field for Yver
                        * This was an Attribute!
                        */

                        
                                    protected int localYver ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getYver(){
                               return localYver;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Yver
                               */
                               public void setYver(int param){
                            
                                            this.localYver=param;
                                    

                               }
                            

                        /**
                        * field for Yitemid
                        * This was an Attribute!
                        */

                        
                                    protected int localYitemid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getYitemid(){
                               return localYitemid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Yitemid
                               */
                               public void setYitemid(int param){
                            
                                            this.localYitemid=param;
                                    

                               }
                            

                        /**
                        * field for Ydid
                        * This was an Attribute!
                        */

                        
                                    protected int localYdid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getYdid(){
                               return localYdid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ydid
                               */
                               public void setYdid(int param){
                            
                                            this.localYdid=param;
                                    

                               }
                            

                        /**
                        * field for Ylchg
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localYlchg ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getYlchg(){
                               return localYlchg;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ylchg
                               */
                               public void setYlchg(java.lang.String param){
                            
                                            this.localYlchg=param;
                                    

                               }
                            

                        /**
                        * field for Ylmver
                        * This was an Attribute!
                        */

                        
                                    protected int localYlmver ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getYlmver(){
                               return localYlmver;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ylmver
                               */
                               public void setYlmver(int param){
                            
                                            this.localYlmver=param;
                                    

                               }
                            

                        /**
                        * field for Bsitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localBsitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getBsitem(){
                               return localBsitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bsitem
                               */
                               public void setBsitem(java.lang.String param){
                            
                                            this.localBsitem=param;
                                    

                               }
                            

                        /**
                        * field for Benc
                        * This was an Attribute!
                        */

                        
                                    protected int localBenc ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getBenc(){
                               return localBenc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Benc
                               */
                               public void setBenc(int param){
                            
                                            this.localBenc=param;
                                    

                               }
                            

                        /**
                        * field for Bitemid
                        * This was an Attribute!
                        */

                        
                                    protected int localBitemid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getBitemid(){
                               return localBitemid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bitemid
                               */
                               public void setBitemid(int param){
                            
                                            this.localBitemid=param;
                                    

                               }
                            

                        /**
                        * field for Bver
                        * This was an Attribute!
                        */

                        
                                    protected int localBver ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getBver(){
                               return localBver;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bver
                               */
                               public void setBver(int param){
                            
                                            this.localBver=param;
                                    

                               }
                            

                        /**
                        * field for Bhash
                        * This was an Attribute!
                        */

                        
                                    protected javax.activation.DataHandler localBhash ;
                                

                           /**
                           * Auto generated getter method
                           * @return javax.activation.DataHandler
                           */
                           public  javax.activation.DataHandler getBhash(){
                               return localBhash;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bhash
                               */
                               public void setBhash(javax.activation.DataHandler param){
                            
                                            this.localBhash=param;
                                    

                               }
                            

                        /**
                        * field for Bdid
                        * This was an Attribute!
                        */

                        
                                    protected int localBdid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getBdid(){
                               return localBdid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bdid
                               */
                               public void setBdid(int param){
                            
                                            this.localBdid=param;
                                    

                               }
                            

                        /**
                        * field for Btype
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localBtype ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getBtype(){
                               return localBtype;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Btype
                               */
                               public void setBtype(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param){
                            
                                            this.localBtype=param;
                                    

                               }
                            

                        /**
                        * field for Bchg
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localBchg ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getBchg(){
                               return localBchg;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bchg
                               */
                               public void setBchg(java.lang.String param){
                            
                                            this.localBchg=param;
                                    

                               }
                            

                        /**
                        * field for Titemid
                        * This was an Attribute!
                        */

                        
                                    protected int localTitemid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getTitemid(){
                               return localTitemid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Titemid
                               */
                               public void setTitemid(int param){
                            
                                            this.localTitemid=param;
                                    

                               }
                            

                        /**
                        * field for Tver
                        * This was an Attribute!
                        */

                        
                                    protected int localTver ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getTver(){
                               return localTver;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tver
                               */
                               public void setTver(int param){
                            
                                            this.localTver=param;
                                    

                               }
                            

                        /**
                        * field for Tsitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localTsitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTsitem(){
                               return localTsitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tsitem
                               */
                               public void setTsitem(java.lang.String param){
                            
                                            this.localTsitem=param;
                                    

                               }
                            

                        /**
                        * field for Tenc
                        * This was an Attribute!
                        */

                        
                                    protected int localTenc ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getTenc(){
                               return localTenc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tenc
                               */
                               public void setTenc(int param){
                            
                                            this.localTenc=param;
                                    

                               }
                            

                        /**
                        * field for Thash
                        * This was an Attribute!
                        */

                        
                                    protected javax.activation.DataHandler localThash ;
                                

                           /**
                           * Auto generated getter method
                           * @return javax.activation.DataHandler
                           */
                           public  javax.activation.DataHandler getThash(){
                               return localThash;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Thash
                               */
                               public void setThash(javax.activation.DataHandler param){
                            
                                            this.localThash=param;
                                    

                               }
                            

                        /**
                        * field for Tdid
                        * This was an Attribute!
                        */

                        
                                    protected int localTdid ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getTdid(){
                               return localTdid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tdid
                               */
                               public void setTdid(int param){
                            
                                            this.localTdid=param;
                                    

                               }
                            

                        /**
                        * field for Ttype
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localTtype ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getTtype(){
                               return localTtype;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ttype
                               */
                               public void setTtype(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param){
                            
                                            this.localTtype=param;
                                    

                               }
                            

                        /**
                        * field for Tlmver
                        * This was an Attribute!
                        */

                        
                                    protected int localTlmver ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getTlmver(){
                               return localTlmver;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tlmver
                               */
                               public void setTlmver(int param){
                            
                                            this.localTlmver=param;
                                    

                               }
                            

                        /**
                        * field for Srclitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localSrclitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSrclitem(){
                               return localSrclitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Srclitem
                               */
                               public void setSrclitem(java.lang.String param){
                            
                                            this.localSrclitem=param;
                                    

                               }
                            

                        /**
                        * field for Tgtlitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localTgtlitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTgtlitem(){
                               return localTgtlitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tgtlitem
                               */
                               public void setTgtlitem(java.lang.String param){
                            
                                            this.localTgtlitem=param;
                                    

                               }
                            

                        /**
                        * field for Ctype
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType localCtype ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType getCtype(){
                               return localCtype;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ctype
                               */
                               public void setCtype(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType param){
                            
                                            this.localCtype=param;
                                    

                               }
                            

                        /**
                        * field for Reason
                        * This was an Attribute!
                        */

                        
                                    protected int localReason ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getReason(){
                               return localReason;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Reason
                               */
                               public void setReason(int param){
                            
                                            this.localReason=param;
                                    

                               }
                            

                        /**
                        * field for Isnamecflict
                        * This was an Attribute!
                        */

                        
                                    protected boolean localIsnamecflict ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getIsnamecflict(){
                               return localIsnamecflict;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Isnamecflict
                               */
                               public void setIsnamecflict(boolean param){
                            
                                            this.localIsnamecflict=param;
                                    

                               }
                            

                        /**
                        * field for Isforced
                        * This was an Attribute!
                        */

                        
                                    protected boolean localIsforced ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getIsforced(){
                               return localIsforced;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Isforced
                               */
                               public void setIsforced(boolean param){
                            
                                            this.localIsforced=param;
                                    

                               }
                            

                        /**
                        * field for Res
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution localRes ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution getRes(){
                               return localRes;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Res
                               */
                               public void setRes(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution param){
                            
                                            this.localRes=param;
                                    

                               }
                            

                        /**
                        * field for Isresolved
                        * This was an Attribute!
                        */

                        
                                    protected boolean localIsresolved ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getIsresolved(){
                               return localIsresolved;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Isresolved
                               */
                               public void setIsresolved(boolean param){
                            
                                            this.localIsresolved=param;
                                    

                               }
                            

                        /**
                        * field for Bdurl
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localBdurl ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getBdurl(){
                               return localBdurl;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Bdurl
                               */
                               public void setBdurl(java.lang.String param){
                            
                                            this.localBdurl=param;
                                    

                               }
                            

                        /**
                        * field for Tdurl
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localTdurl ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTdurl(){
                               return localTdurl;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Tdurl
                               */
                               public void setTdurl(java.lang.String param){
                            
                                            this.localTdurl=param;
                                    

                               }
                            

                        /**
                        * field for Ydurl
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localYdurl ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getYdurl(){
                               return localYdurl;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ydurl
                               */
                               public void setYdurl(java.lang.String param){
                            
                                            this.localYdurl=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       Conflict.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":Conflict",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "Conflict",
                           xmlWriter);
                   }

               
                   }
               
                                                   if (localCid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "cid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localCid is null");
                                      }
                                    
                                                   if (localPcid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "pcid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPcid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localPcid is null");
                                      }
                                    
                                            if (localYchg != null){
                                        
                                                writeAttribute("",
                                                         "ychg",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYchg), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYchg is null");
                                      }
                                    
                                            if (localYsitem != null){
                                        
                                                writeAttribute("",
                                                         "ysitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYsitem), xmlWriter);

                                            
                                      }
                                    
                                            if (localYsitemsrc != null){
                                        
                                                writeAttribute("",
                                                         "ysitemsrc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYsitemsrc), xmlWriter);

                                            
                                      }
                                    
                                                   if (localYenc!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "yenc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYenc), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYenc is null");
                                      }
                                    
                                    
                                    if (localYtype != null){
                                        writeAttribute("",
                                           "ytype",
                                           localYtype.toString(), xmlWriter);
                                    }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYtype is null");
                                      }
                                    
                                                   if (localYver!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "yver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYver), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYver is null");
                                      }
                                    
                                                   if (localYitemid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "yitemid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYitemid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYitemid is null");
                                      }
                                    
                                                   if (localYdid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "ydid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYdid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYdid is null");
                                      }
                                    
                                            if (localYlchg != null){
                                        
                                                writeAttribute("",
                                                         "ylchg",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYlchg), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYlchg is null");
                                      }
                                    
                                                   if (localYlmver!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "ylmver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYlmver), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localYlmver is null");
                                      }
                                    
                                            if (localBsitem != null){
                                        
                                                writeAttribute("",
                                                         "bsitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBsitem), xmlWriter);

                                            
                                      }
                                    
                                                   if (localBenc!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "benc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBenc), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localBenc is null");
                                      }
                                    
                                                   if (localBitemid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "bitemid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBitemid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localBitemid is null");
                                      }
                                    
                                                   if (localBver!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "bver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBver), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localBver is null");
                                      }
                                    
                                            if (localBhash != null){
                                        
                                                writeAttribute("",
                                                         "bhash",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBhash), xmlWriter);

                                            
                                      }
                                    
                                                   if (localBdid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "bdid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBdid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localBdid is null");
                                      }
                                    
                                    
                                    if (localBtype != null){
                                        writeAttribute("",
                                           "btype",
                                           localBtype.toString(), xmlWriter);
                                    }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localBtype is null");
                                      }
                                    
                                            if (localBchg != null){
                                        
                                                writeAttribute("",
                                                         "bchg",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBchg), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localBchg is null");
                                      }
                                    
                                                   if (localTitemid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "titemid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTitemid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localTitemid is null");
                                      }
                                    
                                                   if (localTver!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "tver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTver), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localTver is null");
                                      }
                                    
                                            if (localTsitem != null){
                                        
                                                writeAttribute("",
                                                         "tsitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTsitem), xmlWriter);

                                            
                                      }
                                    
                                                   if (localTenc!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "tenc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTenc), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localTenc is null");
                                      }
                                    
                                            if (localThash != null){
                                        
                                                writeAttribute("",
                                                         "thash",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localThash), xmlWriter);

                                            
                                      }
                                    
                                                   if (localTdid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "tdid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTdid), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localTdid is null");
                                      }
                                    
                                    
                                    if (localTtype != null){
                                        writeAttribute("",
                                           "ttype",
                                           localTtype.toString(), xmlWriter);
                                    }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localTtype is null");
                                      }
                                    
                                                   if (localTlmver!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "tlmver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTlmver), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localTlmver is null");
                                      }
                                    
                                            if (localSrclitem != null){
                                        
                                                writeAttribute("",
                                                         "srclitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSrclitem), xmlWriter);

                                            
                                      }
                                    
                                            if (localTgtlitem != null){
                                        
                                                writeAttribute("",
                                                         "tgtlitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTgtlitem), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localCtype != null){
                                        writeAttribute("",
                                           "ctype",
                                           localCtype.toString(), xmlWriter);
                                    }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localCtype is null");
                                      }
                                    
                                                   if (localReason!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "reason",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReason), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localReason is null");
                                      }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "isnamecflict",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIsnamecflict), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localIsnamecflict is null");
                                      }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "isforced",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIsforced), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localIsforced is null");
                                      }
                                    
                                    
                                    if (localRes != null){
                                        writeAttribute("",
                                           "res",
                                           localRes.toString(), xmlWriter);
                                    }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "isresolved",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIsresolved), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localIsresolved is null");
                                      }
                                    
                                            if (localBdurl != null){
                                        
                                                writeAttribute("",
                                                         "bdurl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBdurl), xmlWriter);

                                            
                                      }
                                    
                                            if (localTdurl != null){
                                        
                                                writeAttribute("",
                                                         "tdurl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTdurl), xmlWriter);

                                            
                                      }
                                    
                                            if (localYdurl != null){
                                        
                                                writeAttribute("",
                                                         "ydurl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYdurl), xmlWriter);

                                            
                                      }
                                    
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                            attribList.add(
                            new javax.xml.namespace.QName("","cid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","pcid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPcid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ychg"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYchg));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ysitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYsitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ysitemsrc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYsitemsrc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","yenc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYenc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ytype"));
                            
                                      attribList.add(localYtype.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","yver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYver));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","yitemid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYitemid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ydid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYdid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ylchg"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYlchg));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ylmver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYlmver));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bsitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBsitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","benc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBenc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bitemid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBitemid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBver));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bhash"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBhash));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bdid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBdid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","btype"));
                            
                                      attribList.add(localBtype.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bchg"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBchg));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","titemid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTitemid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTver));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tsitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTsitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tenc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTenc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","thash"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localThash));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tdid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTdid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ttype"));
                            
                                      attribList.add(localTtype.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tlmver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTlmver));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","srclitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSrclitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tgtlitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTgtlitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ctype"));
                            
                                      attribList.add(localCtype.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","reason"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReason));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","isnamecflict"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIsnamecflict));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","isforced"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIsforced));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","res"));
                            
                                      attribList.add(localRes.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","isresolved"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIsresolved));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","bdurl"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBdurl));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","tdurl"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTdurl));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ydurl"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localYdurl));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static Conflict parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            Conflict object =
                new Conflict();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"Conflict".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (Conflict)org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "cid"
                    java.lang.String tempAttribCid =
                        
                                reader.getAttributeValue(null,"cid");
                            
                   if (tempAttribCid!=null){
                         java.lang.String content = tempAttribCid;
                        
                                                 object.setCid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribCid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute cid is missing");
                           
                    }
                    handledAttributes.add("cid");
                    
                    // handle attribute "pcid"
                    java.lang.String tempAttribPcid =
                        
                                reader.getAttributeValue(null,"pcid");
                            
                   if (tempAttribPcid!=null){
                         java.lang.String content = tempAttribPcid;
                        
                                                 object.setPcid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribPcid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute pcid is missing");
                           
                    }
                    handledAttributes.add("pcid");
                    
                    // handle attribute "ychg"
                    java.lang.String tempAttribYchg =
                        
                                reader.getAttributeValue(null,"ychg");
                            
                   if (tempAttribYchg!=null){
                         java.lang.String content = tempAttribYchg;
                        
                                                 object.setYchg(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribYchg));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ychg is missing");
                           
                    }
                    handledAttributes.add("ychg");
                    
                    // handle attribute "ysitem"
                    java.lang.String tempAttribYsitem =
                        
                                reader.getAttributeValue(null,"ysitem");
                            
                   if (tempAttribYsitem!=null){
                         java.lang.String content = tempAttribYsitem;
                        
                                                 object.setYsitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribYsitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ysitem");
                    
                    // handle attribute "ysitemsrc"
                    java.lang.String tempAttribYsitemsrc =
                        
                                reader.getAttributeValue(null,"ysitemsrc");
                            
                   if (tempAttribYsitemsrc!=null){
                         java.lang.String content = tempAttribYsitemsrc;
                        
                                                 object.setYsitemsrc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribYsitemsrc));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ysitemsrc");
                    
                    // handle attribute "yenc"
                    java.lang.String tempAttribYenc =
                        
                                reader.getAttributeValue(null,"yenc");
                            
                   if (tempAttribYenc!=null){
                         java.lang.String content = tempAttribYenc;
                        
                                                 object.setYenc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribYenc));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute yenc is missing");
                           
                    }
                    handledAttributes.add("yenc");
                    
                    // handle attribute "ytype"
                    java.lang.String tempAttribYtype =
                        
                                reader.getAttributeValue(null,"ytype");
                            
                   if (tempAttribYtype!=null){
                         java.lang.String content = tempAttribYtype;
                        
                                                  object.setYtype(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(reader,tempAttribYtype));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ytype is missing");
                           
                    }
                    handledAttributes.add("ytype");
                    
                    // handle attribute "yver"
                    java.lang.String tempAttribYver =
                        
                                reader.getAttributeValue(null,"yver");
                            
                   if (tempAttribYver!=null){
                         java.lang.String content = tempAttribYver;
                        
                                                 object.setYver(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribYver));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute yver is missing");
                           
                    }
                    handledAttributes.add("yver");
                    
                    // handle attribute "yitemid"
                    java.lang.String tempAttribYitemid =
                        
                                reader.getAttributeValue(null,"yitemid");
                            
                   if (tempAttribYitemid!=null){
                         java.lang.String content = tempAttribYitemid;
                        
                                                 object.setYitemid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribYitemid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute yitemid is missing");
                           
                    }
                    handledAttributes.add("yitemid");
                    
                    // handle attribute "ydid"
                    java.lang.String tempAttribYdid =
                        
                                reader.getAttributeValue(null,"ydid");
                            
                   if (tempAttribYdid!=null){
                         java.lang.String content = tempAttribYdid;
                        
                                                 object.setYdid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribYdid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ydid is missing");
                           
                    }
                    handledAttributes.add("ydid");
                    
                    // handle attribute "ylchg"
                    java.lang.String tempAttribYlchg =
                        
                                reader.getAttributeValue(null,"ylchg");
                            
                   if (tempAttribYlchg!=null){
                         java.lang.String content = tempAttribYlchg;
                        
                                                 object.setYlchg(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribYlchg));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ylchg is missing");
                           
                    }
                    handledAttributes.add("ylchg");
                    
                    // handle attribute "ylmver"
                    java.lang.String tempAttribYlmver =
                        
                                reader.getAttributeValue(null,"ylmver");
                            
                   if (tempAttribYlmver!=null){
                         java.lang.String content = tempAttribYlmver;
                        
                                                 object.setYlmver(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribYlmver));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ylmver is missing");
                           
                    }
                    handledAttributes.add("ylmver");
                    
                    // handle attribute "bsitem"
                    java.lang.String tempAttribBsitem =
                        
                                reader.getAttributeValue(null,"bsitem");
                            
                   if (tempAttribBsitem!=null){
                         java.lang.String content = tempAttribBsitem;
                        
                                                 object.setBsitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribBsitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("bsitem");
                    
                    // handle attribute "benc"
                    java.lang.String tempAttribBenc =
                        
                                reader.getAttributeValue(null,"benc");
                            
                   if (tempAttribBenc!=null){
                         java.lang.String content = tempAttribBenc;
                        
                                                 object.setBenc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribBenc));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute benc is missing");
                           
                    }
                    handledAttributes.add("benc");
                    
                    // handle attribute "bitemid"
                    java.lang.String tempAttribBitemid =
                        
                                reader.getAttributeValue(null,"bitemid");
                            
                   if (tempAttribBitemid!=null){
                         java.lang.String content = tempAttribBitemid;
                        
                                                 object.setBitemid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribBitemid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute bitemid is missing");
                           
                    }
                    handledAttributes.add("bitemid");
                    
                    // handle attribute "bver"
                    java.lang.String tempAttribBver =
                        
                                reader.getAttributeValue(null,"bver");
                            
                   if (tempAttribBver!=null){
                         java.lang.String content = tempAttribBver;
                        
                                                 object.setBver(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribBver));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute bver is missing");
                           
                    }
                    handledAttributes.add("bver");
                    
                    // handle attribute "bhash"
                    java.lang.String tempAttribBhash =
                        
                                reader.getAttributeValue(null,"bhash");
                            
                   if (tempAttribBhash!=null){
                         java.lang.String content = tempAttribBhash;
                        
                                                 object.setBhash(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(tempAttribBhash));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("bhash");
                    
                    // handle attribute "bdid"
                    java.lang.String tempAttribBdid =
                        
                                reader.getAttributeValue(null,"bdid");
                            
                   if (tempAttribBdid!=null){
                         java.lang.String content = tempAttribBdid;
                        
                                                 object.setBdid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribBdid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute bdid is missing");
                           
                    }
                    handledAttributes.add("bdid");
                    
                    // handle attribute "btype"
                    java.lang.String tempAttribBtype =
                        
                                reader.getAttributeValue(null,"btype");
                            
                   if (tempAttribBtype!=null){
                         java.lang.String content = tempAttribBtype;
                        
                                                  object.setBtype(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(reader,tempAttribBtype));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute btype is missing");
                           
                    }
                    handledAttributes.add("btype");
                    
                    // handle attribute "bchg"
                    java.lang.String tempAttribBchg =
                        
                                reader.getAttributeValue(null,"bchg");
                            
                   if (tempAttribBchg!=null){
                         java.lang.String content = tempAttribBchg;
                        
                                                 object.setBchg(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribBchg));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute bchg is missing");
                           
                    }
                    handledAttributes.add("bchg");
                    
                    // handle attribute "titemid"
                    java.lang.String tempAttribTitemid =
                        
                                reader.getAttributeValue(null,"titemid");
                            
                   if (tempAttribTitemid!=null){
                         java.lang.String content = tempAttribTitemid;
                        
                                                 object.setTitemid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribTitemid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute titemid is missing");
                           
                    }
                    handledAttributes.add("titemid");
                    
                    // handle attribute "tver"
                    java.lang.String tempAttribTver =
                        
                                reader.getAttributeValue(null,"tver");
                            
                   if (tempAttribTver!=null){
                         java.lang.String content = tempAttribTver;
                        
                                                 object.setTver(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribTver));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute tver is missing");
                           
                    }
                    handledAttributes.add("tver");
                    
                    // handle attribute "tsitem"
                    java.lang.String tempAttribTsitem =
                        
                                reader.getAttributeValue(null,"tsitem");
                            
                   if (tempAttribTsitem!=null){
                         java.lang.String content = tempAttribTsitem;
                        
                                                 object.setTsitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribTsitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("tsitem");
                    
                    // handle attribute "tenc"
                    java.lang.String tempAttribTenc =
                        
                                reader.getAttributeValue(null,"tenc");
                            
                   if (tempAttribTenc!=null){
                         java.lang.String content = tempAttribTenc;
                        
                                                 object.setTenc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribTenc));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute tenc is missing");
                           
                    }
                    handledAttributes.add("tenc");
                    
                    // handle attribute "thash"
                    java.lang.String tempAttribThash =
                        
                                reader.getAttributeValue(null,"thash");
                            
                   if (tempAttribThash!=null){
                         java.lang.String content = tempAttribThash;
                        
                                                 object.setThash(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(tempAttribThash));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("thash");
                    
                    // handle attribute "tdid"
                    java.lang.String tempAttribTdid =
                        
                                reader.getAttributeValue(null,"tdid");
                            
                   if (tempAttribTdid!=null){
                         java.lang.String content = tempAttribTdid;
                        
                                                 object.setTdid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribTdid));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute tdid is missing");
                           
                    }
                    handledAttributes.add("tdid");
                    
                    // handle attribute "ttype"
                    java.lang.String tempAttribTtype =
                        
                                reader.getAttributeValue(null,"ttype");
                            
                   if (tempAttribTtype!=null){
                         java.lang.String content = tempAttribTtype;
                        
                                                  object.setTtype(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(reader,tempAttribTtype));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ttype is missing");
                           
                    }
                    handledAttributes.add("ttype");
                    
                    // handle attribute "tlmver"
                    java.lang.String tempAttribTlmver =
                        
                                reader.getAttributeValue(null,"tlmver");
                            
                   if (tempAttribTlmver!=null){
                         java.lang.String content = tempAttribTlmver;
                        
                                                 object.setTlmver(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribTlmver));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute tlmver is missing");
                           
                    }
                    handledAttributes.add("tlmver");
                    
                    // handle attribute "srclitem"
                    java.lang.String tempAttribSrclitem =
                        
                                reader.getAttributeValue(null,"srclitem");
                            
                   if (tempAttribSrclitem!=null){
                         java.lang.String content = tempAttribSrclitem;
                        
                                                 object.setSrclitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribSrclitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("srclitem");
                    
                    // handle attribute "tgtlitem"
                    java.lang.String tempAttribTgtlitem =
                        
                                reader.getAttributeValue(null,"tgtlitem");
                            
                   if (tempAttribTgtlitem!=null){
                         java.lang.String content = tempAttribTgtlitem;
                        
                                                 object.setTgtlitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribTgtlitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("tgtlitem");
                    
                    // handle attribute "ctype"
                    java.lang.String tempAttribCtype =
                        
                                reader.getAttributeValue(null,"ctype");
                            
                   if (tempAttribCtype!=null){
                         java.lang.String content = tempAttribCtype;
                        
                                                  object.setCtype(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType.Factory.fromString(reader,tempAttribCtype));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ctype is missing");
                           
                    }
                    handledAttributes.add("ctype");
                    
                    // handle attribute "reason"
                    java.lang.String tempAttribReason =
                        
                                reader.getAttributeValue(null,"reason");
                            
                   if (tempAttribReason!=null){
                         java.lang.String content = tempAttribReason;
                        
                                                 object.setReason(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribReason));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute reason is missing");
                           
                    }
                    handledAttributes.add("reason");
                    
                    // handle attribute "isnamecflict"
                    java.lang.String tempAttribIsnamecflict =
                        
                                reader.getAttributeValue(null,"isnamecflict");
                            
                   if (tempAttribIsnamecflict!=null){
                         java.lang.String content = tempAttribIsnamecflict;
                        
                                                 object.setIsnamecflict(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttribIsnamecflict));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute isnamecflict is missing");
                           
                    }
                    handledAttributes.add("isnamecflict");
                    
                    // handle attribute "isforced"
                    java.lang.String tempAttribIsforced =
                        
                                reader.getAttributeValue(null,"isforced");
                            
                   if (tempAttribIsforced!=null){
                         java.lang.String content = tempAttribIsforced;
                        
                                                 object.setIsforced(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttribIsforced));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute isforced is missing");
                           
                    }
                    handledAttributes.add("isforced");
                    
                    // handle attribute "res"
                    java.lang.String tempAttribRes =
                        
                                reader.getAttributeValue(null,"res");
                            
                   if (tempAttribRes!=null){
                         java.lang.String content = tempAttribRes;
                        
                                                  object.setRes(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution.Factory.fromString(reader,tempAttribRes));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("res");
                    
                    // handle attribute "isresolved"
                    java.lang.String tempAttribIsresolved =
                        
                                reader.getAttributeValue(null,"isresolved");
                            
                   if (tempAttribIsresolved!=null){
                         java.lang.String content = tempAttribIsresolved;
                        
                                                 object.setIsresolved(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttribIsresolved));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute isresolved is missing");
                           
                    }
                    handledAttributes.add("isresolved");
                    
                    // handle attribute "bdurl"
                    java.lang.String tempAttribBdurl =
                        
                                reader.getAttributeValue(null,"bdurl");
                            
                   if (tempAttribBdurl!=null){
                         java.lang.String content = tempAttribBdurl;
                        
                                                 object.setBdurl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribBdurl));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("bdurl");
                    
                    // handle attribute "tdurl"
                    java.lang.String tempAttribTdurl =
                        
                                reader.getAttributeValue(null,"tdurl");
                            
                   if (tempAttribTdurl!=null){
                         java.lang.String content = tempAttribTdurl;
                        
                                                 object.setTdurl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribTdurl));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("tdurl");
                    
                    // handle attribute "ydurl"
                    java.lang.String tempAttribYdurl =
                        
                                reader.getAttributeValue(null,"ydurl");
                            
                   if (tempAttribYdurl!=null){
                         java.lang.String content = tempAttribYdurl;
                        
                                                 object.setYdurl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribYdurl));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ydurl");
                    
                    
                    reader.next();
                



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          