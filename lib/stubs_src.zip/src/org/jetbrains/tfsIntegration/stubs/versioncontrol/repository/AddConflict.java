/**
 * AddConflict.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;


/**
 *  AddConflict bean class
 */
public class AddConflict implements org.apache.axis2.databinding.ADBBean {
    public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
            "AddConflict", "");

    /**
     * field for WorkspaceName
     */
    protected java.lang.String localWorkspaceName;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localWorkspaceNameTracker = false;

    /**
     * field for OwnerName
     */
    protected java.lang.String localOwnerName;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOwnerNameTracker = false;

    /**
     * field for ConflictType
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType localConflictType;

    /**
     * field for ItemId
     */
    protected int localItemId;

    /**
     * field for VersionFrom
     */
    protected int localVersionFrom;

    /**
     * field for PendingChangeId
     */
    protected int localPendingChangeId;

    /**
     * field for SourceLocalItem
     */
    protected java.lang.String localSourceLocalItem;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSourceLocalItemTracker = false;

    /**
     * field for TargetLocalItem
     */
    protected java.lang.String localTargetLocalItem;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTargetLocalItemTracker = false;

    /**
     * field for Reason
     */
    protected int localReason;

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")) {
            return "";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getWorkspaceName() {
        return localWorkspaceName;
    }

    /**
     * Auto generated setter method
     * @param param WorkspaceName
     */
    public void setWorkspaceName(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localWorkspaceNameTracker = true;
        } else {
            localWorkspaceNameTracker = false;
        }

        this.localWorkspaceName = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getOwnerName() {
        return localOwnerName;
    }

    /**
     * Auto generated setter method
     * @param param OwnerName
     */
    public void setOwnerName(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localOwnerNameTracker = true;
        } else {
            localOwnerNameTracker = false;
        }

        this.localOwnerName = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType getConflictType() {
        return localConflictType;
    }

    /**
     * Auto generated setter method
     * @param param ConflictType
     */
    public void setConflictType(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType param) {
        this.localConflictType = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getItemId() {
        return localItemId;
    }

    /**
     * Auto generated setter method
     * @param param ItemId
     */
    public void setItemId(int param) {
        this.localItemId = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getVersionFrom() {
        return localVersionFrom;
    }

    /**
     * Auto generated setter method
     * @param param VersionFrom
     */
    public void setVersionFrom(int param) {
        this.localVersionFrom = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getPendingChangeId() {
        return localPendingChangeId;
    }

    /**
     * Auto generated setter method
     * @param param PendingChangeId
     */
    public void setPendingChangeId(int param) {
        this.localPendingChangeId = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getSourceLocalItem() {
        return localSourceLocalItem;
    }

    /**
     * Auto generated setter method
     * @param param SourceLocalItem
     */
    public void setSourceLocalItem(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localSourceLocalItemTracker = true;
        } else {
            localSourceLocalItemTracker = false;
        }

        this.localSourceLocalItem = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getTargetLocalItem() {
        return localTargetLocalItem;
    }

    /**
     * Auto generated setter method
     * @param param TargetLocalItem
     */
    public void setTargetLocalItem(java.lang.String param) {
        if (param != null) {
            //update the setting tracker
            localTargetLocalItemTracker = true;
        } else {
            localTargetLocalItemTracker = false;
        }

        this.localTargetLocalItem = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getReason() {
        return localReason;
    }

    /**
     * Auto generated setter method
     * @param param Reason
     */
    public void setReason(int param) {
        this.localReason = param;
    }

    /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
    public static boolean isReaderMTOMAware(
        javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;

        try {
            isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(
                        org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        } catch (java.lang.IllegalArgumentException e) {
            isReaderMTOMAware = false;
        }

        return isReaderMTOMAware;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        org.apache.axiom.om.OMDataSource dataSource = new org.apache.axis2.databinding.ADBDataSource(this,
                MY_QNAME) {
                public void serialize(
                    org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                    throws javax.xml.stream.XMLStreamException {
                    AddConflict.this.serialize(MY_QNAME, factory, xmlWriter);
                }
            };

        return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(MY_QNAME,
            factory, dataSource);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory,
        org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();

        if (namespace != null) {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace,
                    parentQName.getLocalPart());
            } else {
                if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(),
                    namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        } else {
            xmlWriter.writeStartElement(parentQName.getLocalPart());
        }

        if (localWorkspaceNameTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "workspaceName",
                        namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "workspaceName");
                }
            } else {
                xmlWriter.writeStartElement("workspaceName");
            }

            if (localWorkspaceName == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "workspaceName cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localWorkspaceName);
            }

            xmlWriter.writeEndElement();
        }

        if (localOwnerNameTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "ownerName", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "ownerName");
                }
            } else {
                xmlWriter.writeStartElement("ownerName");
            }

            if (localOwnerName == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "ownerName cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localOwnerName);
            }

            xmlWriter.writeEndElement();
        }

        if (localConflictType == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "conflictType cannot be null!!");
        }

        localConflictType.serialize(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "conflictType"), factory, xmlWriter);

        namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

        if (!namespace.equals("")) {
            prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null) {
                prefix = generatePrefix(namespace);

                xmlWriter.writeStartElement(prefix, "itemId", namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            } else {
                xmlWriter.writeStartElement(namespace, "itemId");
            }
        } else {
            xmlWriter.writeStartElement("itemId");
        }

        if (localItemId == java.lang.Integer.MIN_VALUE) {
            throw new org.apache.axis2.databinding.ADBException(
                "itemId cannot be null!!");
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localItemId));
        }

        xmlWriter.writeEndElement();

        namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

        if (!namespace.equals("")) {
            prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null) {
                prefix = generatePrefix(namespace);

                xmlWriter.writeStartElement(prefix, "versionFrom", namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            } else {
                xmlWriter.writeStartElement(namespace, "versionFrom");
            }
        } else {
            xmlWriter.writeStartElement("versionFrom");
        }

        if (localVersionFrom == java.lang.Integer.MIN_VALUE) {
            throw new org.apache.axis2.databinding.ADBException(
                "versionFrom cannot be null!!");
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localVersionFrom));
        }

        xmlWriter.writeEndElement();

        namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

        if (!namespace.equals("")) {
            prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null) {
                prefix = generatePrefix(namespace);

                xmlWriter.writeStartElement(prefix, "pendingChangeId", namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            } else {
                xmlWriter.writeStartElement(namespace, "pendingChangeId");
            }
        } else {
            xmlWriter.writeStartElement("pendingChangeId");
        }

        if (localPendingChangeId == java.lang.Integer.MIN_VALUE) {
            throw new org.apache.axis2.databinding.ADBException(
                "pendingChangeId cannot be null!!");
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localPendingChangeId));
        }

        xmlWriter.writeEndElement();

        if (localSourceLocalItemTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "sourceLocalItem",
                        namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "sourceLocalItem");
                }
            } else {
                xmlWriter.writeStartElement("sourceLocalItem");
            }

            if (localSourceLocalItem == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "sourceLocalItem cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localSourceLocalItem);
            }

            xmlWriter.writeEndElement();
        }

        if (localTargetLocalItemTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "targetLocalItem",
                        namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "targetLocalItem");
                }
            } else {
                xmlWriter.writeStartElement("targetLocalItem");
            }

            if (localTargetLocalItem == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                    "targetLocalItem cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localTargetLocalItem);
            }

            xmlWriter.writeEndElement();
        }

        namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

        if (!namespace.equals("")) {
            prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null) {
                prefix = generatePrefix(namespace);

                xmlWriter.writeStartElement(prefix, "reason", namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            } else {
                xmlWriter.writeStartElement(namespace, "reason");
            }
        } else {
            xmlWriter.writeStartElement("reason");
        }

        if (localReason == java.lang.Integer.MIN_VALUE) {
            throw new org.apache.axis2.databinding.ADBException(
                "reason cannot be null!!");
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localReason));
        }

        xmlWriter.writeEndElement();

        xmlWriter.writeEndElement();
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     * databinding method to get an XML representation of this object
     *
     */
    public javax.xml.stream.XMLStreamReader getPullParser(
        javax.xml.namespace.QName qName)
        throws org.apache.axis2.databinding.ADBException {
        java.util.ArrayList elementList = new java.util.ArrayList();
        java.util.ArrayList attribList = new java.util.ArrayList();

        if (localWorkspaceNameTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "workspaceName"));

            if (localWorkspaceName != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localWorkspaceName));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "workspaceName cannot be null!!");
            }
        }

        if (localOwnerNameTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "ownerName"));

            if (localOwnerName != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localOwnerName));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "ownerName cannot be null!!");
            }
        }

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "conflictType"));

        if (localConflictType == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "conflictType cannot be null!!");
        }

        elementList.add(localConflictType);

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "itemId"));

        elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localItemId));

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "versionFrom"));

        elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localVersionFrom));

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "pendingChangeId"));

        elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localPendingChangeId));

        if (localSourceLocalItemTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "sourceLocalItem"));

            if (localSourceLocalItem != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localSourceLocalItem));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "sourceLocalItem cannot be null!!");
            }
        }

        if (localTargetLocalItemTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "targetLocalItem"));

            if (localTargetLocalItem != null) {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localTargetLocalItem));
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "targetLocalItem cannot be null!!");
            }
        }

        elementList.add(new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "reason"));

        elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localReason));

        return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
            elementList.toArray(), attribList.toArray());
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static AddConflict parse(javax.xml.stream.XMLStreamReader reader)
            throws java.lang.Exception {
            AddConflict object = new AddConflict();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"AddConflict".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (AddConflict) org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "workspaceName").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setWorkspaceName(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "ownerName").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setOwnerName(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "conflictType").equals(reader.getName())) {
                    object.setConflictType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "itemId").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setItemId(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "versionFrom").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setVersionFrom(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "pendingChangeId").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setPendingChangeId(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "sourceLocalItem").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setSourceLocalItem(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "targetLocalItem").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setTargetLocalItem(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "reason").equals(reader.getName())) {
                    java.lang.String content = reader.getElementText();

                    object.setReason(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
