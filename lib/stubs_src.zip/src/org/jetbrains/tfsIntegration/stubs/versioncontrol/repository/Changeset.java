
/**
 * Changeset.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */
            
                package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;
            

            /**
            *  Changeset bean class
            */
        
        public  class Changeset
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = Changeset
                Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for Changes
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChange localChanges ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localChangesTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChange
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChange getChanges(){
                               return localChanges;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Changes
                               */
                               public void setChanges(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChange param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localChangesTracker = true;
                                       } else {
                                          localChangesTracker = false;
                                              
                                       }
                                   
                                            this.localChanges=param;
                                    

                               }
                            

                        /**
                        * field for Comment
                        */

                        
                                    protected java.lang.String localComment ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localCommentTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getComment(){
                               return localComment;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Comment
                               */
                               public void setComment(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localCommentTracker = true;
                                       } else {
                                          localCommentTracker = false;
                                              
                                       }
                                   
                                            this.localComment=param;
                                    

                               }
                            

                        /**
                        * field for CheckinNote
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote localCheckinNote ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localCheckinNoteTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote getCheckinNote(){
                               return localCheckinNote;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param CheckinNote
                               */
                               public void setCheckinNote(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localCheckinNoteTracker = true;
                                       } else {
                                          localCheckinNoteTracker = false;
                                              
                                       }
                                   
                                            this.localCheckinNote=param;
                                    

                               }
                            

                        /**
                        * field for PolicyOverride
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyOverrideInfo localPolicyOverride ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPolicyOverrideTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyOverrideInfo
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyOverrideInfo getPolicyOverride(){
                               return localPolicyOverride;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PolicyOverride
                               */
                               public void setPolicyOverride(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyOverrideInfo param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPolicyOverrideTracker = true;
                                       } else {
                                          localPolicyOverrideTracker = false;
                                              
                                       }
                                   
                                            this.localPolicyOverride=param;
                                    

                               }
                            

                        /**
                        * field for Cmtr
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localCmtr ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getCmtr(){
                               return localCmtr;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Cmtr
                               */
                               public void setCmtr(java.lang.String param){
                            
                                            this.localCmtr=param;
                                    

                               }
                            

                        /**
                        * field for Date
                        * This was an Attribute!
                        */

                        
                                    protected java.util.Calendar localDate ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getDate(){
                               return localDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Date
                               */
                               public void setDate(java.util.Calendar param){
                            
                                            this.localDate=param;
                                    

                               }
                            

                        /**
                        * field for Cset
                        * This was an Attribute!
                        */

                        
                                    protected int localCset ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getCset(){
                               return localCset;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Cset
                               */
                               public void setCset(int param){
                            
                                            this.localCset=param;
                                    

                               }
                            

                        /**
                        * field for Owner
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localOwner ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getOwner(){
                               return localOwner;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Owner
                               */
                               public void setOwner(java.lang.String param){
                            
                                            this.localOwner=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       Changeset.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":Changeset",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "Changeset",
                           xmlWriter);
                   }

               
                   }
               
                                            if (localCmtr != null){
                                        
                                                writeAttribute("",
                                                         "cmtr",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCmtr), xmlWriter);

                                            
                                      }
                                    
                                            if (localDate != null){
                                        
                                                writeAttribute("",
                                                         "date",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDate), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localDate is null");
                                      }
                                    
                                                   if (localCset!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "cset",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCset), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localCset is null");
                                      }
                                    
                                            if (localOwner != null){
                                        
                                                writeAttribute("",
                                                         "owner",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOwner), xmlWriter);

                                            
                                      }
                                     if (localChangesTracker){
                                            if (localChanges==null){
                                                 throw new org.apache.axis2.databinding.ADBException("Changes cannot be null!!");
                                            }
                                           localChanges.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","Changes"),
                                               factory,xmlWriter);
                                        } if (localCommentTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"Comment", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"Comment");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("Comment");
                                    }
                                

                                          if (localComment==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("Comment cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localComment);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localCheckinNoteTracker){
                                            if (localCheckinNote==null){
                                                 throw new org.apache.axis2.databinding.ADBException("CheckinNote cannot be null!!");
                                            }
                                           localCheckinNote.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","CheckinNote"),
                                               factory,xmlWriter);
                                        } if (localPolicyOverrideTracker){
                                            if (localPolicyOverride==null){
                                                 throw new org.apache.axis2.databinding.ADBException("PolicyOverride cannot be null!!");
                                            }
                                           localPolicyOverride.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","PolicyOverride"),
                                               factory,xmlWriter);
                                        }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localChangesTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "Changes"));
                            
                            
                                    if (localChanges==null){
                                         throw new org.apache.axis2.databinding.ADBException("Changes cannot be null!!");
                                    }
                                    elementList.add(localChanges);
                                } if (localCommentTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "Comment"));
                                 
                                        if (localComment != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localComment));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("Comment cannot be null!!");
                                        }
                                    } if (localCheckinNoteTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "CheckinNote"));
                            
                            
                                    if (localCheckinNote==null){
                                         throw new org.apache.axis2.databinding.ADBException("CheckinNote cannot be null!!");
                                    }
                                    elementList.add(localCheckinNote);
                                } if (localPolicyOverrideTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "PolicyOverride"));
                            
                            
                                    if (localPolicyOverride==null){
                                         throw new org.apache.axis2.databinding.ADBException("PolicyOverride cannot be null!!");
                                    }
                                    elementList.add(localPolicyOverride);
                                }
                            attribList.add(
                            new javax.xml.namespace.QName("","cmtr"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCmtr));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","date"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDate));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","cset"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCset));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","owner"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOwner));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static Changeset parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            Changeset object =
                new Changeset();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"Changeset".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (Changeset)org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "cmtr"
                    java.lang.String tempAttribCmtr =
                        
                                reader.getAttributeValue(null,"cmtr");
                            
                   if (tempAttribCmtr!=null){
                         java.lang.String content = tempAttribCmtr;
                        
                                                 object.setCmtr(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribCmtr));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("cmtr");
                    
                    // handle attribute "date"
                    java.lang.String tempAttribDate =
                        
                                reader.getAttributeValue(null,"date");
                            
                   if (tempAttribDate!=null){
                         java.lang.String content = tempAttribDate;
                        
                                                 object.setDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(tempAttribDate));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute date is missing");
                           
                    }
                    handledAttributes.add("date");
                    
                    // handle attribute "cset"
                    java.lang.String tempAttribCset =
                        
                                reader.getAttributeValue(null,"cset");
                            
                   if (tempAttribCset!=null){
                         java.lang.String content = tempAttribCset;
                        
                                                 object.setCset(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribCset));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute cset is missing");
                           
                    }
                    handledAttributes.add("cset");
                    
                    // handle attribute "owner"
                    java.lang.String tempAttribOwner =
                        
                                reader.getAttributeValue(null,"owner");
                            
                   if (tempAttribOwner!=null){
                         java.lang.String content = tempAttribOwner;
                        
                                                 object.setOwner(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribOwner));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("owner");
                    
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","Changes").equals(reader.getName())){
                                
                                                object.setChanges(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChange.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","Comment").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setComment(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","CheckinNote").equals(reader.getName())){
                                
                                                object.setCheckinNote(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","PolicyOverride").equals(reader.getName())){
                                
                                                object.setPolicyOverride(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyOverrideInfo.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          