
/**
 * ExtendedItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */
            
                package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;
            

            /**
            *  ExtendedItem bean class
            */
        
        public  class ExtendedItem
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = ExtendedItem
                Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for Lver
                        * This was an Attribute!
                        */

                        
                                    protected int localLver =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getLver(){
                               return localLver;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Lver
                               */
                               public void setLver(int param){
                            
                                            this.localLver=param;
                                    

                               }
                            

                        /**
                        * field for Did
                        * This was an Attribute!
                        */

                        
                                    protected int localDid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getDid(){
                               return localDid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Did
                               */
                               public void setDid(int param){
                            
                                            this.localDid=param;
                                    

                               }
                            

                        /**
                        * field for Latest
                        * This was an Attribute!
                        */

                        
                                    protected int localLatest =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getLatest(){
                               return localLatest;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Latest
                               */
                               public void setLatest(int param){
                            
                                            this.localLatest=param;
                                    

                               }
                            

                        /**
                        * field for Type
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localType ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getType(){
                               return localType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Type
                               */
                               public void setType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param){
                            
                                            this.localType=param;
                                    

                               }
                            

                        /**
                        * field for Enc
                        * This was an Attribute!
                        */

                        
                                    protected int localEnc =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("-3");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getEnc(){
                               return localEnc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Enc
                               */
                               public void setEnc(int param){
                            
                                            this.localEnc=param;
                                    

                               }
                            

                        /**
                        * field for Itemid
                        * This was an Attribute!
                        */

                        
                                    protected int localItemid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getItemid(){
                               return localItemid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Itemid
                               */
                               public void setItemid(int param){
                            
                                            this.localItemid=param;
                                    

                               }
                            

                        /**
                        * field for Local
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localLocal ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocal(){
                               return localLocal;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Local
                               */
                               public void setLocal(java.lang.String param){
                            
                                            this.localLocal=param;
                                    

                               }
                            

                        /**
                        * field for Titem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localTitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTitem(){
                               return localTitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Titem
                               */
                               public void setTitem(java.lang.String param){
                            
                                            this.localTitem=param;
                                    

                               }
                            

                        /**
                        * field for Sitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localSitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSitem(){
                               return localSitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Sitem
                               */
                               public void setSitem(java.lang.String param){
                            
                                            this.localSitem=param;
                                    

                               }
                            

                        /**
                        * field for Chg
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localChg =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString("None");
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getChg(){
                               return localChg;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Chg
                               */
                               public void setChg(java.lang.String param){
                            
                                            this.localChg=param;
                                    

                               }
                            

                        /**
                        * field for Ochg
                        * This was an Attribute!
                        */

                        
                                    protected boolean localOchg =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean("false");
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getOchg(){
                               return localOchg;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ochg
                               */
                               public void setOchg(boolean param){
                            
                                            this.localOchg=param;
                                    

                               }
                            

                        /**
                        * field for Lock
                        * This was an Attribute!
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel localLock ;
                                

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel
                           */
                           public  org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel getLock(){
                               return localLock;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Lock
                               */
                               public void setLock(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel param){
                            
                                            this.localLock=param;
                                    

                               }
                            

                        /**
                        * field for Lowner
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localLowner ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLowner(){
                               return localLowner;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Lowner
                               */
                               public void setLowner(java.lang.String param){
                            
                                            this.localLowner=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       ExtendedItem.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":ExtendedItem",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "ExtendedItem",
                           xmlWriter);
                   }

               
                   }
               
                                                   if (localLver!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "lver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLver), xmlWriter);

                                            
                                      }
                                    
                                                   if (localDid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "did",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDid), xmlWriter);

                                            
                                      }
                                    
                                                   if (localLatest!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "latest",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLatest), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localType != null){
                                        writeAttribute("",
                                           "type",
                                           localType.toString(), xmlWriter);
                                    }
                                    
                                                   if (localEnc!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "enc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnc), xmlWriter);

                                            
                                      }
                                    
                                                   if (localItemid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "itemid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItemid), xmlWriter);

                                            
                                      }
                                    
                                            if (localLocal != null){
                                        
                                                writeAttribute("",
                                                         "local",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocal), xmlWriter);

                                            
                                      }
                                    
                                            if (localTitem != null){
                                        
                                                writeAttribute("",
                                                         "titem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTitem), xmlWriter);

                                            
                                      }
                                    
                                            if (localSitem != null){
                                        
                                                writeAttribute("",
                                                         "sitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSitem), xmlWriter);

                                            
                                      }
                                    
                                            if (localChg != null){
                                        
                                                writeAttribute("",
                                                         "chg",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChg), xmlWriter);

                                            
                                      }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "ochg",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOchg), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localLock != null){
                                        writeAttribute("",
                                           "lock",
                                           localLock.toString(), xmlWriter);
                                    }
                                    
                                            if (localLowner != null){
                                        
                                                writeAttribute("",
                                                         "lowner",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLowner), xmlWriter);

                                            
                                      }
                                    
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                            attribList.add(
                            new javax.xml.namespace.QName("","lver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLver));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","did"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","latest"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLatest));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","type"));
                            
                                      attribList.add(localType.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","enc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","itemid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItemid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","local"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocal));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","titem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","sitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","chg"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChg));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ochg"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOchg));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","lock"));
                            
                                      attribList.add(localLock.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","lowner"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLowner));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static ExtendedItem parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            ExtendedItem object =
                new ExtendedItem();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"ExtendedItem".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (ExtendedItem)org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "lver"
                    java.lang.String tempAttribLver =
                        
                                reader.getAttributeValue(null,"lver");
                            
                   if (tempAttribLver!=null){
                         java.lang.String content = tempAttribLver;
                        
                                                 object.setLver(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribLver));
                                            
                    } else {
                       
                                           object.setLver(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("lver");
                    
                    // handle attribute "did"
                    java.lang.String tempAttribDid =
                        
                                reader.getAttributeValue(null,"did");
                            
                   if (tempAttribDid!=null){
                         java.lang.String content = tempAttribDid;
                        
                                                 object.setDid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribDid));
                                            
                    } else {
                       
                                           object.setDid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("did");
                    
                    // handle attribute "latest"
                    java.lang.String tempAttribLatest =
                        
                                reader.getAttributeValue(null,"latest");
                            
                   if (tempAttribLatest!=null){
                         java.lang.String content = tempAttribLatest;
                        
                                                 object.setLatest(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribLatest));
                                            
                    } else {
                       
                                           object.setLatest(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("latest");
                    
                    // handle attribute "type"
                    java.lang.String tempAttribType =
                        
                                reader.getAttributeValue(null,"type");
                            
                   if (tempAttribType!=null){
                         java.lang.String content = tempAttribType;
                        
                                                  object.setType(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(reader,tempAttribType));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("type");
                    
                    // handle attribute "enc"
                    java.lang.String tempAttribEnc =
                        
                                reader.getAttributeValue(null,"enc");
                            
                   if (tempAttribEnc!=null){
                         java.lang.String content = tempAttribEnc;
                        
                                                 object.setEnc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribEnc));
                                            
                    } else {
                       
                                           object.setEnc(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("enc");
                    
                    // handle attribute "itemid"
                    java.lang.String tempAttribItemid =
                        
                                reader.getAttributeValue(null,"itemid");
                            
                   if (tempAttribItemid!=null){
                         java.lang.String content = tempAttribItemid;
                        
                                                 object.setItemid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribItemid));
                                            
                    } else {
                       
                                           object.setItemid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("itemid");
                    
                    // handle attribute "local"
                    java.lang.String tempAttribLocal =
                        
                                reader.getAttributeValue(null,"local");
                            
                   if (tempAttribLocal!=null){
                         java.lang.String content = tempAttribLocal;
                        
                                                 object.setLocal(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribLocal));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("local");
                    
                    // handle attribute "titem"
                    java.lang.String tempAttribTitem =
                        
                                reader.getAttributeValue(null,"titem");
                            
                   if (tempAttribTitem!=null){
                         java.lang.String content = tempAttribTitem;
                        
                                                 object.setTitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribTitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("titem");
                    
                    // handle attribute "sitem"
                    java.lang.String tempAttribSitem =
                        
                                reader.getAttributeValue(null,"sitem");
                            
                   if (tempAttribSitem!=null){
                         java.lang.String content = tempAttribSitem;
                        
                                                 object.setSitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribSitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("sitem");
                    
                    // handle attribute "chg"
                    java.lang.String tempAttribChg =
                        
                                reader.getAttributeValue(null,"chg");
                            
                   if (tempAttribChg!=null){
                         java.lang.String content = tempAttribChg;
                        
                                                 object.setChg(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribChg));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("chg");
                    
                    // handle attribute "ochg"
                    java.lang.String tempAttribOchg =
                        
                                reader.getAttributeValue(null,"ochg");
                            
                   if (tempAttribOchg!=null){
                         java.lang.String content = tempAttribOchg;
                        
                                                 object.setOchg(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttribOchg));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ochg");
                    
                    // handle attribute "lock"
                    java.lang.String tempAttribLock =
                        
                                reader.getAttributeValue(null,"lock");
                            
                   if (tempAttribLock!=null){
                         java.lang.String content = tempAttribLock;
                        
                                                  object.setLock(
                                                        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel.Factory.fromString(reader,tempAttribLock));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("lock");
                    
                    // handle attribute "lowner"
                    java.lang.String tempAttribLowner =
                        
                                reader.getAttributeValue(null,"lowner");
                            
                   if (tempAttribLowner!=null){
                         java.lang.String content = tempAttribLowner;
                        
                                                 object.setLowner(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribLowner));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("lowner");
                    
                    
                    reader.next();
                



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          