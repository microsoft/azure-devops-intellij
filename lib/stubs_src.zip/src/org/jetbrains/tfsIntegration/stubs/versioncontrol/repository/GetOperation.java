/**
 * GetOperation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;


/**
 *  GetOperation bean class
 */
public class GetOperation implements org.apache.axis2.databinding.ADBBean {
    /**
     * field for HashValue
     */
    protected javax.activation.DataHandler localHashValue;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHashValueTracker = false;

    /**
     * field for Type
     * This was an Attribute!
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType localType;

    /**
     * field for Itemid
     * This was an Attribute!
     */
    protected int localItemid;

    /**
     * field for Slocal
     * This was an Attribute!
     */
    protected java.lang.String localSlocal;

    /**
     * field for Tlocal
     * This was an Attribute!
     */
    protected java.lang.String localTlocal;

    /**
     * field for Titem
     * This was an Attribute!
     */
    protected java.lang.String localTitem;

    /**
     * field for Sver
     * This was an Attribute!
     */
    protected int localSver;

    /**
     * field for Lver
     * This was an Attribute!
     */
    protected int localLver;

    /**
     * field for Did
     * This was an Attribute!
     */
    protected int localDid;

    /**
     * field for Chg
     * This was an Attribute!
     */
    protected java.lang.String localChg;

    /**
     * field for Lock
     * This was an Attribute!
     */
    protected org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel localLock;

    /**
     * field for Il
     * This was an Attribute!
     */
    protected boolean localIl;

    /**
     * field for Pcid
     * This was an Attribute!
     */
    protected int localPcid;

    /**
     * field for Cnflct
     * This was an Attribute!
     */
    protected boolean localCnflct;

    /**
     * field for Cnflctchg
     * This was an Attribute!
     */
    protected java.lang.String localCnflctchg;

    /**
     * field for Cnflctitemid
     * This was an Attribute!
     */
    protected int localCnflctitemid;

    /**
     * field for Durl
     * This was an Attribute!
     */
    protected java.lang.String localDurl;

    /* This type was generated from the piece of schema that had
       name = GetOperation
       Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
       Namespace Prefix =
     */
    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")) {
            return "";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Auto generated getter method
     * @return javax.activation.DataHandler
     */
    public javax.activation.DataHandler getHashValue() {
        return localHashValue;
    }

    /**
     * Auto generated setter method
     * @param param HashValue
     */
    public void setHashValue(javax.activation.DataHandler param) {
        if (param != null) {
            //update the setting tracker
            localHashValueTracker = true;
        } else {
            localHashValueTracker = false;
        }

        this.localHashValue = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType getType() {
        return localType;
    }

    /**
     * Auto generated setter method
     * @param param Type
     */
    public void setType(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType param) {
        this.localType = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getItemid() {
        return localItemid;
    }

    /**
     * Auto generated setter method
     * @param param Itemid
     */
    public void setItemid(int param) {
        this.localItemid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getSlocal() {
        return localSlocal;
    }

    /**
     * Auto generated setter method
     * @param param Slocal
     */
    public void setSlocal(java.lang.String param) {
        this.localSlocal = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getTlocal() {
        return localTlocal;
    }

    /**
     * Auto generated setter method
     * @param param Tlocal
     */
    public void setTlocal(java.lang.String param) {
        this.localTlocal = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getTitem() {
        return localTitem;
    }

    /**
     * Auto generated setter method
     * @param param Titem
     */
    public void setTitem(java.lang.String param) {
        this.localTitem = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getSver() {
        return localSver;
    }

    /**
     * Auto generated setter method
     * @param param Sver
     */
    public void setSver(int param) {
        this.localSver = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getLver() {
        return localLver;
    }

    /**
     * Auto generated setter method
     * @param param Lver
     */
    public void setLver(int param) {
        this.localLver = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getDid() {
        return localDid;
    }

    /**
     * Auto generated setter method
     * @param param Did
     */
    public void setDid(int param) {
        this.localDid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getChg() {
        return localChg;
    }

    /**
     * Auto generated setter method
     * @param param Chg
     */
    public void setChg(java.lang.String param) {
        this.localChg = param;
    }

    /**
     * Auto generated getter method
     * @return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel
     */
    public org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel getLock() {
        return localLock;
    }

    /**
     * Auto generated setter method
     * @param param Lock
     */
    public void setLock(
        org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel param) {
        this.localLock = param;
    }

    /**
     * Auto generated getter method
     * @return boolean
     */
    public boolean getIl() {
        return localIl;
    }

    /**
     * Auto generated setter method
     * @param param Il
     */
    public void setIl(boolean param) {
        this.localIl = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getPcid() {
        return localPcid;
    }

    /**
     * Auto generated setter method
     * @param param Pcid
     */
    public void setPcid(int param) {
        this.localPcid = param;
    }

    /**
     * Auto generated getter method
     * @return boolean
     */
    public boolean getCnflct() {
        return localCnflct;
    }

    /**
     * Auto generated setter method
     * @param param Cnflct
     */
    public void setCnflct(boolean param) {
        this.localCnflct = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getCnflctchg() {
        return localCnflctchg;
    }

    /**
     * Auto generated setter method
     * @param param Cnflctchg
     */
    public void setCnflctchg(java.lang.String param) {
        this.localCnflctchg = param;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getCnflctitemid() {
        return localCnflctitemid;
    }

    /**
     * Auto generated setter method
     * @param param Cnflctitemid
     */
    public void setCnflctitemid(int param) {
        this.localCnflctitemid = param;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getDurl() {
        return localDurl;
    }

    /**
     * Auto generated setter method
     * @param param Durl
     */
    public void setDurl(java.lang.String param) {
        this.localDurl = param;
    }

    /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
    public static boolean isReaderMTOMAware(
        javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;

        try {
            isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(
                        org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        } catch (java.lang.IllegalArgumentException e) {
            isReaderMTOMAware = false;
        }

        return isReaderMTOMAware;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        org.apache.axiom.om.OMDataSource dataSource = new org.apache.axis2.databinding.ADBDataSource(this,
                parentQName) {
                public void serialize(
                    org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                    throws javax.xml.stream.XMLStreamException {
                    GetOperation.this.serialize(parentQName, factory, xmlWriter);
                }
            };

        return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(parentQName,
            factory, dataSource);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory,
        org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();

        if (namespace != null) {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace,
                    parentQName.getLocalPart());
            } else {
                if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(),
                    namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        } else {
            xmlWriter.writeStartElement(parentQName.getLocalPart());
        }

        if (localType != null) {
            writeAttribute("", "type", localType.toString(), xmlWriter);
        }

        if (localItemid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "itemid",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localItemid), xmlWriter);
        }

        if (localSlocal != null) {
            writeAttribute("", "slocal",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localSlocal), xmlWriter);
        }

        if (localTlocal != null) {
            writeAttribute("", "tlocal",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localTlocal), xmlWriter);
        }

        if (localTitem != null) {
            writeAttribute("", "titem",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localTitem), xmlWriter);
        }

        if (localSver != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "sver",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localSver), xmlWriter);
        }

        if (localLver != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "lver",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localLver), xmlWriter);
        }

        if (localDid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "did",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localDid), xmlWriter);
        }

        if (localChg != null) {
            writeAttribute("", "chg",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localChg), xmlWriter);
        }

        if (localLock != null) {
            writeAttribute("", "lock", localLock.toString(), xmlWriter);
        }

        if (true) {
            writeAttribute("", "il",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localIl), xmlWriter);
        }

        if (localPcid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "pcid",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localPcid), xmlWriter);
        }

        if (true) {
            writeAttribute("", "cnflct",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localCnflct), xmlWriter);
        }

        if (localCnflctchg != null) {
            writeAttribute("", "cnflctchg",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localCnflctchg), xmlWriter);
        }

        if (localCnflctitemid != java.lang.Integer.MIN_VALUE) {
            writeAttribute("", "cnflctitemid",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localCnflctitemid), xmlWriter);
        }

        if (localDurl != null) {
            writeAttribute("", "durl",
                org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    localDurl), xmlWriter);
        }

        if (localHashValueTracker) {
            namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";

            if (!namespace.equals("")) {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "HashValue", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                } else {
                    xmlWriter.writeStartElement(namespace, "HashValue");
                }
            } else {
                xmlWriter.writeStartElement("HashValue");
            }

            if (localHashValue != null) {
                xmlWriter.writeDataHandler(localHashValue);
            }

            xmlWriter.writeEndElement();
        }

        xmlWriter.writeEndElement();
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (xmlWriter.getPrefix(namespace) == null) {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        xmlWriter.writeAttribute(namespace, attName, attValue);
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(namespace, attName, attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     * databinding method to get an XML representation of this object
     *
     */
    public javax.xml.stream.XMLStreamReader getPullParser(
        javax.xml.namespace.QName qName)
        throws org.apache.axis2.databinding.ADBException {
        java.util.ArrayList elementList = new java.util.ArrayList();
        java.util.ArrayList attribList = new java.util.ArrayList();

        if (localHashValueTracker) {
            elementList.add(new javax.xml.namespace.QName(
                    "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                    "HashValue"));

            elementList.add(localHashValue);
        }

        attribList.add(new javax.xml.namespace.QName("", "type"));

        attribList.add(localType.toString());

        attribList.add(new javax.xml.namespace.QName("", "itemid"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localItemid));

        attribList.add(new javax.xml.namespace.QName("", "slocal"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localSlocal));

        attribList.add(new javax.xml.namespace.QName("", "tlocal"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localTlocal));

        attribList.add(new javax.xml.namespace.QName("", "titem"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localTitem));

        attribList.add(new javax.xml.namespace.QName("", "sver"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localSver));

        attribList.add(new javax.xml.namespace.QName("", "lver"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localLver));

        attribList.add(new javax.xml.namespace.QName("", "did"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localDid));

        attribList.add(new javax.xml.namespace.QName("", "chg"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localChg));

        attribList.add(new javax.xml.namespace.QName("", "lock"));

        attribList.add(localLock.toString());

        attribList.add(new javax.xml.namespace.QName("", "il"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localIl));

        attribList.add(new javax.xml.namespace.QName("", "pcid"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localPcid));

        attribList.add(new javax.xml.namespace.QName("", "cnflct"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localCnflct));

        attribList.add(new javax.xml.namespace.QName("", "cnflctchg"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localCnflctchg));

        attribList.add(new javax.xml.namespace.QName("", "cnflctitemid"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localCnflctitemid));

        attribList.add(new javax.xml.namespace.QName("", "durl"));

        attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                localDurl));

        return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
            elementList.toArray(), attribList.toArray());
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static GetOperation parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            GetOperation object = new GetOperation();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"GetOperation".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (GetOperation) org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                // handle attribute "type"
                java.lang.String tempAttribType = reader.getAttributeValue(null,
                        "type");

                if (tempAttribType != null) {
                    java.lang.String content = tempAttribType;

                    if (tempAttribType.indexOf(":") > 0) {
                        // this seems to be a Qname so find the namespace and send
                        prefix = tempAttribType.substring(0,
                                tempAttribType.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object.setType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(
                                tempAttribType, namespaceuri));
                    } else {
                        // this seems to be not a qname send and empty namespace incase of it is
                        // check is done in fromString method
                        object.setType(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.fromString(
                                tempAttribType, ""));
                    }
                } else {
                }

                handledAttributes.add("type");

                // handle attribute "itemid"
                java.lang.String tempAttribItemid = reader.getAttributeValue(null,
                        "itemid");

                if (tempAttribItemid != null) {
                    java.lang.String content = tempAttribItemid;

                    object.setItemid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribItemid));
                } else {
                    object.setItemid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("itemid");

                // handle attribute "slocal"
                java.lang.String tempAttribSlocal = reader.getAttributeValue(null,
                        "slocal");

                if (tempAttribSlocal != null) {
                    java.lang.String content = tempAttribSlocal;

                    object.setSlocal(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribSlocal));
                } else {
                }

                handledAttributes.add("slocal");

                // handle attribute "tlocal"
                java.lang.String tempAttribTlocal = reader.getAttributeValue(null,
                        "tlocal");

                if (tempAttribTlocal != null) {
                    java.lang.String content = tempAttribTlocal;

                    object.setTlocal(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribTlocal));
                } else {
                }

                handledAttributes.add("tlocal");

                // handle attribute "titem"
                java.lang.String tempAttribTitem = reader.getAttributeValue(null,
                        "titem");

                if (tempAttribTitem != null) {
                    java.lang.String content = tempAttribTitem;

                    object.setTitem(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribTitem));
                } else {
                }

                handledAttributes.add("titem");

                // handle attribute "sver"
                java.lang.String tempAttribSver = reader.getAttributeValue(null,
                        "sver");

                if (tempAttribSver != null) {
                    java.lang.String content = tempAttribSver;

                    object.setSver(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribSver));
                } else {
                    object.setSver(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("sver");

                // handle attribute "lver"
                java.lang.String tempAttribLver = reader.getAttributeValue(null,
                        "lver");

                if (tempAttribLver != null) {
                    java.lang.String content = tempAttribLver;

                    object.setLver(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribLver));
                } else {
                    object.setLver(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("lver");

                // handle attribute "did"
                java.lang.String tempAttribDid = reader.getAttributeValue(null,
                        "did");

                if (tempAttribDid != null) {
                    java.lang.String content = tempAttribDid;

                    object.setDid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribDid));
                } else {
                    object.setDid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("did");

                // handle attribute "chg"
                java.lang.String tempAttribChg = reader.getAttributeValue(null,
                        "chg");

                if (tempAttribChg != null) {
                    java.lang.String content = tempAttribChg;

                    object.setChg(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribChg));
                } else {
                }

                handledAttributes.add("chg");

                // handle attribute "lock"
                java.lang.String tempAttribLock = reader.getAttributeValue(null,
                        "lock");

                if (tempAttribLock != null) {
                    java.lang.String content = tempAttribLock;

                    if (tempAttribLock.indexOf(":") > 0) {
                        // this seems to be a Qname so find the namespace and send
                        prefix = tempAttribLock.substring(0,
                                tempAttribLock.indexOf(":"));
                        namespaceuri = reader.getNamespaceURI(prefix);
                        object.setLock(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel.Factory.fromString(
                                tempAttribLock, namespaceuri));
                    } else {
                        // this seems to be not a qname send and empty namespace incase of it is
                        // check is done in fromString method
                        object.setLock(org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel.Factory.fromString(
                                tempAttribLock, ""));
                    }
                } else {
                }

                handledAttributes.add("lock");

                // handle attribute "il"
                java.lang.String tempAttribIl = reader.getAttributeValue(null,
                        "il");

                if (tempAttribIl != null) {
                    java.lang.String content = tempAttribIl;

                    object.setIl(org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(
                            tempAttribIl));
                } else {
                }

                handledAttributes.add("il");

                // handle attribute "pcid"
                java.lang.String tempAttribPcid = reader.getAttributeValue(null,
                        "pcid");

                if (tempAttribPcid != null) {
                    java.lang.String content = tempAttribPcid;

                    object.setPcid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribPcid));
                } else {
                    object.setPcid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("pcid");

                // handle attribute "cnflct"
                java.lang.String tempAttribCnflct = reader.getAttributeValue(null,
                        "cnflct");

                if (tempAttribCnflct != null) {
                    java.lang.String content = tempAttribCnflct;

                    object.setCnflct(org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(
                            tempAttribCnflct));
                } else {
                }

                handledAttributes.add("cnflct");

                // handle attribute "cnflctchg"
                java.lang.String tempAttribCnflctchg = reader.getAttributeValue(null,
                        "cnflctchg");

                if (tempAttribCnflctchg != null) {
                    java.lang.String content = tempAttribCnflctchg;

                    object.setCnflctchg(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribCnflctchg));
                } else {
                }

                handledAttributes.add("cnflctchg");

                // handle attribute "cnflctitemid"
                java.lang.String tempAttribCnflctitemid = reader.getAttributeValue(null,
                        "cnflctitemid");

                if (tempAttribCnflctitemid != null) {
                    java.lang.String content = tempAttribCnflctitemid;

                    object.setCnflctitemid(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            tempAttribCnflctitemid));
                } else {
                    object.setCnflctitemid(java.lang.Integer.MIN_VALUE);
                }

                handledAttributes.add("cnflctitemid");

                // handle attribute "durl"
                java.lang.String tempAttribDurl = reader.getAttributeValue(null,
                        "durl");

                if (tempAttribDurl != null) {
                    java.lang.String content = tempAttribDurl;

                    object.setDurl(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            tempAttribDurl));
                } else {
                }

                handledAttributes.add("durl");

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                            "HashValue").equals(reader.getName())) {
                    reader.next();

                    if (isReaderMTOMAware(reader) &&
                            java.lang.Boolean.TRUE.equals(reader.getProperty(
                                    org.apache.axiom.om.OMConstants.IS_BINARY))) {
                        //MTOM aware reader - get the datahandler directly and put it in the object
                        object.setHashValue((javax.activation.DataHandler) reader.getProperty(
                                org.apache.axiom.om.OMConstants.DATA_HANDLER));
                    } else {
                        if ((reader.getEventType() == javax.xml.stream.XMLStreamConstants.START_ELEMENT) &&
                                reader.getName()
                                          .equals(new javax.xml.namespace.QName(
                                        org.apache.axiom.om.impl.MTOMConstants.XOP_NAMESPACE_URI,
                                        org.apache.axiom.om.impl.MTOMConstants.XOP_INCLUDE))) {
                            java.lang.String id = org.apache.axiom.om.util.ElementHelper.getContentID(reader,
                                    "UTF-8");
                            object.setHashValue(((org.apache.axiom.soap.impl.builder.MTOMStAXSOAPModelBuilder) ((org.apache.axiom.om.impl.llom.OMStAXWrapper) reader).getBuilder()).getDataHandler(
                                    id));
                            reader.next();

                            reader.next();
                        } else if (reader.hasText()) {
                            //Do the usual conversion
                            java.lang.String content = reader.getText();
                            object.setHashValue(org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(
                                    content));

                            reader.next();
                        }
                    }

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getLocalName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
