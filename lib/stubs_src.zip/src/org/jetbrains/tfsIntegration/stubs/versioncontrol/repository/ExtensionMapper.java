/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:58 LKT)
 */
package org.jetbrains.tfsIntegration.stubs.versioncontrol.repository;


/**
 *  ExtensionMapper class
 */
public class ExtensionMapper {
    public static java.lang.Object getTypeObject(
        java.lang.String namespaceURI, java.lang.String typeName,
        javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ChangesetMerge".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ChangesetMerge.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "FileType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.FileType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfArrayOfBranchRelative".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfBranchRelative.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfChangeset".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeset.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "TeamProjectFolderOptions".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.TeamProjectFolderOptions.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ItemSpec".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSpec.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfArrayOfExtendedItem".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfExtendedItem.Factory.parse(reader);
        }

        if ("http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                "guid".equals(typeName)) {
            return com.microsoft.wsdl.types.Guid.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "CheckinResult".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinResult.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PendingSetType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendingSetType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Changeset".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Changeset.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfWarning".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWarning.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "DeletedState".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.DeletedState.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "CheckinWorkItemAction".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinWorkItemAction.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PermissionChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PermissionChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "RepositoryProperties".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RepositoryProperties.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ItemSecurity".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSecurity.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfChangesetMerge".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangesetMerge.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfAccessEntry".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfAccessEntry.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "LockLevel".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LockLevel.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PendingState".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendingState.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Warning".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Warning.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "MergeOptions".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeOptions.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Annotation".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Annotation.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "LabelResult".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelResult.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfExtendedItem".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfExtendedItem.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfItemSecurity".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSecurity.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfLabelResult".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelResult.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfArrayOfGetOperation".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfArrayOfGetOperation.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ExtendedItem".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ExtendedItem.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ConflictType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfCheckinNotificationWorkItemInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNotificationWorkItemInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "CheckinOptions".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinOptions.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "CheckinNoteFieldValue".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNoteFieldValue.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfPermissionChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPermissionChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "AccessEntry".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.AccessEntry.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "WarningType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.WarningType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "WorkingFolderType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.WorkingFolderType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfConflict".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfConflict.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "GlobalSecurity".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GlobalSecurity.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ItemSet".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemSet.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "LabelItemSpec".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelItemSpec.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "VersionControlLabel".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionControlLabel.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "CheckinNotificationWorkItemInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNotificationWorkItemInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ChangeRequest".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ChangeRequest.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "RequestType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RequestType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "VersionSpec".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionSpec.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Resolution".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Resolution.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfFileType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFileType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfAnnotation".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfAnnotation.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfInt".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfInt.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfVersionControlLabel".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfVersionControlLabel.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfWorkingFolder".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWorkingFolder.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "TeamProjectFolderPermission".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.TeamProjectFolderPermission.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfItem".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItem.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfItemSet".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSet.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "SecurityChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SecurityChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "LabelResultStatus".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelResultStatus.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfPolicyFailureInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPolicyFailureInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "CheckinNote".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNote.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfWorkspace".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfWorkspace.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfSecurityChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfSecurityChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "BranchRelative".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.BranchRelative.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "MergeCandidate".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeCandidate.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "RecursionType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.RecursionType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfMergeCandidate".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfMergeCandidate.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfTeamProjectFolderPermission".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfTeamProjectFolderPermission.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "GetOperation".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetOperation.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfGetOperation".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfGetOperation.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfChangeRequest".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfChangeRequest.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "VersionControlLink".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.VersionControlLink.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "LabelChildOption".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LabelChildOption.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfCheckinNoteFieldValue".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldValue.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PendingSet".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendingSet.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "CheckinNoteFieldDefinition".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNoteFieldDefinition.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "CheckinOptions_type0".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinOptions_type0.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "SeverityType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.SeverityType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfFailure".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfFailure.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfPendingChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfVersionControlLink".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfVersionControlLink.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfString".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfString.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Workspace".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Workspace.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfPendingSet".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingSet.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Item".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Item.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfCheckinNoteFieldDefinition".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfCheckinNoteFieldDefinition.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfLabelItemSpec".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLabelItemSpec.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Change".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Change.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfBranchRelative".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfBranchRelative.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PolicyFailureInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyFailureInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "LocalVersionUpdate".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.LocalVersionUpdate.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfItemSpec".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfItemSpec.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfGetRequest".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfGetRequest.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Shelveset".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Shelveset.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Conflict".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Conflict.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ConflictInformation".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ConflictInformation.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "MergeOptions_type0".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.MergeOptions_type0.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfShelveset".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfShelveset.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "WorkingFolder".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.WorkingFolder.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "GetRequest".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.GetRequest.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PolicyOverrideInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PolicyOverrideInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "CheckinNotificationInfo".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.CheckinNotificationInfo.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ArrayOfPendingState".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfPendingState.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "PendingChange".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.PendingChange.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) &&
                "ArrayOfLocalVersionUpdate".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ArrayOfLocalVersionUpdate.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "ItemType".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.ItemType.Factory.parse(reader);
        }

        if ("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(
                    namespaceURI) && "Failure".equals(typeName)) {
            return org.jetbrains.tfsIntegration.stubs.versioncontrol.repository.Failure.Factory.parse(reader);
        }

        throw new org.apache.axis2.databinding.ADBException("Unsupported type " +
            namespaceURI + " " + typeName);
    }
}
