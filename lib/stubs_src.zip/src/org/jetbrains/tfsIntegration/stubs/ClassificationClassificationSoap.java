

/**
 * ClassificationClassificationSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  ClassificationClassificationSoap java interface
     */

    public interface ClassificationClassificationSoap {
          

        /**
          * Auto generated method signature
          * 
                    * @param createNode76
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNodeResponse CreateNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateNode createNode76)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNodesXml78
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResponse GetNodesXml(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXml getNodesXml78)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProjectProperties80
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse GetProjectProperties(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectProperties getProjectProperties80)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listProjects82
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjectsResponse ListProjects(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects listProjects82)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNodeFromPath84
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPathResponse GetNodeFromPath(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeFromPath getNodeFromPath84)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteProject86
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse DeleteProject(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProject deleteProject86)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProject88
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectResponse GetProject(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProject getProject88)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteBranches90
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse DeleteBranches(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranches deleteBranches90)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNode92
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodeResponse GetNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNode getNode92)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getDeletedNodesXml94
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResponse GetDeletedNodesXml(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXml getDeletedNodesXml94)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createProject96
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProjectResponse CreateProject(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.CreateProject createProject96)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param reorderNode98
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse ReorderNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNode reorderNode98)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listStructures100
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructuresResponse ListStructures(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListStructures listStructures100)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param renameNode102
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse RenameNode(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNode renameNode102)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProjectFromName104
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromNameResponse GetProjectFromName(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectFromName getProjectFromName104)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param moveBranch106
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse MoveBranch(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranch moveBranch106)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateProjectProperties108
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse UpdateProjectProperties(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectProperties updateProjectProperties108)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getChangedNodes110
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodesResponse GetChangedNodes(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetChangedNodes getChangedNodes110)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listAllProjects112
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjectsResponse ListAllProjects(

                        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects listAllProjects112)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    