/**
 * ClassificationClassificationSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClassificationClassificationSoap java interface
 */
public interface ClassificationClassificationSoap {
    /**
     * Auto generated method signature
     * @param createProject164
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo CreateProject(
        java.lang.String projectName165,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.Structure_type0 structure166)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteProject169
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteProjectResponse DeleteProject(
        java.lang.String projectUri170) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getProjectProperties172
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetProjectPropertiesResponse GetProjectProperties(
        java.lang.String projectUri173) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param updateProjectProperties175
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.UpdateProjectPropertiesResponse UpdateProjectProperties(
        java.lang.String projectUri176, java.lang.String state177,
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectProperty properties178)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getProject180
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo GetProject(
        java.lang.String projectUri181) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getProjectFromName184
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ProjectInfo GetProjectFromName(
        java.lang.String projectName185) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listProjects188
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo ListProjects(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListProjects listProjects188)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listAllProjects191
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfProjectInfo ListAllProjects(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ListAllProjects listAllProjects191)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param listStructures194
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfNodeInfo ListStructures(
        java.lang.String projectUri195) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getNodesXml198
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetNodesXmlResult_type0 GetNodesXml(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString nodeUris199,
        boolean childNodes200) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param createNode203
     */
    public java.lang.String CreateNode(java.lang.String nodeName204,
        java.lang.String parentNodeUri205) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param renameNode208
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.RenameNodeResponse RenameNode(
        java.lang.String nodeUri209, java.lang.String newNodeName210)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param moveBranch212
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.MoveBranchResponse MoveBranch(
        java.lang.String nodeUri213, java.lang.String newParentNodeUri214)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param reorderNode216
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ReorderNodeResponse ReorderNode(
        java.lang.String nodeUri217, int moveBy218)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param deleteBranches220
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.DeleteBranchesResponse DeleteBranches(
        org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.ArrayOfString nodeUris221,
        java.lang.String reclassifyUri222) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getDeletedNodesXml224
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.GetDeletedNodesXmlResult_type0 GetDeletedNodesXml(
        java.lang.String projectUri225, java.util.Calendar since226)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getNode229
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo GetNode(
        java.lang.String nodeUri230) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getNodeFromPath233
     */
    public org.jetbrains.tfsIntegration.stubs.services.commonstructureservice.NodeInfo GetNodeFromPath(
        java.lang.String nodePath234) throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getChangedNodes237
     */
    public java.lang.String GetChangedNodes(int firstSequenceId238)
        throws java.rmi.RemoteException;

    //
}
