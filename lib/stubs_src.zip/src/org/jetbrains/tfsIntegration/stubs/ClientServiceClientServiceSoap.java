

/**
 * ClientServiceClientServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  ClientServiceClientServiceSoap java interface
     */

    public interface ClientServiceClientServiceSoap {
          

        /**
          * Auto generated method signature
          * 
                    * @param syncBisGroupsAndUsers
                
                    * @param requestHeader
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers syncBisGroupsAndUsers,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitemCountOnBehalfOf
                
                    * @param requestHeader0
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse QueryWorkitemCountOnBehalfOf(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf queryWorkitemCountOnBehalfOf,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader0)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQuery
                
                    * @param requestHeader1
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse GetStoredQuery(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery getStoredQuery,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader1)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getReferencingWorkitemUris
                
                    * @param requestHeader2
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse GetReferencingWorkitemUris(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris getReferencingWorkitemUris,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader2)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQueries
                
                    * @param requestHeader3
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse GetStoredQueries(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries getStoredQueries,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader3)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadata
                
                    * @param requestHeader4
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata getMetadata,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader4)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageWorkitemsByIdRevs
                
                    * @param requestHeader5
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs pageWorkitemsByIdRevs,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader5)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param syncAccessControlLists
                
                    * @param requestHeader6
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists syncAccessControlLists,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader6)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param stampWorkitemCache
                
                    * @param requestHeader7
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader7)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param bulkUpdate
                
                    * @param requestHeader8
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate bulkUpdate,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader8)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadataEx2
                
                    * @param requestHeader9
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 getMetadataEx2,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader9)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param requestCancel
                
                    * @param requestHeader10
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel requestCancel,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader10)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageItemsOnBehalfOf
                
                    * @param requestHeader11
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse PageItemsOnBehalfOf(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf pageItemsOnBehalfOf,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader11)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getWorkItem
                
                    * @param requestHeader12
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem getWorkItem,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader12)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param syncExternalStructures
                
                    * @param requestHeader13
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures syncExternalStructures,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader13)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getWorkitemTrackingVersion
                
                    * @param requestHeader14
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse GetWorkitemTrackingVersion(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader14)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param update
                
                    * @param requestHeader15
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update update,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader15)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitemCount
                
                    * @param requestHeader16
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount queryWorkitemCount,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader16)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitems
                
                    * @param requestHeader17
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems queryWorkitems,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader17)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadataEx
                
                    * @param requestHeader18
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx getMetadataEx,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader18)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageWorkitemsByIds
                
                    * @param requestHeader19
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds pageWorkitemsByIds,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader19)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    