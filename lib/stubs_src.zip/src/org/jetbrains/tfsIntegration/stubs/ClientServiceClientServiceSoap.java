/**
 * ClientServiceClientServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClientServiceClientServiceSoap java interface
 */
public interface ClientServiceClientServiceSoap {
    /**
     * Auto generated method signature
     * @param getWorkitemTrackingVersion
     * @param requestHeader
     */
    public java.lang.String GetWorkitemTrackingVersion(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param stampWorkitemCache
     * @param requestHeader0
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader0)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getReferencingWorkitemUris
     * @param requestHeader1
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString GetReferencingWorkitemUris(
        java.lang.String artifactUri,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader1)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getWorkItem
     * @param requestHeader2
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(
        int workItemId, int revisionId, int minimumRevisionId,
        java.util.Calendar asOfDate, boolean useMaster,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader2)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitems
     * @param requestHeader3
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 psQuery,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader3)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIds
     * @param requestHeader7
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns,
        java.util.Calendar asOfDate4, boolean useMaster5,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave6,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader7)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIdRevs
     * @param requestHeader12
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair pairs,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns8,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns9,
        java.util.Calendar asOfDate10, boolean useMaster11,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader12)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageItemsOnBehalfOf
     * @param requestHeader15
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 PageItemsOnBehalfOf(
        java.lang.String userName,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids13,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns14,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader15)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCount
     * @param requestHeader19
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 psQuery16,
        boolean useMaster17,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave18,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader19)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCountOnBehalfOf
     * @param requestHeader21
     */
    public int QueryWorkitemCountOnBehalfOf(java.lang.String userName20,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 query,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader21)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadata
     * @param requestHeader24
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave22,
        boolean useMaster23,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader24)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx
     * @param requestHeader27
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave25,
        boolean useMaster26,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader27)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx2
     * @param requestHeader30
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave28,
        boolean useMaster29,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader30)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param update
     * @param requestHeader32
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 _package,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave31,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader32)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param bulkUpdate
     * @param requestHeader35
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 _package33,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave34,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader35)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQuery
     * @param requestHeader36
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 GetStoredQuery(
        com.microsoft.wsdl.types.Guid queryId,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader36)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQueries
     * @param requestHeader37
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 GetStoredQueries(
        long rowVersion, int projectId,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader37)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncExternalStructures
     * @param requestHeader38
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(
        java.lang.String projectURI,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader38)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncAccessControlLists
     * @param requestHeader40
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(
        java.lang.String projectURI39,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader40)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncBisGroupsAndUsers
     * @param requestHeader41
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(
        java.lang.String projectUri,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader41)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param requestCancel
     * @param requestHeader42
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(
        java.lang.String requestIdToCancel,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader42)
        throws java.rmi.RemoteException;

    //
}
