/**
 * ClientServiceClientServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClientServiceClientServiceSoap java interface
 */
public interface ClientServiceClientServiceSoap {
    /**
     * Auto generated method signature
     * @param getWorkitemTrackingVersion
     * @param requestHeader
     */
    public java.lang.String GetWorkitemTrackingVersion(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param stampWorkitemCache
     * @param requestHeader0
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader0)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getReferencingWorkitemUris
     * @param requestHeader1
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString GetReferencingWorkitemUris(
        java.lang.String artifactUri,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader1)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getWorkItem
     * @param requestHeader2
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(
        int workItemId, int revisionId, int minimumRevisionId,
        java.util.Calendar asOfDate, boolean useMaster,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader2)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitems
     * @param requestHeader5
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 psQuery,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfQuerySortOrderEntry sort,
        boolean useMaster3,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave4,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader5)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIds
     * @param requestHeader9
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns,
        java.util.Calendar asOfDate6, boolean useMaster7,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave8,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader9)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIdRevs
     * @param requestHeader14
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair pairs,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns10,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns11,
        java.util.Calendar asOfDate12, boolean useMaster13,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader14)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageItemsOnBehalfOf
     * @param requestHeader17
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 PageItemsOnBehalfOf(
        java.lang.String userName,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids15,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns16,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader17)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCount
     * @param requestHeader21
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 psQuery18,
        boolean useMaster19,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave20,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader21)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCountOnBehalfOf
     * @param requestHeader23
     */
    public int QueryWorkitemCountOnBehalfOf(java.lang.String userName22,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 query,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader23)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadata
     * @param requestHeader26
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave24,
        boolean useMaster25,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader26)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx
     * @param requestHeader29
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave27,
        boolean useMaster28,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader29)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx2
     * @param requestHeader32
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave30,
        boolean useMaster31,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader32)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param update
     * @param requestHeader34
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 _package,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave33,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader34)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param bulkUpdate
     * @param requestHeader37
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 _package35,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave36,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader37)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQuery
     * @param requestHeader38
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 GetStoredQuery(
        com.microsoft.wsdl.types.Guid queryId,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader38)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQueries
     * @param requestHeader39
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 GetStoredQueries(
        long rowVersion, int projectId,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader39)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncExternalStructures
     * @param requestHeader40
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(
        java.lang.String projectURI,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader40)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncAccessControlLists
     * @param requestHeader42
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(
        java.lang.String projectURI41,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader42)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncBisGroupsAndUsers
     * @param requestHeader43
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(
        java.lang.String projectUri,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader43)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param requestCancel
     * @param requestHeader44
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(
        java.lang.String requestIdToCancel,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader44)
        throws java.rmi.RemoteException;

    //
}
