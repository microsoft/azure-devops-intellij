

/**
 * ServerStatusServerStatusSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  ServerStatusServerStatusSoap java interface
     */

    public interface ServerStatusServerStatusSoap {
          

        /**
          * Auto generated method signature
          * 
                    * @param checkAuthentication12
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.serverstatus.CheckAuthenticationResponse CheckAuthentication(

                        org.jetbrains.tfsIntegration.stubs.services.serverstatus.CheckAuthentication checkAuthentication12)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getServerStatus14
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetServerStatusResponse GetServerStatus(

                        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetServerStatus getServerStatus14)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getSupportedContractVersion16
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetSupportedContractVersionResponse GetSupportedContractVersion(

                        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetSupportedContractVersion getSupportedContractVersion16)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    