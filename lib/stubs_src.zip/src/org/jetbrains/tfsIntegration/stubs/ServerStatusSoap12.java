/**
 * ServerStatusServerStatusSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ServerStatusSoap12 java interface
 */
public interface ServerStatusSoap12 {
    /**
     * Auto generated method signature
     * @param getServerStatus
     */
    public org.jetbrains.tfsIntegration.stubs.services.serverstatus.ArrayOfDataChanged GetServerStatus(
        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetServerStatus getServerStatus)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param checkAuthentication
     */
    public java.lang.String CheckAuthentication(
        org.jetbrains.tfsIntegration.stubs.services.serverstatus.CheckAuthentication checkAuthentication)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getSupportedContractVersion
     */
    public java.lang.String GetSupportedContractVersion(
        org.jetbrains.tfsIntegration.stubs.services.serverstatus.GetSupportedContractVersion getSupportedContractVersion)
        throws java.rmi.RemoteException;

    //
}
