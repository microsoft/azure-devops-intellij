
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */

            package org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "OperatorType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.OperatorType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "id_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Id_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "items_type2".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ComputedColumn_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumn_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "IdRevisionPair".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.IdRevisionPair.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "psQuery_type1".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "QueryIds_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryIds_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.wsdl.types.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "package_type1".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "InsertResourceLink_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertResourceLink_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "c_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.C_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "table_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Table_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type3".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type3.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "UpdateWorkItem_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateWorkItem_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Package_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0E.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Column_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Column_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "queriesPayload_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "InsertText_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertText_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Columns_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type7".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type7.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "package_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfInt".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "queryPayload_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "items_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "columns_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0E.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type4".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type4.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "workItem_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.WorkItem_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "result_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Result_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "r_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.R_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "query_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type5".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type5.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "items_type1".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type6".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type6.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "GroupType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GroupType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "RequestHeader".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Query_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0E.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "result_type1".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Result_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type8".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type8.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "psQuery_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "resultIds_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ResultIds_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "GroupOperatorType".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GroupOperatorType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfIdRevisionPair".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type1".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfString".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "rows_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Rows_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type2".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Metadata_type2.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Expression_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Expression_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "MetadataTableHaveEntry".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.MetadataTableHaveEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfMetadataTableHaveEntry".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ComputedColumns_type0".equals(typeName)){
                   
                            return  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumns_type0.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    