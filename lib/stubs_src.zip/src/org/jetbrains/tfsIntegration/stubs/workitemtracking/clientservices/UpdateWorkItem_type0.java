
/**
 * UpdateWorkItem_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:41 LKT)
 */
            
                package org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices;
            

            /**
            *  UpdateWorkItem_type0 bean class
            */
        
        public  class UpdateWorkItem_type0
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = UpdateWorkItem_type0
                Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for ComputedColumns
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumns_type0 localComputedColumns ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localComputedColumnsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumns_type0
                           */
                           public  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumns_type0 getComputedColumns(){
                               return localComputedColumns;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ComputedColumns
                               */
                               public void setComputedColumns(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumns_type0 param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localComputedColumnsTracker = true;
                                       } else {
                                          localComputedColumnsTracker = false;
                                              
                                       }
                                   
                                            this.localComputedColumns=param;
                                    

                               }
                            

                        /**
                        * field for Columns
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0 localColumns ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localColumnsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0
                           */
                           public  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0 getColumns(){
                               return localColumns;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Columns
                               */
                               public void setColumns(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0 param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localColumnsTracker = true;
                                       } else {
                                          localColumnsTracker = false;
                                              
                                       }
                                   
                                            this.localColumns=param;
                                    

                               }
                            

                        /**
                        * field for InsertText
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertText_type0 localInsertText ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localInsertTextTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertText_type0
                           */
                           public  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertText_type0 getInsertText(){
                               return localInsertText;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param InsertText
                               */
                               public void setInsertText(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertText_type0 param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localInsertTextTracker = true;
                                       } else {
                                          localInsertTextTracker = false;
                                              
                                       }
                                   
                                            this.localInsertText=param;
                                    

                               }
                            

                        /**
                        * field for InsertResourceLink
                        */

                        
                                    protected org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertResourceLink_type0 localInsertResourceLink ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localInsertResourceLinkTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertResourceLink_type0
                           */
                           public  org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertResourceLink_type0 getInsertResourceLink(){
                               return localInsertResourceLink;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param InsertResourceLink
                               */
                               public void setInsertResourceLink(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertResourceLink_type0 param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localInsertResourceLinkTracker = true;
                                       } else {
                                          localInsertResourceLinkTracker = false;
                                              
                                       }
                                   
                                            this.localInsertResourceLink=param;
                                    

                               }
                            

                        /**
                        * field for WorkItemID
                        * This was an Attribute!
                        */

                        
                                    protected int localWorkItemID ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getWorkItemID(){
                               return localWorkItemID;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WorkItemID
                               */
                               public void setWorkItemID(int param){
                            
                                            this.localWorkItemID=param;
                                    

                               }
                            

                        /**
                        * field for Revision
                        * This was an Attribute!
                        */

                        
                                    protected int localRevision ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getRevision(){
                               return localRevision;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Revision
                               */
                               public void setRevision(int param){
                            
                                            this.localRevision=param;
                                    

                               }
                            

                        /**
                        * field for ObjectType
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localObjectType ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getObjectType(){
                               return localObjectType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ObjectType
                               */
                               public void setObjectType(java.lang.String param){
                            
                                            this.localObjectType=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       UpdateWorkItem_type0.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":UpdateWorkItem_type0",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "UpdateWorkItem_type0",
                           xmlWriter);
                   }

               
                   }
               
                                                   if (localWorkItemID!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "WorkItemID",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWorkItemID), xmlWriter);

                                            
                                      }
                                    
                                                   if (localRevision!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "Revision",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRevision), xmlWriter);

                                            
                                      }
                                    
                                            if (localObjectType != null){
                                        
                                                writeAttribute("",
                                                         "ObjectType",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localObjectType), xmlWriter);

                                            
                                      }
                                     if (localComputedColumnsTracker){
                                            if (localComputedColumns==null){
                                                 throw new org.apache.axis2.databinding.ADBException("ComputedColumns cannot be null!!");
                                            }
                                           localComputedColumns.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","ComputedColumns"),
                                               factory,xmlWriter);
                                        } if (localColumnsTracker){
                                            if (localColumns==null){
                                                 throw new org.apache.axis2.databinding.ADBException("Columns cannot be null!!");
                                            }
                                           localColumns.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","Columns"),
                                               factory,xmlWriter);
                                        } if (localInsertTextTracker){
                                            if (localInsertText==null){
                                                 throw new org.apache.axis2.databinding.ADBException("InsertText cannot be null!!");
                                            }
                                           localInsertText.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","InsertText"),
                                               factory,xmlWriter);
                                        } if (localInsertResourceLinkTracker){
                                            if (localInsertResourceLink==null){
                                                 throw new org.apache.axis2.databinding.ADBException("InsertResourceLink cannot be null!!");
                                            }
                                           localInsertResourceLink.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","InsertResourceLink"),
                                               factory,xmlWriter);
                                        }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localComputedColumnsTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                                      "ComputedColumns"));
                            
                            
                                    if (localComputedColumns==null){
                                         throw new org.apache.axis2.databinding.ADBException("ComputedColumns cannot be null!!");
                                    }
                                    elementList.add(localComputedColumns);
                                } if (localColumnsTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                                      "Columns"));
                            
                            
                                    if (localColumns==null){
                                         throw new org.apache.axis2.databinding.ADBException("Columns cannot be null!!");
                                    }
                                    elementList.add(localColumns);
                                } if (localInsertTextTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                                      "InsertText"));
                            
                            
                                    if (localInsertText==null){
                                         throw new org.apache.axis2.databinding.ADBException("InsertText cannot be null!!");
                                    }
                                    elementList.add(localInsertText);
                                } if (localInsertResourceLinkTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                                      "InsertResourceLink"));
                            
                            
                                    if (localInsertResourceLink==null){
                                         throw new org.apache.axis2.databinding.ADBException("InsertResourceLink cannot be null!!");
                                    }
                                    elementList.add(localInsertResourceLink);
                                }
                            attribList.add(
                            new javax.xml.namespace.QName("","WorkItemID"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWorkItemID));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","Revision"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRevision));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ObjectType"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localObjectType));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static UpdateWorkItem_type0 parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            UpdateWorkItem_type0 object =
                new UpdateWorkItem_type0();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"UpdateWorkItem_type0".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (UpdateWorkItem_type0)org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "WorkItemID"
                    java.lang.String tempAttribWorkItemID =
                        
                                reader.getAttributeValue(null,"WorkItemID");
                            
                   if (tempAttribWorkItemID!=null){
                         java.lang.String content = tempAttribWorkItemID;
                        
                                                 object.setWorkItemID(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribWorkItemID));
                                            
                    } else {
                       
                                           object.setWorkItemID(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("WorkItemID");
                    
                    // handle attribute "Revision"
                    java.lang.String tempAttribRevision =
                        
                                reader.getAttributeValue(null,"Revision");
                            
                   if (tempAttribRevision!=null){
                         java.lang.String content = tempAttribRevision;
                        
                                                 object.setRevision(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribRevision));
                                            
                    } else {
                       
                                           object.setRevision(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("Revision");
                    
                    // handle attribute "ObjectType"
                    java.lang.String tempAttribObjectType =
                        
                                reader.getAttributeValue(null,"ObjectType");
                            
                   if (tempAttribObjectType!=null){
                         java.lang.String content = tempAttribObjectType;
                        
                                                 object.setObjectType(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribObjectType));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ObjectType");
                    
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","ComputedColumns").equals(reader.getName())){
                                
                                                object.setComputedColumns(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ComputedColumns_type0.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","Columns").equals(reader.getName())){
                                
                                                object.setColumns(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Columns_type0.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","InsertText").equals(reader.getName())){
                                
                                                object.setInsertText(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertText_type0.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03","InsertResourceLink").equals(reader.getName())){
                                
                                                object.setInsertResourceLink(org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.InsertResourceLink_type0.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          