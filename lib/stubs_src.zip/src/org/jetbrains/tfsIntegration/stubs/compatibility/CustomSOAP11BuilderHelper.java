package org.jetbrains.tfsIntegration.stubs.compatibility;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.impl.OMNodeEx;
import org.apache.axiom.om.impl.exception.OMBuilderException;
import org.apache.axiom.soap.*;

import org.w3c.dom.Element;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;


// copy of SOAP11BuilderHelper class
public class CustomSOAP11BuilderHelper extends CustomSOAPBuilderHelper
    implements SOAP11Constants {
    private SOAPFactory factory;
    private boolean faultcodePresent = false;
    private boolean faultstringPresent = false;

    public CustomSOAP11BuilderHelper(CustomStAXSOAPModelBuilder builder) {
        super(builder);
        factory = builder.getSoapFactory();
    }

    public OMElement handleEvent(XMLStreamReader parser, OMElement parent,
        int elementLevel) throws SOAPProcessingException {
        this.parser = parser;

        OMElement element = null;
        String localName = parser.getLocalName();

        if (elementLevel == 4) {
            if (SOAP_FAULT_CODE_LOCAL_NAME.equals(localName)) {
                SOAPFaultCode code = factory.createSOAPFaultCode((SOAPFault) parent,
                        builder);
                processNamespaceData(code, false);
                processAttributes(code);

                processText(parser, code);
                ((OMNodeEx) code).setComplete(true);
                element = code;
                builder.elementLevel--;

                faultcodePresent = true;
            } else if (SOAP_FAULT_STRING_LOCAL_NAME.equals(localName)) {
                SOAPFaultReason reason = factory.createSOAPFaultReason((SOAPFault) parent,
                        builder);
                processNamespaceData(reason, false);
                processAttributes(reason);

                processText(parser, reason);
                ((OMNodeEx) reason).setComplete(true);
                element = reason;
                builder.elementLevel--;

                faultstringPresent = true;
            } else if (SOAP_FAULT_ACTOR_LOCAL_NAME.equals(localName)) {
                element = factory.createSOAPFaultRole((SOAPFault) parent,
                        builder);
                processNamespaceData(element, false);
                processAttributes(element);
            } else if (SOAP_FAULT_DETAIL_LOCAL_NAME.equals(localName)) {
                element = factory.createSOAPFaultDetail((SOAPFault) parent,
                        builder);
                processNamespaceData(element, false);
                processAttributes(element);
            } else {
                element = factory.createOMElement(localName, null, parent,
                        builder);
                processNamespaceData(element, false);
                processAttributes(element);
            }
        } else if (elementLevel == 5) {
            String parentTagName = "";

            if (parent instanceof Element) {
                parentTagName = ((Element) parent).getTagName();
            } else {
                parentTagName = parent.getLocalName();
            }

            if (parentTagName.equals(SOAP_FAULT_CODE_LOCAL_NAME)) {
                throw new OMBuilderException(
                    "faultcode element should not have children");
            } else if (parentTagName.equals(SOAP_FAULT_STRING_LOCAL_NAME)) {
                throw new OMBuilderException(
                    "faultstring element should not have children");
            } else if (parentTagName.equals(SOAP_FAULT_ACTOR_LOCAL_NAME)) {
                throw new OMBuilderException(
                    "faultactor element should not have children");
            } else {
                element = this.factory.createOMElement(localName, null, parent,
                        builder);
                processNamespaceData(element, false);
                processAttributes(element);
            }
        } else if (elementLevel > 5) {
            element = this.factory.createOMElement(localName, null, parent,
                    builder);
            processNamespaceData(element, false);
            processAttributes(element);
        }

        return element;
    }

    private void processText(XMLStreamReader parser, OMElement value) {
        try {
            int token = parser.next();

            while (token != XMLStreamReader.END_ELEMENT) {
                if (token == XMLStreamReader.CHARACTERS) {
                    factory.createOMText(value, parser.getText());
                } else {
                    throw new SOAPProcessingException(
                        "Only Characters are allowed here");
                }

                token = parser.next();
            }
        } catch (XMLStreamException e) {
            throw new SOAPProcessingException(e);
        }
    }
}
