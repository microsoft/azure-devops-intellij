package org.jetbrains.tfsIntegration.stubs.compatibility;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.impl.builder.StAXBuilder;
import org.apache.axiom.om.util.StAXUtils;
import org.apache.axiom.soap.SOAPEnvelope;

import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.builder.BuilderUtil;
import org.apache.axis2.builder.SOAPBuilder;
import org.apache.axis2.context.MessageContext;

import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;


//uses CustomStAXSOAPModelBuilder
public class CustomSOAPBuilder extends SOAPBuilder {
    public OMElement processDocument(InputStream inputStream,
        String contentType, MessageContext messageContext)
        throws AxisFault {
        XMLStreamReader streamReader;

        try {
            String charSetEncoding = (String) messageContext.getProperty(Constants.Configuration.CHARACTER_SET_ENCODING);

            // Get the actual encoding by looking at the BOM of the InputStream
            PushbackInputStream pis = BuilderUtil.getPushbackInputStream(inputStream);
            String actualCharSetEncoding = BuilderUtil.getCharSetEncoding(pis,
                    charSetEncoding);

            // Get the XMLStreamReader for this input stream
            streamReader = StAXUtils.createXMLStreamReader(pis,
                    actualCharSetEncoding);

            StAXBuilder builder = new CustomStAXSOAPModelBuilder(streamReader);
            SOAPEnvelope envelope = (SOAPEnvelope) builder.getDocumentElement();
            BuilderUtil.validateSOAPVersion(BuilderUtil.getEnvelopeNamespace(
                    contentType), envelope);
            BuilderUtil.validateCharSetEncoding(charSetEncoding,
                builder.getDocument().getCharsetEncoding(),
                envelope.getNamespace().getNamespaceURI());

            return envelope;
        } catch (IOException e) {
            throw AxisFault.makeFault(e);
        } catch (XMLStreamException e) {
            throw AxisFault.makeFault(e);
        }
    }
}
