package org.jetbrains.tfsIntegration.stubs.compatibility;

import java.util.Iterator;

import javax.xml.namespace.QName;

import org.apache.axiom.om.OMAttribute;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNode;
import org.apache.axiom.om.OMText;
import org.apache.axiom.om.OMXMLParserWrapper;
import org.apache.axiom.om.impl.llom.OMElementImpl;
import org.apache.axiom.om.impl.llom.OMTextImpl;
import org.apache.axiom.soap.SOAP12Constants;
import org.apache.axiom.soap.SOAPBody;
import org.apache.axiom.soap.SOAPFault;
import org.apache.axiom.soap.SOAPFaultDetail;
import org.apache.axiom.soap.impl.llom.soap12.SOAP12Factory;
import org.apache.axiom.soap.impl.llom.soap12.SOAP12FaultImpl;

public class CustomSOAP12Factory extends SOAP12Factory {

	public SOAPFault createSOAPFault(SOAPBody parent, OMXMLParserWrapper builder) {

		return new SOAP12FaultImpl(parent, builder, this) {
			@Override
			public SOAPFaultDetail getDetail() {
				SOAPFaultDetail detail = super.getDetail();
				if (detail == null) {
					// try with no namespace
					detail = (SOAPFaultDetail) getFirstChildWithName(new QName(SOAP12Constants.SOAP_FAULT_DETAIL_LOCAL_NAME));
				}
				if (detail != null) {
					// Axis takes the first child and ignores attributes -> make
					// a copy and append it as a child
					detail.addChild(detail.cloneOMElement());
				}
				return detail;
			}
		};
	}

}
