package org.jetbrains.tfsIntegration.stubs.compatibility;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.exception.OMBuilderException;
import org.apache.axiom.soap.SOAP11Constants;
import org.apache.axiom.soap.SOAP12Constants;
import org.apache.axiom.soap.SOAPProcessingException;

import javax.xml.stream.XMLStreamReader;


// copy of SOAPBuilderHelper class
public abstract class CustomSOAPBuilderHelper {
    protected CustomStAXSOAPModelBuilder builder;
    protected XMLStreamReader parser;

    protected CustomSOAPBuilderHelper(CustomStAXSOAPModelBuilder builder) {
        this.builder = builder;
    }

    public abstract OMElement handleEvent(XMLStreamReader parser,
        OMElement element, int elementLevel) throws SOAPProcessingException;

    protected void processNamespaceData(OMElement node,
        boolean checkSOAPNamespace) {
        int namespaceCount = parser.getNamespaceCount();

        for (int i = 0; i < namespaceCount; i++) {
            String namespaceURI = parser.getNamespaceURI(i);

            if (namespaceURI != null) {
                node.declareNamespace(parser.getNamespaceURI(i),
                    parser.getNamespacePrefix(i));
            }
        }

        // set the own namespace
        String namespaceURI = parser.getNamespaceURI();
        String prefix = parser.getPrefix();
        OMNamespace namespace = null;

        if ((namespaceURI != null) && (namespaceURI.length() > 0)) {
            if (prefix == null) {
                // this means, this elements has a default namespace or it has inherited a default namespace from its parent
                namespace = node.findNamespace(namespaceURI, "");

                if (namespace == null) {
                    namespace = node.declareNamespace(namespaceURI, "");
                }
            } else {
                namespace = node.findNamespace(namespaceURI, prefix);
            }

            node.setNamespace(namespace);
        }

        // TODO we got to have this to make sure OM reject mesagess that are not name space qualified
        // But got to comment this to interop with Axis.1.x
        // if (namespace == null) {
        // throw new OMException("All elements must be namespace qualified!");
        // }
        if (checkSOAPNamespace) {
            if ((node.getNamespace() != null) &&
                    !node.getNamespace().getNamespaceURI()
                             .equals(SOAP11Constants.SOAP_ENVELOPE_NAMESPACE_URI) &&
                    !node.getNamespace().getNamespaceURI()
                             .equals(SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI)) {
                throw new OMBuilderException("invalid SOAP namespace URI");
            }
        }
    }

    protected void processAttributes(OMElement node) {
        int attribCount = parser.getAttributeCount();

        for (int i = 0; i < attribCount; i++) {
            OMNamespace ns = null;
            String uri = parser.getAttributeNamespace(i);

            if ((uri != null) && (uri.hashCode() != 0)) {
                ns = node.findNamespace(uri, parser.getAttributePrefix(i));
            }

            // todo if the attributes are supposed to namespace qualified all the time
            // todo then this should throw an exception here
            node.addAttribute(parser.getAttributeLocalName(i),
                parser.getAttributeValue(i), ns);
        }
    }
}
