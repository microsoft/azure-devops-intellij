

/**
 * RegistrationRegistrationSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  RegistrationRegistrationSoap java interface
     */

    public interface RegistrationRegistrationSoap {
          

        /**
          * Auto generated method signature
          * 
                    * @param getRegistrationEntries4
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.services.registration.GetRegistrationEntriesResponse GetRegistrationEntries(

                        org.jetbrains.tfsIntegration.stubs.services.registration.GetRegistrationEntries getRegistrationEntries4)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    