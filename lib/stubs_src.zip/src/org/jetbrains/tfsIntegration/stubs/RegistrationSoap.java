/**
 * RegistrationRegistrationSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  RegistrationSoap java interface
 */
public interface RegistrationSoap {
    /**
     * Auto generated method signature
     * @param getRegistrationEntries8
     */
    public org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfRegistrationEntry GetRegistrationEntries(
        java.lang.String toolId9) throws java.rmi.RemoteException;

    //
}
