/**
 * ClientServiceClientServiceSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClientServiceClientServiceSoap12 java interface
 */
public interface ClientServiceClientServiceSoap12 {
    /**
     * Auto generated method signature
     * @param getWorkitemTrackingVersion277
     * @param requestHeader278
     */
    public java.lang.String GetWorkitemTrackingVersion(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion277,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader278)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param stampWorkitemCache281
     * @param requestHeader282
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache281,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader282)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getReferencingWorkitemUris284
     * @param requestHeader286
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString GetReferencingWorkitemUris(
        java.lang.String artifactUri285,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader286)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getWorkItem289
     * @param requestHeader296
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(
        int workItemId290, int revisionId291, int minimumRevisionId292,
        java.util.Calendar asOfDate293, boolean useMaster294,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave295,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader296)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitems298
     * @param requestHeader303
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 psQuery299,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfQuerySortOrderEntry sort300,
        boolean useMaster301,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave302,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader303)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIds305
     * @param requestHeader312
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids306,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns307,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns308,
        java.util.Calendar asOfDate309, boolean useMaster310,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave311,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader312)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIdRevs314
     * @param requestHeader320
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair pairs315,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns316,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns317,
        java.util.Calendar asOfDate318, boolean useMaster319,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader320)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageItemsOnBehalfOf322
     * @param requestHeader326
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 PageItemsOnBehalfOf(
        java.lang.String userName323,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids324,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns325,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader326)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCount329
     * @param requestHeader333
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 psQuery330,
        boolean useMaster331,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave332,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader333)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCountOnBehalfOf335
     * @param requestHeader338
     */
    public int QueryWorkitemCountOnBehalfOf(java.lang.String userName336,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 query337,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader338)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadata341
     * @param requestHeader344
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave342,
        boolean useMaster343,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader344)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx346
     * @param requestHeader349
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave347,
        boolean useMaster348,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader349)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx2351
     * @param requestHeader354
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave352,
        boolean useMaster353,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader354)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param update356
     * @param requestHeader359
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 _package357,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave358,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader359)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param bulkUpdate361
     * @param requestHeader364
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 _package362,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave363,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader364)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQuery366
     * @param requestHeader368
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 GetStoredQuery(
        com.microsoft.wsdl.types.Guid queryId367,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader368)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQueries371
     * @param requestHeader374
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 GetStoredQueries(
        long rowVersion372, int projectId373,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader374)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncExternalStructures377
     * @param requestHeader379
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(
        java.lang.String projectURI378,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader379)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncAccessControlLists381
     * @param requestHeader383
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(
        java.lang.String projectURI382,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader383)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncBisGroupsAndUsers385
     * @param requestHeader387
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(
        java.lang.String projectUri386,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader387)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param requestCancel389
     * @param requestHeader391
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(
        java.lang.String requestIdToCancel390,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader0 requestHeader391)
        throws java.rmi.RemoteException;

    //
}
