/**
 * ClientServiceClientServiceSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  ClientServiceClientServiceSoap12 java interface
 */
public interface ClientServiceClientServiceSoap12 {
    /**
     * Auto generated method signature
     * @param getWorkitemTrackingVersion269
     * @param requestHeader270
     */
    public java.lang.String GetWorkitemTrackingVersion(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion269,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader270)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param stampWorkitemCache273
     * @param requestHeader274
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache273,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader274)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getReferencingWorkitemUris276
     * @param requestHeader278
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString GetReferencingWorkitemUris(
        java.lang.String artifactUri277,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader278)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getWorkItem281
     * @param requestHeader288
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(
        int workItemId282, int revisionId283, int minimumRevisionId284,
        java.util.Calendar asOfDate285, boolean useMaster286,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave287,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader288)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitems290
     * @param requestHeader292
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type1 psQuery291,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader292)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIds294
     * @param requestHeader301
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids295,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns296,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns297,
        java.util.Calendar asOfDate298, boolean useMaster299,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave300,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader301)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageWorkitemsByIdRevs303
     * @param requestHeader309
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfIdRevisionPair pairs304,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns305,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt longTextColumns306,
        java.util.Calendar asOfDate307, boolean useMaster308,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader309)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param pageItemsOnBehalfOf311
     * @param requestHeader315
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Items_type2 PageItemsOnBehalfOf(
        java.lang.String userName312,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfInt ids313,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfString columns314,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader315)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCount318
     * @param requestHeader322
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PsQuery_type0 psQuery319,
        boolean useMaster320,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave321,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader322)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param queryWorkitemCountOnBehalfOf324
     * @param requestHeader327
     */
    public int QueryWorkitemCountOnBehalfOf(java.lang.String userName325,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Query_type0 query326,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader327)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadata330
     * @param requestHeader333
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave331,
        boolean useMaster332,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader333)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx335
     * @param requestHeader338
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave336,
        boolean useMaster337,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader338)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getMetadataEx2340
     * @param requestHeader343
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave341,
        boolean useMaster342,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader343)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param update345
     * @param requestHeader348
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type1 _package346,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave347,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader348)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param bulkUpdate350
     * @param requestHeader353
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Package_type0 _package351,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.ArrayOfMetadataTableHaveEntry metadataHave352,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader353)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQuery355
     * @param requestHeader357
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryPayload_type0 GetStoredQuery(
        com.microsoft.wsdl.types.Guid queryId356,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader357)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param getStoredQueries360
     * @param requestHeader363
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueriesPayload_type0 GetStoredQueries(
        long rowVersion361, int projectId362,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader363)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncExternalStructures366
     * @param requestHeader368
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(
        java.lang.String projectURI367,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader368)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncAccessControlLists370
     * @param requestHeader372
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(
        java.lang.String projectURI371,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader372)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param syncBisGroupsAndUsers374
     * @param requestHeader376
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(
        java.lang.String projectUri375,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader376)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     * @param requestCancel378
     * @param requestHeader380
     */
    public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(
        java.lang.String requestIdToCancel379,
        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeader3 requestHeader380)
        throws java.rmi.RemoteException;

    //
}
