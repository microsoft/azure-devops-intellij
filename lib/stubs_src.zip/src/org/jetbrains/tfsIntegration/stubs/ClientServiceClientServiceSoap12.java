

/**
 * ClientServiceClientServiceSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */

    package org.jetbrains.tfsIntegration.stubs;

    /*
     *  ClientServiceClientServiceSoap12 java interface
     */

    public interface ClientServiceClientServiceSoap12 {
          

        /**
          * Auto generated method signature
          * 
                    * @param syncBisGroupsAndUsers146
                
                    * @param requestHeader147
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsersResponse SyncBisGroupsAndUsers(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncBisGroupsAndUsers syncBisGroupsAndUsers146,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader147)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitemCountOnBehalfOf149
                
                    * @param requestHeader150
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOfResponse QueryWorkitemCountOnBehalfOf(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountOnBehalfOf queryWorkitemCountOnBehalfOf149,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader150)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQuery152
                
                    * @param requestHeader153
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueryResponse GetStoredQuery(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQuery getStoredQuery152,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader153)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getReferencingWorkitemUris155
                
                    * @param requestHeader156
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUrisResponse GetReferencingWorkitemUris(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetReferencingWorkitemUris getReferencingWorkitemUris155,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader156)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQueries158
                
                    * @param requestHeader159
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueriesResponse GetStoredQueries(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetStoredQueries getStoredQueries158,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader159)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadata161
                
                    * @param requestHeader162
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataResponse GetMetadata(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadata getMetadata161,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader162)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageWorkitemsByIdRevs164
                
                    * @param requestHeader165
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevsResponse PageWorkitemsByIdRevs(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdRevs pageWorkitemsByIdRevs164,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader165)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param syncAccessControlLists167
                
                    * @param requestHeader168
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlListsResponse SyncAccessControlLists(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncAccessControlLists syncAccessControlLists167,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader168)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param stampWorkitemCache170
                
                    * @param requestHeader171
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCacheResponse StampWorkitemCache(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.StampWorkitemCache stampWorkitemCache170,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader171)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param bulkUpdate173
                
                    * @param requestHeader174
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdateResponse BulkUpdate(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.BulkUpdate bulkUpdate173,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader174)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadataEx2176
                
                    * @param requestHeader177
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2Response GetMetadataEx2(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx2 getMetadataEx2176,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader177)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param requestCancel179
                
                    * @param requestHeader180
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancelResponse RequestCancel(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestCancel requestCancel179,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader180)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageItemsOnBehalfOf182
                
                    * @param requestHeader183
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOfResponse PageItemsOnBehalfOf(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageItemsOnBehalfOf pageItemsOnBehalfOf182,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader183)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getWorkItem185
                
                    * @param requestHeader186
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItemResponse GetWorkItem(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkItem getWorkItem185,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader186)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param syncExternalStructures188
                
                    * @param requestHeader189
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructuresResponse SyncExternalStructures(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.SyncExternalStructures syncExternalStructures188,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader189)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getWorkitemTrackingVersion191
                
                    * @param requestHeader192
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersionResponse GetWorkitemTrackingVersion(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetWorkitemTrackingVersion getWorkitemTrackingVersion191,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader192)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param update194
                
                    * @param requestHeader195
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.UpdateResponse Update(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.Update update194,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader195)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitemCount197
                
                    * @param requestHeader198
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCountResponse QueryWorkitemCount(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemCount queryWorkitemCount197,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader198)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitems200
                
                    * @param requestHeader201
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitemsResponse QueryWorkitems(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.QueryWorkitems queryWorkitems200,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader201)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadataEx203
                
                    * @param requestHeader204
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataExResponse GetMetadataEx(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.GetMetadataEx getMetadataEx203,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader204)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageWorkitemsByIds206
                
                    * @param requestHeader207
                
         */

         
                     public org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIdsResponse PageWorkitemsByIds(

                        org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.PageWorkitemsByIds pageWorkitemsByIds206,org.jetbrains.tfsIntegration.stubs.workitemtracking.clientservices.RequestHeaderE requestHeader207)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    