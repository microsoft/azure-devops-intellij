/**
 * RegistrationRegistrationSoap12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.3  Built on : Aug 10, 2007 (04:45:47 LKT)
 */
package org.jetbrains.tfsIntegration.stubs;


/*
 *  RegistrationSoap12 java interface
 */
public interface RegistrationSoap12 {
    /**
     * Auto generated method signature
     * @param getRegistrationEntries
     */
    public org.jetbrains.tfsIntegration.stubs.services.registration.ArrayOfRegistrationEntry GetRegistrationEntries(
        java.lang.String toolId) throws java.rmi.RemoteException;

    //
}
