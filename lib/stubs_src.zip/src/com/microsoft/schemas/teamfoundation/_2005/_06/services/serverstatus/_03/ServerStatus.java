

/**
 * ServerStatus.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03;

    /*
     *  ServerStatus java interface
     */

    public interface ServerStatus {
          

        /**
          * Auto generated method signature
          * 
                    * @param checkAuthentication
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.CheckAuthenticationResponse checkAuthentication(

                        com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.CheckAuthentication checkAuthentication)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getServerStatus
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.GetServerStatusResponse getServerStatus(

                        com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.GetServerStatus getServerStatus)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getSupportedContractVersion
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.GetSupportedContractVersionResponse getSupportedContractVersion(

                        com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.GetSupportedContractVersion getSupportedContractVersion)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    