

/**
 * GroupSecurityService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03;

    /*
     *  GroupSecurityService java interface
     */

    public interface GroupSecurityService {
          

        /**
          * Auto generated method signature
          * 
                    * @param createApplicationGroup
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.CreateApplicationGroupResponse createApplicationGroup(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.CreateApplicationGroup createApplicationGroup)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getChangedIdentities
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.GetChangedIdentitiesResponse getChangedIdentities(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.GetChangedIdentities getChangedIdentities)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateApplicationGroup
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.UpdateApplicationGroupResponse updateApplicationGroup(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.UpdateApplicationGroup updateApplicationGroup)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteApplicationGroup
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.DeleteApplicationGroupResponse deleteApplicationGroup(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.DeleteApplicationGroup deleteApplicationGroup)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeMemberFromApplicationGroup
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.RemoveMemberFromApplicationGroupResponse removeMemberFromApplicationGroup(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.RemoveMemberFromApplicationGroup removeMemberFromApplicationGroup)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param addMemberToApplicationGroup
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.AddMemberToApplicationGroupResponse addMemberToApplicationGroup(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.AddMemberToApplicationGroup addMemberToApplicationGroup)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param readIdentity
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.ReadIdentityResponse readIdentity(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.ReadIdentity readIdentity)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param readIdentityFromSource
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.ReadIdentityFromSourceResponse readIdentityFromSource(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.ReadIdentityFromSource readIdentityFromSource)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param isIdentityCached
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.IsIdentityCachedResponse isIdentityCached(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.IsIdentityCached isIdentityCached)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param isMember
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.IsMemberResponse isMember(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.IsMember isMember)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listApplicationGroups
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.ListApplicationGroupsResponse listApplicationGroups(

                        com.microsoft.schemas.teamfoundation._2005._06.services.groupsecurity._03.ListApplicationGroups listApplicationGroups)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    