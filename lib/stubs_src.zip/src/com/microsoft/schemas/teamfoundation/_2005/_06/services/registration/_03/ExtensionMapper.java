
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.schemas.teamfoundation._2005._06.services.registration._03;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "OutboundLinkType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.OutboundLinkType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationExtendedAttribute2".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.RegistrationExtendedAttribute2.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfFrameworkRegistrationEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfFrameworkRegistrationEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationServiceInterface".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.RegistrationServiceInterface.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationDatabase".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.RegistrationDatabase.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationExtendedAttribute2".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfRegistrationExtendedAttribute2.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationArtifactType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfRegistrationArtifactType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfOutboundLinkType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfOutboundLinkType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "FrameworkRegistrationEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.FrameworkRegistrationEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationDatabase".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfRegistrationDatabase.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ChangeType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ChangeType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationEventType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.RegistrationEventType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationEventType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfRegistrationEventType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "ArrayOfRegistrationServiceInterface".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.ArrayOfRegistrationServiceInterface.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Registration/03".equals(namespaceURI) &&
                  "RegistrationArtifactType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.RegistrationArtifactType.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    