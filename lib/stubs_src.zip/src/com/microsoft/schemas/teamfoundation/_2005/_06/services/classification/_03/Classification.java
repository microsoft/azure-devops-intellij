

/**
 * Classification.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.schemas.teamfoundation._2005._06.services.classification._03;

    /*
     *  Classification java interface
     */

    public interface Classification {
          

        /**
          * Auto generated method signature
          * 
                    * @param createNode
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.CreateNodeResponse createNode(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.CreateNode createNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNodesXml
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNodesXmlResponse getNodesXml(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNodesXml getNodesXml)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProjectProperties
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetProjectPropertiesResponse getProjectProperties(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetProjectProperties getProjectProperties)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listProjects
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ListProjectsResponse listProjects(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ListProjects listProjects)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNodeFromPath
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNodeFromPathResponse getNodeFromPath(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNodeFromPath getNodeFromPath)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteProject
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.DeleteProjectResponse deleteProject(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.DeleteProject deleteProject)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProject
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetProjectResponse getProject(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetProject getProject)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteBranches
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.DeleteBranchesResponse deleteBranches(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.DeleteBranches deleteBranches)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getNode
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNodeResponse getNode(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNode getNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getDeletedNodesXml
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetDeletedNodesXmlResponse getDeletedNodesXml(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetDeletedNodesXml getDeletedNodesXml)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createProject
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.CreateProjectResponse createProject(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.CreateProject createProject)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param reorderNode
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ReorderNodeResponse reorderNode(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ReorderNode reorderNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listStructures
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ListStructuresResponse listStructures(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ListStructures listStructures)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param renameNode
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.RenameNodeResponse renameNode(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.RenameNode renameNode)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getProjectFromName
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetProjectFromNameResponse getProjectFromName(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetProjectFromName getProjectFromName)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param moveBranch
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.MoveBranchResponse moveBranch(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.MoveBranch moveBranch)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateProjectProperties
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.UpdateProjectPropertiesResponse updateProjectProperties(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.UpdateProjectProperties updateProjectProperties)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getChangedNodes
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetChangedNodesResponse getChangedNodes(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetChangedNodes getChangedNodes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param listAllProjects
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ListAllProjectsResponse listAllProjects(

                        com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ListAllProjects listAllProjects)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    