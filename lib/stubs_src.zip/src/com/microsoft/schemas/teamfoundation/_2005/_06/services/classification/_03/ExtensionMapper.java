
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.schemas.teamfoundation._2005._06.services.classification._03;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ArrayOfNodeInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ArrayOfNodeInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ProjectState".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ProjectState.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "GetNodesXmlResult_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetNodesXmlResult_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ProjectProperty".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ProjectProperty.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ArrayOfProjectProperty".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ArrayOfProjectProperty.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ArrayOfProjectInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ArrayOfProjectInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "NodeInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.NodeInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "structure_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.Structure_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "GetDeletedNodesXmlResult_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.GetDeletedNodesXmlResult_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ProjectInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ProjectInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "Property".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.Property.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ArrayOfProperty".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ArrayOfProperty.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/Classification/03".equals(namespaceURI) &&
                  "ArrayOfString".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.classification._03.ArrayOfString.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    