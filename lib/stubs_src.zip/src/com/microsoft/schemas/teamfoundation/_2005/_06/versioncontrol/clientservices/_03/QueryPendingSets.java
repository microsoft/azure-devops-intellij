
/**
 * QueryPendingSets.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */
            
                package com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03;
            

            /**
            *  QueryPendingSets bean class
            */
        
        public  class QueryPendingSets
        implements org.apache.axis2.databinding.ADBBean{
        
                public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "QueryPendingSets",
                "");

            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for LocalWorkspaceName
                        */

                        
                                    protected java.lang.String localLocalWorkspaceName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocalWorkspaceNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocalWorkspaceName(){
                               return localLocalWorkspaceName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocalWorkspaceName
                               */
                               public void setLocalWorkspaceName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLocalWorkspaceNameTracker = true;
                                       } else {
                                          localLocalWorkspaceNameTracker = false;
                                              
                                       }
                                   
                                            this.localLocalWorkspaceName=param;
                                    

                               }
                            

                        /**
                        * field for LocalWorkspaceOwner
                        */

                        
                                    protected java.lang.String localLocalWorkspaceOwner ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocalWorkspaceOwnerTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocalWorkspaceOwner(){
                               return localLocalWorkspaceOwner;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocalWorkspaceOwner
                               */
                               public void setLocalWorkspaceOwner(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLocalWorkspaceOwnerTracker = true;
                                       } else {
                                          localLocalWorkspaceOwnerTracker = false;
                                              
                                       }
                                   
                                            this.localLocalWorkspaceOwner=param;
                                    

                               }
                            

                        /**
                        * field for QueryWorkspaceName
                        */

                        
                                    protected java.lang.String localQueryWorkspaceName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localQueryWorkspaceNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getQueryWorkspaceName(){
                               return localQueryWorkspaceName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param QueryWorkspaceName
                               */
                               public void setQueryWorkspaceName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localQueryWorkspaceNameTracker = true;
                                       } else {
                                          localQueryWorkspaceNameTracker = false;
                                              
                                       }
                                   
                                            this.localQueryWorkspaceName=param;
                                    

                               }
                            

                        /**
                        * field for OwnerName
                        */

                        
                                    protected java.lang.String localOwnerName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOwnerNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getOwnerName(){
                               return localOwnerName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OwnerName
                               */
                               public void setOwnerName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localOwnerNameTracker = true;
                                       } else {
                                          localOwnerNameTracker = false;
                                              
                                       }
                                   
                                            this.localOwnerName=param;
                                    

                               }
                            

                        /**
                        * field for ItemSpecs
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSpec localItemSpecs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localItemSpecsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSpec getItemSpecs(){
                               return localItemSpecs;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ItemSpecs
                               */
                               public void setItemSpecs(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localItemSpecsTracker = true;
                                       } else {
                                          localItemSpecsTracker = false;
                                              
                                       }
                                   
                                            this.localItemSpecs=param;
                                    

                               }
                            

                        /**
                        * field for GenerateDownloadUrls
                        */

                        
                                    protected boolean localGenerateDownloadUrls ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getGenerateDownloadUrls(){
                               return localGenerateDownloadUrls;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GenerateDownloadUrls
                               */
                               public void setGenerateDownloadUrls(boolean param){
                            
                                            this.localGenerateDownloadUrls=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
                org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,MY_QNAME){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       QueryPendingSets.this.serialize(MY_QNAME,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               MY_QNAME,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":QueryPendingSets",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "QueryPendingSets",
                           xmlWriter);
                   }

               
                   }
                if (localLocalWorkspaceNameTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"localWorkspaceName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"localWorkspaceName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("localWorkspaceName");
                                    }
                                

                                          if (localLocalWorkspaceName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("localWorkspaceName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLocalWorkspaceName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocalWorkspaceOwnerTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"localWorkspaceOwner", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"localWorkspaceOwner");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("localWorkspaceOwner");
                                    }
                                

                                          if (localLocalWorkspaceOwner==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("localWorkspaceOwner cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLocalWorkspaceOwner);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localQueryWorkspaceNameTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"queryWorkspaceName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"queryWorkspaceName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("queryWorkspaceName");
                                    }
                                

                                          if (localQueryWorkspaceName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("queryWorkspaceName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localQueryWorkspaceName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOwnerNameTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"ownerName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"ownerName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("ownerName");
                                    }
                                

                                          if (localOwnerName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("ownerName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localOwnerName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localItemSpecsTracker){
                                            if (localItemSpecs==null){
                                                 throw new org.apache.axis2.databinding.ADBException("itemSpecs cannot be null!!");
                                            }
                                           localItemSpecs.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","itemSpecs"),
                                               factory,xmlWriter);
                                        }
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"generateDownloadUrls", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"generateDownloadUrls");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("generateDownloadUrls");
                                    }
                                
                                               if (false) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("generateDownloadUrls cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGenerateDownloadUrls));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localLocalWorkspaceNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "localWorkspaceName"));
                                 
                                        if (localLocalWorkspaceName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocalWorkspaceName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("localWorkspaceName cannot be null!!");
                                        }
                                    } if (localLocalWorkspaceOwnerTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "localWorkspaceOwner"));
                                 
                                        if (localLocalWorkspaceOwner != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocalWorkspaceOwner));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("localWorkspaceOwner cannot be null!!");
                                        }
                                    } if (localQueryWorkspaceNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "queryWorkspaceName"));
                                 
                                        if (localQueryWorkspaceName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localQueryWorkspaceName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("queryWorkspaceName cannot be null!!");
                                        }
                                    } if (localOwnerNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "ownerName"));
                                 
                                        if (localOwnerName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOwnerName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("ownerName cannot be null!!");
                                        }
                                    } if (localItemSpecsTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "itemSpecs"));
                            
                            
                                    if (localItemSpecs==null){
                                         throw new org.apache.axis2.databinding.ADBException("itemSpecs cannot be null!!");
                                    }
                                    elementList.add(localItemSpecs);
                                }
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "generateDownloadUrls"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGenerateDownloadUrls));
                            

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static QueryPendingSets parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            QueryPendingSets object =
                new QueryPendingSets();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"QueryPendingSets".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (QueryPendingSets)com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","localWorkspaceName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocalWorkspaceName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","localWorkspaceOwner").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocalWorkspaceOwner(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","queryWorkspaceName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setQueryWorkspaceName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","ownerName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setOwnerName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","itemSpecs").equals(reader.getName())){
                                
                                                object.setItemSpecs(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","generateDownloadUrls").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGenerateDownloadUrls(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                else{
                                    // A start element we are not expecting indicates an invalid parameter was passed
                                    throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                                }
                              
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          