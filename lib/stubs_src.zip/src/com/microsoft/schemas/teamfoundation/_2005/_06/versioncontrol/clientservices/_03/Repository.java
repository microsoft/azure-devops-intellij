

/**
 * Repository.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03;

    /*
     *  Repository java interface
     */

    public interface Repository {
          

        /**
          * Auto generated method signature
          * 
                    * @param checkIn
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckInResponse checkIn(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckIn checkIn)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryShelvesets
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryShelvesetsResponse queryShelvesets(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryShelvesets queryShelvesets)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryFileTypes
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryFileTypesResponse queryFileTypes(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryFileTypes queryFileTypes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createTeamProjectFolder
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateTeamProjectFolderResponse createTeamProjectFolder(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateTeamProjectFolder createTeamProjectFolder)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingSets
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryPendingSetsResponse queryPendingSets(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryPendingSets queryPendingSets)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getRepositoryProperties
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.GetRepositoryPropertiesResponse getRepositoryProperties(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.GetRepositoryProperties getRepositoryProperties)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param resolve
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ResolveResponse resolve(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Resolve resolve)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param setFileTypes
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.SetFileTypesResponse setFileTypes(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.SetFileTypes setFileTypes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryHistory
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryHistoryResponse queryHistory(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryHistory queryHistory)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingChangesForWorkspace
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryPendingChangesForWorkspaceResponse queryPendingChangesForWorkspace(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryPendingChangesForWorkspace queryPendingChangesForWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMerges
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryMergesResponse queryMerges(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryMerges queryMerges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMergeCandidates
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryMergeCandidatesResponse queryMergeCandidates(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryMergeCandidates queryMergeCandidates)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkspace
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryWorkspaceResponse queryWorkspace(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryWorkspace queryWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param merge
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.MergeResponse merge(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Merge merge)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateGlobalSecurity
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateGlobalSecurityResponse updateGlobalSecurity(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateGlobalSecurity updateGlobalSecurity)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryAnnotation
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryAnnotationResponse queryAnnotation(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryAnnotation queryAnnotation)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryMergesWithDetails
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryMergesWithDetailsResponse queryMergesWithDetails(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryMergesWithDetails queryMergesWithDetails)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryCheckinNoteDefinition
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryCheckinNoteDefinitionResponse queryCheckinNoteDefinition(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryCheckinNoteDefinition queryCheckinNoteDefinition)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateItemSecurity
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateItemSecurityResponse updateItemSecurity(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateItemSecurity updateItemSecurity)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryChangeset
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryChangesetResponse queryChangeset(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryChangeset queryChangeset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateWorkspace
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateWorkspaceResponse updateWorkspace(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateWorkspace updateWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param unshelve
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UnshelveResponse unshelve(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Unshelve unshelve)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param addConflict
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.AddConflictResponse addConflict(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.AddConflict addConflict)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteShelveset
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteShelvesetResponse deleteShelveset(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteShelveset deleteShelveset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteAnnotation
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteAnnotationResponse deleteAnnotation(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteAnnotation deleteAnnotation)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param checkAuthentication
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckAuthenticationResponse checkAuthentication(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckAuthentication checkAuthentication)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryLocalVersions
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryLocalVersionsResponse queryLocalVersions(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryLocalVersions queryLocalVersions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createAnnotation
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateAnnotationResponse createAnnotation(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateAnnotation createAnnotation)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryPendingChangesById
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryPendingChangesByIdResponse queryPendingChangesById(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryPendingChangesById queryPendingChangesById)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryConflicts
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryConflictsResponse queryConflicts(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryConflicts queryConflicts)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryEffectiveItemPermissions
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryEffectiveItemPermissionsResponse queryEffectiveItemPermissions(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryEffectiveItemPermissions queryEffectiveItemPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param get
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.GetResponse get(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Get get)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemPermissions
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemPermissionsResponse queryItemPermissions(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemPermissions queryItemPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param unlabelItem
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UnlabelItemResponse unlabelItem(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UnlabelItem unlabelItem)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pendChanges
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PendChangesResponse pendChanges(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PendChanges pendChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateChangeset
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateChangesetResponse updateChangeset(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateChangeset updateChangeset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryLabels
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryLabelsResponse queryLabels(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryLabels queryLabels)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param checkPendingChanges
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckPendingChangesResponse checkPendingChanges(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckPendingChanges checkPendingChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param destroy
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DestroyResponse destroy(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Destroy destroy)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param refreshIdentityDisplayName
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RefreshIdentityDisplayNameResponse refreshIdentityDisplayName(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RefreshIdentityDisplayName refreshIdentityDisplayName)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemsById
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemsByIdResponse queryItemsById(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemsById queryItemsById)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param shelve
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ShelveResponse shelve(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Shelve shelve)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryBranches
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryBranchesResponse queryBranches(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryBranches queryBranches)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryChangesForChangeset
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryChangesForChangesetResponse queryChangesForChangeset(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryChangesForChangeset queryChangesForChangeset)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateCheckinNoteFieldName
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateCheckinNoteFieldNameResponse updateCheckinNoteFieldName(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateCheckinNoteFieldName updateCheckinNoteFieldName)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteLabel
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteLabelResponse deleteLabel(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteLabel deleteLabel)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryShelvedChanges
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryShelvedChangesResponse queryShelvedChanges(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryShelvedChanges queryShelvedChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createWorkspace
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateWorkspaceResponse createWorkspace(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateWorkspace createWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkspaces
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryWorkspacesResponse queryWorkspaces(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryWorkspaces queryWorkspaces)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updateLocalVersion
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateLocalVersionResponse updateLocalVersion(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdateLocalVersion updateLocalVersion)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param undoPendingChanges
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UndoPendingChangesResponse undoPendingChanges(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UndoPendingChanges undoPendingChanges)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryCheckinNoteFieldNames
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryCheckinNoteFieldNamesResponse queryCheckinNoteFieldNames(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryCheckinNoteFieldNames queryCheckinNoteFieldNames)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param deleteWorkspace
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteWorkspaceResponse deleteWorkspace(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeleteWorkspace deleteWorkspace)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param updatePendingState
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdatePendingStateResponse updatePendingState(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.UpdatePendingState updatePendingState)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItems
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemsResponse queryItems(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItems queryItems)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryItemsExtended
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemsExtendedResponse queryItemsExtended(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryItemsExtended queryItemsExtended)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createCheckinNoteDefinition
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateCheckinNoteDefinitionResponse createCheckinNoteDefinition(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateCheckinNoteDefinition createCheckinNoteDefinition)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryGlobalPermissions
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryGlobalPermissionsResponse queryGlobalPermissions(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryGlobalPermissions queryGlobalPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeLocalConflict
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RemoveLocalConflictResponse removeLocalConflict(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RemoveLocalConflict removeLocalConflict)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryEffectiveGlobalPermissions
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryEffectiveGlobalPermissionsResponse queryEffectiveGlobalPermissions(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.QueryEffectiveGlobalPermissions queryEffectiveGlobalPermissions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param createBranch
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateBranchResponse createBranch(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CreateBranch createBranch)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param labelItem
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LabelItemResponse labelItem(

                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LabelItem labelItem)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    