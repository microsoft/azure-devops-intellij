
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/ServerStatus/03".equals(namespaceURI) &&
                  "ArrayOfDataChanged".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.ArrayOfDataChanged.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/Services/ServerStatus/03".equals(namespaceURI) &&
                  "DataChanged".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.services.serverstatus._03.DataChanged.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    