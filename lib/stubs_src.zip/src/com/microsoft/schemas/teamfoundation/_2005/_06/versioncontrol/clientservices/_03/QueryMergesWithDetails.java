
/**
 * QueryMergesWithDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */
            
                package com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03;
            

            /**
            *  QueryMergesWithDetails bean class
            */
        
        public  class QueryMergesWithDetails
        implements org.apache.axis2.databinding.ADBBean{
        
                public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                "QueryMergesWithDetails",
                "");

            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for WorkspaceName
                        */

                        
                                    protected java.lang.String localWorkspaceName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWorkspaceNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWorkspaceName(){
                               return localWorkspaceName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WorkspaceName
                               */
                               public void setWorkspaceName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWorkspaceNameTracker = true;
                                       } else {
                                          localWorkspaceNameTracker = false;
                                              
                                       }
                                   
                                            this.localWorkspaceName=param;
                                    

                               }
                            

                        /**
                        * field for WorkspaceOwner
                        */

                        
                                    protected java.lang.String localWorkspaceOwner ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWorkspaceOwnerTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWorkspaceOwner(){
                               return localWorkspaceOwner;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WorkspaceOwner
                               */
                               public void setWorkspaceOwner(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWorkspaceOwnerTracker = true;
                                       } else {
                                          localWorkspaceOwnerTracker = false;
                                              
                                       }
                                   
                                            this.localWorkspaceOwner=param;
                                    

                               }
                            

                        /**
                        * field for Source
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec localSource ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSourceTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec getSource(){
                               return localSource;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Source
                               */
                               public void setSource(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSourceTracker = true;
                                       } else {
                                          localSourceTracker = false;
                                              
                                       }
                                   
                                            this.localSource=param;
                                    

                               }
                            

                        /**
                        * field for VersionSource
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec localVersionSource ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localVersionSourceTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec getVersionSource(){
                               return localVersionSource;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param VersionSource
                               */
                               public void setVersionSource(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localVersionSourceTracker = true;
                                       } else {
                                          localVersionSourceTracker = false;
                                              
                                       }
                                   
                                            this.localVersionSource=param;
                                    

                               }
                            

                        /**
                        * field for Target
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec localTarget ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTargetTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec getTarget(){
                               return localTarget;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Target
                               */
                               public void setTarget(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localTargetTracker = true;
                                       } else {
                                          localTargetTracker = false;
                                              
                                       }
                                   
                                            this.localTarget=param;
                                    

                               }
                            

                        /**
                        * field for VersionTarget
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec localVersionTarget ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localVersionTargetTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec getVersionTarget(){
                               return localVersionTarget;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param VersionTarget
                               */
                               public void setVersionTarget(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localVersionTargetTracker = true;
                                       } else {
                                          localVersionTargetTracker = false;
                                              
                                       }
                                   
                                            this.localVersionTarget=param;
                                    

                               }
                            

                        /**
                        * field for VersionFrom
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec localVersionFrom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localVersionFromTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec getVersionFrom(){
                               return localVersionFrom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param VersionFrom
                               */
                               public void setVersionFrom(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localVersionFromTracker = true;
                                       } else {
                                          localVersionFromTracker = false;
                                              
                                       }
                                   
                                            this.localVersionFrom=param;
                                    

                               }
                            

                        /**
                        * field for VersionTo
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec localVersionTo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localVersionToTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec getVersionTo(){
                               return localVersionTo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param VersionTo
                               */
                               public void setVersionTo(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localVersionToTracker = true;
                                       } else {
                                          localVersionToTracker = false;
                                              
                                       }
                                   
                                            this.localVersionTo=param;
                                    

                               }
                            

                        /**
                        * field for MaxChangesets
                        */

                        
                                    protected int localMaxChangesets ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getMaxChangesets(){
                               return localMaxChangesets;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaxChangesets
                               */
                               public void setMaxChangesets(int param){
                            
                                            this.localMaxChangesets=param;
                                    

                               }
                            

                        /**
                        * field for ShowAll
                        */

                        
                                    protected boolean localShowAll ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localShowAllTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getShowAll(){
                               return localShowAll;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ShowAll
                               */
                               public void setShowAll(boolean param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (false) {
                                           localShowAllTracker = false;
                                              
                                       } else {
                                          localShowAllTracker = true;
                                       }
                                   
                                            this.localShowAll=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
                org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,MY_QNAME){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       QueryMergesWithDetails.this.serialize(MY_QNAME,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               MY_QNAME,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":QueryMergesWithDetails",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "QueryMergesWithDetails",
                           xmlWriter);
                   }

               
                   }
                if (localWorkspaceNameTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"workspaceName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"workspaceName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("workspaceName");
                                    }
                                

                                          if (localWorkspaceName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("workspaceName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWorkspaceName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWorkspaceOwnerTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"workspaceOwner", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"workspaceOwner");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("workspaceOwner");
                                    }
                                

                                          if (localWorkspaceOwner==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("workspaceOwner cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWorkspaceOwner);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSourceTracker){
                                            if (localSource==null){
                                                 throw new org.apache.axis2.databinding.ADBException("source cannot be null!!");
                                            }
                                           localSource.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","source"),
                                               factory,xmlWriter);
                                        } if (localVersionSourceTracker){
                                            if (localVersionSource==null){
                                                 throw new org.apache.axis2.databinding.ADBException("versionSource cannot be null!!");
                                            }
                                           localVersionSource.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionSource"),
                                               factory,xmlWriter);
                                        } if (localTargetTracker){
                                            if (localTarget==null){
                                                 throw new org.apache.axis2.databinding.ADBException("target cannot be null!!");
                                            }
                                           localTarget.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","target"),
                                               factory,xmlWriter);
                                        } if (localVersionTargetTracker){
                                            if (localVersionTarget==null){
                                                 throw new org.apache.axis2.databinding.ADBException("versionTarget cannot be null!!");
                                            }
                                           localVersionTarget.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionTarget"),
                                               factory,xmlWriter);
                                        } if (localVersionFromTracker){
                                            if (localVersionFrom==null){
                                                 throw new org.apache.axis2.databinding.ADBException("versionFrom cannot be null!!");
                                            }
                                           localVersionFrom.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionFrom"),
                                               factory,xmlWriter);
                                        } if (localVersionToTracker){
                                            if (localVersionTo==null){
                                                 throw new org.apache.axis2.databinding.ADBException("versionTo cannot be null!!");
                                            }
                                           localVersionTo.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionTo"),
                                               factory,xmlWriter);
                                        }
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maxChangesets", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maxChangesets");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maxChangesets");
                                    }
                                
                                               if (localMaxChangesets==java.lang.Integer.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("maxChangesets cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxChangesets));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                              if (localShowAllTracker){
                                    namespace = "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"showAll", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"showAll");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("showAll");
                                    }
                                
                                               if (false) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("showAll cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localShowAll));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localWorkspaceNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "workspaceName"));
                                 
                                        if (localWorkspaceName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWorkspaceName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("workspaceName cannot be null!!");
                                        }
                                    } if (localWorkspaceOwnerTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "workspaceOwner"));
                                 
                                        if (localWorkspaceOwner != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWorkspaceOwner));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("workspaceOwner cannot be null!!");
                                        }
                                    } if (localSourceTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "source"));
                            
                            
                                    if (localSource==null){
                                         throw new org.apache.axis2.databinding.ADBException("source cannot be null!!");
                                    }
                                    elementList.add(localSource);
                                } if (localVersionSourceTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "versionSource"));
                            
                            
                                    if (localVersionSource==null){
                                         throw new org.apache.axis2.databinding.ADBException("versionSource cannot be null!!");
                                    }
                                    elementList.add(localVersionSource);
                                } if (localTargetTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "target"));
                            
                            
                                    if (localTarget==null){
                                         throw new org.apache.axis2.databinding.ADBException("target cannot be null!!");
                                    }
                                    elementList.add(localTarget);
                                } if (localVersionTargetTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "versionTarget"));
                            
                            
                                    if (localVersionTarget==null){
                                         throw new org.apache.axis2.databinding.ADBException("versionTarget cannot be null!!");
                                    }
                                    elementList.add(localVersionTarget);
                                } if (localVersionFromTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "versionFrom"));
                            
                            
                                    if (localVersionFrom==null){
                                         throw new org.apache.axis2.databinding.ADBException("versionFrom cannot be null!!");
                                    }
                                    elementList.add(localVersionFrom);
                                } if (localVersionToTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "versionTo"));
                            
                            
                                    if (localVersionTo==null){
                                         throw new org.apache.axis2.databinding.ADBException("versionTo cannot be null!!");
                                    }
                                    elementList.add(localVersionTo);
                                }
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "maxChangesets"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxChangesets));
                             if (localShowAllTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "showAll"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localShowAll));
                            }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static QueryMergesWithDetails parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            QueryMergesWithDetails object =
                new QueryMergesWithDetails();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"QueryMergesWithDetails".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (QueryMergesWithDetails)com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","workspaceName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWorkspaceName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","workspaceOwner").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWorkspaceOwner(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","source").equals(reader.getName())){
                                
                                                object.setSource(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionSource").equals(reader.getName())){
                                
                                                object.setVersionSource(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","target").equals(reader.getName())){
                                
                                                object.setTarget(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionTarget").equals(reader.getName())){
                                
                                                object.setVersionTarget(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionFrom").equals(reader.getName())){
                                
                                                object.setVersionFrom(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","versionTo").equals(reader.getName())){
                                
                                                object.setVersionTo(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","maxChangesets").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaxChangesets(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                else{
                                    // A start element we are not expecting indicates an invalid parameter was passed
                                    throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                                }
                            
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","showAll").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setShowAll(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          