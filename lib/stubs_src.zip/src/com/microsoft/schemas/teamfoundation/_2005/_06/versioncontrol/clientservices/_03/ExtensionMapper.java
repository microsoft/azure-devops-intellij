
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Resolution".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Resolution.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ItemMerge".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemMerge.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "MergeSource".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.MergeSource.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfPendingSet".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPendingSet.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "WarningType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.WarningType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Conflict".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Conflict.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfTeamProjectFolderPermission".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfTeamProjectFolderPermission.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfItem".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItem.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfCheckinNoteFieldValue".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfCheckinNoteFieldValue.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfItemSecurity".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSecurity.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfMapping".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ChangeRequest".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeRequest.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "RepositoryProperties".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RepositoryProperties.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinWorkItemAction".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinWorkItemAction.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfConflict".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfConflict.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ExtendedItem".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ExtendedItem.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "MergeOptions".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.MergeOptions.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfMergeSource".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeSource.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Changeset".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Changeset.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "GetRequest".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.GetRequest.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ConflictInformation".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ConflictInformation.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PermissionChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PermissionChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Mapping".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Mapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinResult".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinResult.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PolicyFailureInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PolicyFailureInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "TeamProjectFolderOptions".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.TeamProjectFolderOptions.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfWorkspace".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfWorkspace.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Change".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Change.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "SecurityChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.SecurityChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ChangeType_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfString".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfArrayOfGetOperation".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfArrayOfGetOperation.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfChangeRequest".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfChangeRequest.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfChangeset".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfChangeset.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinNoteFieldDefinition".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinNoteFieldDefinition.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfLabelItemSpec".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfLabelItemSpec.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "WorkingFolderType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.WorkingFolderType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LabelResultStatus".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LabelResultStatus.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "TeamProjectFolderPermission".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.TeamProjectFolderPermission.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinOptions_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinOptions_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "VersionSpec".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionSpec.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LocalVersionUpdate".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LocalVersionUpdate.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfExtendedItem".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfExtendedItem.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "MergeOptions_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.MergeOptions_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LabelResult".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LabelResult.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LockLevel".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LockLevel.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Workspace".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Workspace.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "WorkingFolder".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.WorkingFolder.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PendingSet".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PendingSet.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfItemMerge".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemMerge.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfAccessEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfAccessEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "DeletedState".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.DeletedState.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfVersionControlLink".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfVersionControlLink.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ChangeType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinNoteFieldValue".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinNoteFieldValue.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfWorkingFolder".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfWorkingFolder.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfPendingState".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPendingState.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfPermissionChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPermissionChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfFileType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfFileType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfBranchRelative".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfBranchRelative.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "VersionControlLink".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionControlLink.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinNote".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinNote.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "VersionControlLabel".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.VersionControlLabel.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfAnnotation".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfAnnotation.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ConflictType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ConflictType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfCheckinNotificationWorkItemInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfCheckinNotificationWorkItemInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfCheckinNoteFieldDefinition".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfCheckinNoteFieldDefinition.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "SeverityType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.SeverityType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfLocalVersion".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfLocalVersion.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfInt".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfInt.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfPropertyValue".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPropertyValue.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfMergeCandidate".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeCandidate.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfLabelResult".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfLabelResult.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfGetOperation".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfGetOperation.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Annotation".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Annotation.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfShelveset".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfShelveset.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "RecursionType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RecursionType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfArrayOfExtendedItem".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfArrayOfExtendedItem.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinNotificationInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinNotificationInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "RequestType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.RequestType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PendingState".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PendingState.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PolicyOverrideInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PolicyOverrideInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfChangesetMerge".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfChangesetMerge.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.wsdl.types.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Warning".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Warning.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PendingSetType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PendingSetType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfGetRequest".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfGetRequest.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfArrayOfBranchRelative".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfArrayOfBranchRelative.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ItemType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PropertyValue".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PropertyValue.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfVersionControlLabel".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfVersionControlLabel.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfPolicyFailureInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPolicyFailureInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LocalVersion".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LocalVersion.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LabelChildOption".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LabelChildOption.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ChangesetMergeDetails".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangesetMergeDetails.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "GlobalSecurity".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.GlobalSecurity.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "AccessEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.AccessEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ItemSpec".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSpec.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfItemSet".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSet.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfFailure".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfFailure.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ItemSecurity".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSecurity.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "LabelItemSpec".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LabelItemSpec.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ChangesetMerge".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangesetMerge.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfArrayOfLocalVersion".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfArrayOfLocalVersion.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Shelveset".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Shelveset.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfItemSpec".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfItemSpec.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinNotificationWorkItemInfo".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinNotificationWorkItemInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ItemSet".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemSet.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "GetOperation".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.GetOperation.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfWarning".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfWarning.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "MergeCandidate".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.MergeCandidate.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfPendingChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPendingChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "FileType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.FileType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "CheckinOptions".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.CheckinOptions.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Item".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Item.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfSecurityChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfSecurityChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "PendingChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.PendingChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfChange".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfChange.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "Failure".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.Failure.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfLocalVersionUpdate".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfLocalVersionUpdate.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03".equals(namespaceURI) &&
                  "BranchRelative".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.BranchRelative.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    