
/**
 * ClientService2Stub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
        package com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03;

        

        /*
        *  ClientService2Stub java implementation
        */

        
        public class ClientService2Stub extends org.apache.axis2.client.Stub
        implements ClientService2{
        protected org.apache.axis2.description.AxisOperation[] _operations;

        //hashmaps to keep the fault mapping
        private java.util.HashMap faultExceptionNameMap = new java.util.HashMap();
        private java.util.HashMap faultExceptionClassNameMap = new java.util.HashMap();
        private java.util.HashMap faultMessageMap = new java.util.HashMap();

        private static int counter = 0;

        private static synchronized java.lang.String getUniqueSuffix(){
            // reset the counter if it is greater than 99999
            if (counter > 99999){
                counter = 0;
            }
            counter = counter + 1; 
            return java.lang.Long.toString(System.currentTimeMillis()) + "_" + counter;
        }

    
    private void populateAxisService() throws org.apache.axis2.AxisFault {

     //creating the Service with a unique name
     _service = new org.apache.axis2.description.AxisService("ClientService2" + getUniqueSuffix());
     addAnonymousOperations();

        //creating the operations
        org.apache.axis2.description.AxisOperation __operation;

        _operations = new org.apache.axis2.description.AxisOperation[22];
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "syncBisGroupsAndUsers"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[0]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "queryWorkitemCountOnBehalfOf"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[1]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getStoredQuery"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[2]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getReferencingWorkitemUris"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[3]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getStoredQueryItems"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[4]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getStoredQueries"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[5]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getMetadata"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[6]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "pageWorkitemsByIdRevs"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[7]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "syncAccessControlLists"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[8]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "stampWorkitemCache"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[9]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "bulkUpdate"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[10]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getMetadataEx2"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[11]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "requestCancel"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[12]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "pageItemsOnBehalfOf"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[13]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getWorkItem"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[14]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "syncExternalStructures"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[15]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getWorkitemTrackingVersion"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[16]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "update"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[17]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "queryWorkitemCount"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[18]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "queryWorkitems"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[19]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getMetadataEx"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[20]=__operation;
            
        
                   __operation = new org.apache.axis2.description.OutInAxisOperation();
                

            __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "pageWorkitemsByIds"));
	    _service.addOperation(__operation);
	    

	    
	    
            _operations[21]=__operation;
            
        
        }

    //populates the faults
    private void populateFaults(){
         


    }

    /**
      *Constructor that takes in a configContext
      */

    public ClientService2Stub(org.apache.axis2.context.ConfigurationContext configurationContext,
       java.lang.String targetEndpoint)
       throws org.apache.axis2.AxisFault {
         this(configurationContext,targetEndpoint,false);
   }


   /**
     * Constructor that takes in a configContext  and useseperate listner
     */
   public ClientService2Stub(org.apache.axis2.context.ConfigurationContext configurationContext,
        java.lang.String targetEndpoint, boolean useSeparateListener)
        throws org.apache.axis2.AxisFault {
         //To populate AxisService
         populateAxisService();
         populateFaults();

        _serviceClient = new org.apache.axis2.client.ServiceClient(configurationContext,_service);
        
	
        _serviceClient.getOptions().setTo(new org.apache.axis2.addressing.EndpointReference(
                targetEndpoint));
        _serviceClient.getOptions().setUseSeparateListener(useSeparateListener);
        
            //Set the soap version
            _serviceClient.getOptions().setSoapVersionURI(org.apache.axiom.soap.SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI);
        
    
    }

    /**
     * Default Constructor
     */
    public ClientService2Stub(org.apache.axis2.context.ConfigurationContext configurationContext) throws org.apache.axis2.AxisFault {
        
                    this(configurationContext,"http://172.26.240.209:8080/tfs/_tfs_resources/WorkItemTracking/v1.0/ClientService.asmx" );
                
    }

    /**
     * Default Constructor
     */
    public ClientService2Stub() throws org.apache.axis2.AxisFault {
        
                    this("http://172.26.240.209:8080/tfs/_tfs_resources/WorkItemTracking/v1.0/ClientService.asmx" );
                
    }

    /**
     * Constructor taking the target endpoint
     */
    public ClientService2Stub(java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault {
        this(null,targetEndpoint);
    }



        
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#syncBisGroupsAndUsers
                     * @param syncBisGroupsAndUsers21
                    
                     * @param requestHeader22
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse syncBisGroupsAndUsers(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers syncBisGroupsAndUsers21,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader22)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[0].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncBisGroupsAndUsers");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    syncBisGroupsAndUsers21,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "syncBisGroupsAndUsers")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader22!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader22 = toOM(requestHeader22, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "syncBisGroupsAndUsers")));
                                                    addHeader(omElementrequestHeader22,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#queryWorkitemCountOnBehalfOf
                     * @param queryWorkitemCountOnBehalfOf24
                    
                     * @param requestHeader25
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse queryWorkitemCountOnBehalfOf(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf queryWorkitemCountOnBehalfOf24,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader25)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[1].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitemCountOnBehalfOf");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    queryWorkitemCountOnBehalfOf24,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "queryWorkitemCountOnBehalfOf")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader25!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader25 = toOM(requestHeader25, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "queryWorkitemCountOnBehalfOf")));
                                                    addHeader(omElementrequestHeader25,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getStoredQuery
                     * @param getStoredQuery27
                    
                     * @param requestHeader28
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse getStoredQuery(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery getStoredQuery27,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader28)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[2].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQuery");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getStoredQuery27,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getStoredQuery")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader28!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader28 = toOM(requestHeader28, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getStoredQuery")));
                                                    addHeader(omElementrequestHeader28,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getReferencingWorkitemUris
                     * @param getReferencingWorkitemUris30
                    
                     * @param requestHeader31
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse getReferencingWorkitemUris(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris getReferencingWorkitemUris30,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader31)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[3].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetReferencingWorkitemUris");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getReferencingWorkitemUris30,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getReferencingWorkitemUris")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader31!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader31 = toOM(requestHeader31, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getReferencingWorkitemUris")));
                                                    addHeader(omElementrequestHeader31,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getStoredQueryItems
                     * @param getStoredQueryItems33
                    
                     * @param requestHeader34
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse getStoredQueryItems(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems getStoredQueryItems33,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader34)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[4].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQueryItems");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getStoredQueryItems33,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getStoredQueryItems")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader34!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader34 = toOM(requestHeader34, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getStoredQueryItems")));
                                                    addHeader(omElementrequestHeader34,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getStoredQueries
                     * @param getStoredQueries36
                    
                     * @param requestHeader37
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse getStoredQueries(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries getStoredQueries36,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader37)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[5].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetStoredQueries");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getStoredQueries36,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getStoredQueries")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader37!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader37 = toOM(requestHeader37, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getStoredQueries")));
                                                    addHeader(omElementrequestHeader37,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getMetadata
                     * @param getMetadata39
                    
                     * @param requestHeader40
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse getMetadata(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata getMetadata39,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader40)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[6].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadata");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getMetadata39,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getMetadata")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader40!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader40 = toOM(requestHeader40, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getMetadata")));
                                                    addHeader(omElementrequestHeader40,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#pageWorkitemsByIdRevs
                     * @param pageWorkitemsByIdRevs42
                    
                     * @param requestHeader43
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse pageWorkitemsByIdRevs(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs pageWorkitemsByIdRevs42,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader43)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[7].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageWorkitemsByIdRevs");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    pageWorkitemsByIdRevs42,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "pageWorkitemsByIdRevs")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader43!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader43 = toOM(requestHeader43, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "pageWorkitemsByIdRevs")));
                                                    addHeader(omElementrequestHeader43,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#syncAccessControlLists
                     * @param syncAccessControlLists45
                    
                     * @param requestHeader46
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse syncAccessControlLists(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists syncAccessControlLists45,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader46)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[8].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncAccessControlLists");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    syncAccessControlLists45,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "syncAccessControlLists")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader46!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader46 = toOM(requestHeader46, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "syncAccessControlLists")));
                                                    addHeader(omElementrequestHeader46,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#stampWorkitemCache
                     * @param stampWorkitemCache48
                    
                     * @param requestHeader49
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse stampWorkitemCache(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache stampWorkitemCache48,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader49)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[9].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/StampWorkitemCache");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    stampWorkitemCache48,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "stampWorkitemCache")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader49!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader49 = toOM(requestHeader49, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "stampWorkitemCache")));
                                                    addHeader(omElementrequestHeader49,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#bulkUpdate
                     * @param bulkUpdate51
                    
                     * @param requestHeader52
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse bulkUpdate(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate bulkUpdate51,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader52)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[10].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/BulkUpdate");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    bulkUpdate51,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "bulkUpdate")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader52!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader52 = toOM(requestHeader52, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "bulkUpdate")));
                                                    addHeader(omElementrequestHeader52,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getMetadataEx2
                     * @param getMetadataEx254
                    
                     * @param requestHeader55
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response getMetadataEx2(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2 getMetadataEx254,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader55)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[11].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadataEx2");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getMetadataEx254,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getMetadataEx2")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader55!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader55 = toOM(requestHeader55, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getMetadataEx2")));
                                                    addHeader(omElementrequestHeader55,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#requestCancel
                     * @param requestCancel57
                    
                     * @param requestHeader58
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse requestCancel(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel requestCancel57,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader58)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[12].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/RequestCancel");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    requestCancel57,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "requestCancel")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader58!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader58 = toOM(requestHeader58, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "requestCancel")));
                                                    addHeader(omElementrequestHeader58,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#pageItemsOnBehalfOf
                     * @param pageItemsOnBehalfOf60
                    
                     * @param requestHeader61
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse pageItemsOnBehalfOf(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf pageItemsOnBehalfOf60,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader61)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[13].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageItemsOnBehalfOf");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    pageItemsOnBehalfOf60,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "pageItemsOnBehalfOf")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader61!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader61 = toOM(requestHeader61, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "pageItemsOnBehalfOf")));
                                                    addHeader(omElementrequestHeader61,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getWorkItem
                     * @param getWorkItem63
                    
                     * @param requestHeader64
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse getWorkItem(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem getWorkItem63,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader64)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[14].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetWorkItem");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getWorkItem63,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getWorkItem")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader64!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader64 = toOM(requestHeader64, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getWorkItem")));
                                                    addHeader(omElementrequestHeader64,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#syncExternalStructures
                     * @param syncExternalStructures66
                    
                     * @param requestHeader67
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse syncExternalStructures(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures syncExternalStructures66,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader67)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[15].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/SyncExternalStructures");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    syncExternalStructures66,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "syncExternalStructures")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader67!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader67 = toOM(requestHeader67, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "syncExternalStructures")));
                                                    addHeader(omElementrequestHeader67,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getWorkitemTrackingVersion
                     * @param getWorkitemTrackingVersion69
                    
                     * @param requestHeader70
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse getWorkitemTrackingVersion(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion getWorkitemTrackingVersion69,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader70)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[16].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetWorkitemTrackingVersion");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getWorkitemTrackingVersion69,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getWorkitemTrackingVersion")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader70!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader70 = toOM(requestHeader70, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getWorkitemTrackingVersion")));
                                                    addHeader(omElementrequestHeader70,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#update
                     * @param update72
                    
                     * @param requestHeader73
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse update(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update update72,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader73)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[17].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/Update");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    update72,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "update")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader73!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader73 = toOM(requestHeader73, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "update")));
                                                    addHeader(omElementrequestHeader73,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#queryWorkitemCount
                     * @param queryWorkitemCount75
                    
                     * @param requestHeader76
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse queryWorkitemCount(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount queryWorkitemCount75,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader76)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[18].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitemCount");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    queryWorkitemCount75,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "queryWorkitemCount")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader76!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader76 = toOM(requestHeader76, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "queryWorkitemCount")));
                                                    addHeader(omElementrequestHeader76,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#queryWorkitems
                     * @param queryWorkitems78
                    
                     * @param requestHeader79
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse queryWorkitems(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems queryWorkitems78,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader79)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[19].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/QueryWorkitems");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    queryWorkitems78,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "queryWorkitems")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader79!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader79 = toOM(requestHeader79, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "queryWorkitems")));
                                                    addHeader(omElementrequestHeader79,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#getMetadataEx
                     * @param getMetadataEx81
                    
                     * @param requestHeader82
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse getMetadataEx(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx getMetadataEx81,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader82)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[20].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/GetMetadataEx");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getMetadataEx81,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "getMetadataEx")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader82!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader82 = toOM(requestHeader82, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "getMetadataEx")));
                                                    addHeader(omElementrequestHeader82,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            
                    /**
                     * Auto generated method signature
                     * 
                     * @see com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ClientService2#pageWorkitemsByIds
                     * @param pageWorkitemsByIds84
                    
                     * @param requestHeader85
                    
                     */

                    

                            public  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse pageWorkitemsByIds(

                            com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds pageWorkitemsByIds84,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader85)
                        

                    throws java.rmi.RemoteException
                    
                    {
              org.apache.axis2.context.MessageContext _messageContext = null;
              try{
               org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[21].getName());
              _operationClient.getOptions().setAction("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03/PageWorkitemsByIds");
              _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

              
              
                  addPropertyToOperationClient(_operationClient,org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,"&");
              

              // create a message context
              _messageContext = new org.apache.axis2.context.MessageContext();

              

              // create SOAP envelope with that payload
              org.apache.axiom.soap.SOAPEnvelope env = null;
                    
                                                    
                                                    env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    pageWorkitemsByIds84,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03",
                                                    "pageWorkitemsByIds")));
                                                
                                               env.build();
                                    
                                        // add the children only if the parameter is not null
                                        if (requestHeader85!=null){
                                            
                                                    org.apache.axiom.om.OMElement omElementrequestHeader85 = toOM(requestHeader85, optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03", "pageWorkitemsByIds")));
                                                    addHeader(omElementrequestHeader85,env);
                                                
                                        }
                                    
        //adding SOAP soap_headers
         _serviceClient.addHeadersToEnvelope(env);
        // set the message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message contxt to the operation client
        _operationClient.addMessageContext(_messageContext);

        //execute the operation client
        _operationClient.execute(true);

         
               org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient.getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
                org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();
                
                
                                java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement() ,
                                             com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

                               
                                        return (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse)object;
                                   
         }catch(org.apache.axis2.AxisFault f){

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt!=null){
                if (faultExceptionNameMap.containsKey(faultElt.getQName())){
                    //make the fault by reflection
                    try{
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap.get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex=
                                (java.lang.Exception) exceptionClass.newInstance();
                        //message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt.getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt,messageClass,null);
                        java.lang.reflect.Method m = exceptionClass.getMethod("setFaultMessage",
                                   new java.lang.Class[]{messageClass});
                        m.invoke(ex,new java.lang.Object[]{messageObject});
                        

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }catch(java.lang.ClassCastException e){
                       // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.ClassNotFoundException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }catch (java.lang.NoSuchMethodException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    } catch (java.lang.reflect.InvocationTargetException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }  catch (java.lang.IllegalAccessException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }   catch (java.lang.InstantiationException e) {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }else{
                    throw f;
                }
            }else{
                throw f;
            }
            } finally {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
            


       /**
        *  A utility method that copies the namepaces from the SOAPEnvelope
        */
       private java.util.Map getEnvelopeNamespaces(org.apache.axiom.soap.SOAPEnvelope env){
        java.util.Map returnMap = new java.util.HashMap();
        java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();
        while (namespaceIterator.hasNext()) {
            org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator.next();
            returnMap.put(ns.getPrefix(),ns.getNamespaceURI());
        }
       return returnMap;
    }

    
    
    private javax.xml.namespace.QName[] opNameArray = null;
    private boolean optimizeContent(javax.xml.namespace.QName opName) {
        

        if (opNameArray == null) {
            return false;
        }
        for (int i = 0; i < opNameArray.length; i++) {
            if (opName.equals(opNameArray[i])) {
                return true;   
            }
        }
        return false;
    }
     //http://172.26.240.209:8080/tfs/_tfs_resources/WorkItemTracking/v1.0/ClientService.asmx
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2 param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
            private  org.apache.axiom.om.OMElement  toOM(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse param, boolean optimizeContent)
            throws org.apache.axis2.AxisFault {

            
                        try{
                             return param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
                        } catch(org.apache.axis2.databinding.ADBException e){
                            throw org.apache.axis2.AxisFault.makeFault(e);
                        }
                    

            }
        
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2 param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             
                                    
                                        private  org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory, com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds param, boolean optimizeContent)
                                        throws org.apache.axis2.AxisFault{

                                             
                                                    try{

                                                            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
                                                            emptyEnvelope.getBody().addChild(param.getOMElement(com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds.MY_QNAME,factory));
                                                            return emptyEnvelope;
                                                        } catch(org.apache.axis2.databinding.ADBException e){
                                                            throw org.apache.axis2.AxisFault.makeFault(e);
                                                        }
                                                

                                        }
                                
                             
                             /* methods to provide back word compatibility */

                             


        /**
        *  get the default envelope
        */
        private org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory){
        return factory.getDefaultEnvelope();
        }


        private  java.lang.Object fromOM(
        org.apache.axiom.om.OMElement param,
        java.lang.Class type,
        java.util.Map extraNamespaces) throws org.apache.axis2.AxisFault{

        try {
        
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
                if (com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.class.equals(type)){
                
                           return com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE.Factory.parse(param.getXMLStreamReaderWithoutCaching());
                    

                }
           
        } catch (java.lang.Exception e) {
        throw org.apache.axis2.AxisFault.makeFault(e);
        }
           return null;
        }



    
   }
   