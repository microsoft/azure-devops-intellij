
/**
 * PendingChange.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */
            
                package com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03;
            

            /**
            *  PendingChange bean class
            */
        
        public  class PendingChange
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = PendingChange
                Namespace URI = http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for MergeSources
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeSource localMergeSources ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMergeSourcesTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeSource
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeSource getMergeSources(){
                               return localMergeSources;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MergeSources
                               */
                               public void setMergeSources(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeSource param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMergeSourcesTracker = true;
                                       } else {
                                          localMergeSourcesTracker = false;
                                              
                                       }
                                   
                                            this.localMergeSources=param;
                                    

                               }
                            

                        /**
                        * field for PropertyValues
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPropertyValue localPropertyValues ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPropertyValuesTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPropertyValue
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPropertyValue getPropertyValues(){
                               return localPropertyValues;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PropertyValues
                               */
                               public void setPropertyValues(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPropertyValue param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPropertyValuesTracker = true;
                                       } else {
                                          localPropertyValuesTracker = false;
                                              
                                       }
                                   
                                            this.localPropertyValues=param;
                                    

                               }
                            

                        /**
                        * field for ChgEx
                        * This was an Attribute!
                        */

                        
                                    protected int localChgEx =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getChgEx(){
                               return localChgEx;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ChgEx
                               */
                               public void setChgEx(int param){
                            
                                            this.localChgEx=param;
                                    

                               }
                            

                        /**
                        * field for Chg
                        * This was an Attribute!
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType localChg ;
                                

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType getChg(){
                               return localChg;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Chg
                               */
                               public void setChg(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType param){
                            
                                            this.localChg=param;
                                    

                               }
                            

                        /**
                        * field for Date
                        * This was an Attribute!
                        */

                        
                                    protected java.util.Calendar localDate ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getDate(){
                               return localDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Date
                               */
                               public void setDate(java.util.Calendar param){
                            
                                            this.localDate=param;
                                    

                               }
                            

                        /**
                        * field for Did
                        * This was an Attribute!
                        */

                        
                                    protected int localDid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getDid(){
                               return localDid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Did
                               */
                               public void setDid(int param){
                            
                                            this.localDid=param;
                                    

                               }
                            

                        /**
                        * field for Type
                        * This was an Attribute!
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemType localType ;
                                

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemType
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemType getType(){
                               return localType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Type
                               */
                               public void setType(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemType param){
                            
                                            this.localType=param;
                                    

                               }
                            

                        /**
                        * field for Enc
                        * This was an Attribute!
                        */

                        
                                    protected int localEnc =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("-2");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getEnc(){
                               return localEnc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Enc
                               */
                               public void setEnc(int param){
                            
                                            this.localEnc=param;
                                    

                               }
                            

                        /**
                        * field for Itemid
                        * This was an Attribute!
                        */

                        
                                    protected int localItemid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getItemid(){
                               return localItemid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Itemid
                               */
                               public void setItemid(int param){
                            
                                            this.localItemid=param;
                                    

                               }
                            

                        /**
                        * field for Local
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localLocal ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocal(){
                               return localLocal;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Local
                               */
                               public void setLocal(java.lang.String param){
                            
                                            this.localLocal=param;
                                    

                               }
                            

                        /**
                        * field for Lock
                        * This was an Attribute!
                        */

                        
                                    protected com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LockLevel localLock ;
                                

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LockLevel
                           */
                           public  com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LockLevel getLock(){
                               return localLock;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Lock
                               */
                               public void setLock(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LockLevel param){
                            
                                            this.localLock=param;
                                    

                               }
                            

                        /**
                        * field for Item
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localItem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getItem(){
                               return localItem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Item
                               */
                               public void setItem(java.lang.String param){
                            
                                            this.localItem=param;
                                    

                               }
                            

                        /**
                        * field for Srclocal
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localSrclocal ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSrclocal(){
                               return localSrclocal;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Srclocal
                               */
                               public void setSrclocal(java.lang.String param){
                            
                                            this.localSrclocal=param;
                                    

                               }
                            

                        /**
                        * field for Srcitem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localSrcitem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSrcitem(){
                               return localSrcitem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Srcitem
                               */
                               public void setSrcitem(java.lang.String param){
                            
                                            this.localSrcitem=param;
                                    

                               }
                            

                        /**
                        * field for Svrfm
                        * This was an Attribute!
                        */

                        
                                    protected int localSvrfm =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getSvrfm(){
                               return localSvrfm;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Svrfm
                               */
                               public void setSvrfm(int param){
                            
                                            this.localSvrfm=param;
                                    

                               }
                            

                        /**
                        * field for Sdi
                        * This was an Attribute!
                        */

                        
                                    protected int localSdi =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getSdi(){
                               return localSdi;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Sdi
                               */
                               public void setSdi(int param){
                            
                                            this.localSdi=param;
                                    

                               }
                            

                        /**
                        * field for Ver
                        * This was an Attribute!
                        */

                        
                                    protected int localVer =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getVer(){
                               return localVer;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ver
                               */
                               public void setVer(int param){
                            
                                            this.localVer=param;
                                    

                               }
                            

                        /**
                        * field for Hash
                        * This was an Attribute!
                        */

                        
                                    protected javax.activation.DataHandler localHash ;
                                

                           /**
                           * Auto generated getter method
                           * @return javax.activation.DataHandler
                           */
                           public  javax.activation.DataHandler getHash(){
                               return localHash;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Hash
                               */
                               public void setHash(javax.activation.DataHandler param){
                            
                                            this.localHash=param;
                                    

                               }
                            

                        /**
                        * field for Len
                        * This was an Attribute!
                        */

                        
                                    protected long localLen =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong("-1");
                                

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getLen(){
                               return localLen;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Len
                               */
                               public void setLen(long param){
                            
                                            this.localLen=param;
                                    

                               }
                            

                        /**
                        * field for Uhash
                        * This was an Attribute!
                        */

                        
                                    protected javax.activation.DataHandler localUhash ;
                                

                           /**
                           * Auto generated getter method
                           * @return javax.activation.DataHandler
                           */
                           public  javax.activation.DataHandler getUhash(){
                               return localUhash;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Uhash
                               */
                               public void setUhash(javax.activation.DataHandler param){
                            
                                            this.localUhash=param;
                                    

                               }
                            

                        /**
                        * field for Pcid
                        * This was an Attribute!
                        */

                        
                                    protected int localPcid =
                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt("0");
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getPcid(){
                               return localPcid;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Pcid
                               */
                               public void setPcid(int param){
                            
                                            this.localPcid=param;
                                    

                               }
                            

                        /**
                        * field for Durl
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localDurl ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getDurl(){
                               return localDurl;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Durl
                               */
                               public void setDurl(java.lang.String param){
                            
                                            this.localDurl=param;
                                    

                               }
                            

                        /**
                        * field for Shelvedurl
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localShelvedurl ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getShelvedurl(){
                               return localShelvedurl;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Shelvedurl
                               */
                               public void setShelvedurl(java.lang.String param){
                            
                                            this.localShelvedurl=param;
                                    

                               }
                            

                        /**
                        * field for Ct
                        * This was an Attribute!
                        */

                        
                                    protected int localCt ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getCt(){
                               return localCt;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ct
                               */
                               public void setCt(int param){
                            
                                            this.localCt=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       PendingChange.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":PendingChange",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "PendingChange",
                           xmlWriter);
                   }

               
                   }
               
                                                   if (localChgEx!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "chgEx",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChgEx), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localChg != null){
                                        writeAttribute("",
                                           "chg",
                                           localChg.toString(), xmlWriter);
                                    }
                                    
                                            if (localDate != null){
                                        
                                                writeAttribute("",
                                                         "date",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDate), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localDate is null");
                                      }
                                    
                                                   if (localDid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "did",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDid), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localType != null){
                                        writeAttribute("",
                                           "type",
                                           localType.toString(), xmlWriter);
                                    }
                                    
                                                   if (localEnc!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "enc",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnc), xmlWriter);

                                            
                                      }
                                    
                                                   if (localItemid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "itemid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItemid), xmlWriter);

                                            
                                      }
                                    
                                            if (localLocal != null){
                                        
                                                writeAttribute("",
                                                         "local",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocal), xmlWriter);

                                            
                                      }
                                    
                                    
                                    if (localLock != null){
                                        writeAttribute("",
                                           "lock",
                                           localLock.toString(), xmlWriter);
                                    }
                                    
                                            if (localItem != null){
                                        
                                                writeAttribute("",
                                                         "item",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItem), xmlWriter);

                                            
                                      }
                                    
                                            if (localSrclocal != null){
                                        
                                                writeAttribute("",
                                                         "srclocal",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSrclocal), xmlWriter);

                                            
                                      }
                                    
                                            if (localSrcitem != null){
                                        
                                                writeAttribute("",
                                                         "srcitem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSrcitem), xmlWriter);

                                            
                                      }
                                    
                                                   if (localSvrfm!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "svrfm",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSvrfm), xmlWriter);

                                            
                                      }
                                    
                                                   if (localSdi!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "sdi",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSdi), xmlWriter);

                                            
                                      }
                                    
                                                   if (localVer!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "ver",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localVer), xmlWriter);

                                            
                                      }
                                    
                                            if (localHash != null){
                                        
                                                writeAttribute("",
                                                         "hash",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localHash), xmlWriter);

                                            
                                      }
                                    
                                                   if (localLen!=java.lang.Long.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "len",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLen), xmlWriter);

                                            
                                      }
                                    
                                            if (localUhash != null){
                                        
                                                writeAttribute("",
                                                         "uhash",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localUhash), xmlWriter);

                                            
                                      }
                                    
                                                   if (localPcid!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "pcid",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPcid), xmlWriter);

                                            
                                      }
                                    
                                            if (localDurl != null){
                                        
                                                writeAttribute("",
                                                         "durl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDurl), xmlWriter);

                                            
                                      }
                                    
                                            if (localShelvedurl != null){
                                        
                                                writeAttribute("",
                                                         "shelvedurl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localShelvedurl), xmlWriter);

                                            
                                      }
                                    
                                                   if (localCt!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "ct",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCt), xmlWriter);

                                            
                                      }
                                     if (localMergeSourcesTracker){
                                            if (localMergeSources==null){
                                                 throw new org.apache.axis2.databinding.ADBException("MergeSources cannot be null!!");
                                            }
                                           localMergeSources.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","MergeSources"),
                                               factory,xmlWriter);
                                        } if (localPropertyValuesTracker){
                                            if (localPropertyValues==null){
                                                 throw new org.apache.axis2.databinding.ADBException("PropertyValues cannot be null!!");
                                            }
                                           localPropertyValues.serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","PropertyValues"),
                                               factory,xmlWriter);
                                        }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localMergeSourcesTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "MergeSources"));
                            
                            
                                    if (localMergeSources==null){
                                         throw new org.apache.axis2.databinding.ADBException("MergeSources cannot be null!!");
                                    }
                                    elementList.add(localMergeSources);
                                } if (localPropertyValuesTracker){
                            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03",
                                                                      "PropertyValues"));
                            
                            
                                    if (localPropertyValues==null){
                                         throw new org.apache.axis2.databinding.ADBException("PropertyValues cannot be null!!");
                                    }
                                    elementList.add(localPropertyValues);
                                }
                            attribList.add(
                            new javax.xml.namespace.QName("","chgEx"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChgEx));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","chg"));
                            
                                      attribList.add(localChg.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","date"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDate));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","did"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","type"));
                            
                                      attribList.add(localType.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","enc"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnc));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","itemid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItemid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","local"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocal));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","lock"));
                            
                                      attribList.add(localLock.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","item"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localItem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","srclocal"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSrclocal));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","srcitem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSrcitem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","svrfm"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSvrfm));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","sdi"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSdi));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ver"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localVer));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","hash"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localHash));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","len"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLen));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","uhash"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localUhash));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","pcid"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPcid));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","durl"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDurl));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","shelvedurl"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localShelvedurl));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ct"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCt));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static PendingChange parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            PendingChange object =
                new PendingChange();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"PendingChange".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (PendingChange)com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "chgEx"
                    java.lang.String tempAttribChgEx =
                        
                                reader.getAttributeValue(null,"chgEx");
                            
                   if (tempAttribChgEx!=null){
                         java.lang.String content = tempAttribChgEx;
                        
                                                 object.setChgEx(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribChgEx));
                                            
                    } else {
                       
                                           object.setChgEx(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("chgEx");
                    
                    // handle attribute "chg"
                    java.lang.String tempAttribChg =
                        
                                reader.getAttributeValue(null,"chg");
                            
                   if (tempAttribChg!=null){
                         java.lang.String content = tempAttribChg;
                        
                                                  object.setChg(
                                                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ChangeType.Factory.fromString(reader,tempAttribChg));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("chg");
                    
                    // handle attribute "date"
                    java.lang.String tempAttribDate =
                        
                                reader.getAttributeValue(null,"date");
                            
                   if (tempAttribDate!=null){
                         java.lang.String content = tempAttribDate;
                        
                                                 object.setDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(tempAttribDate));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute date is missing");
                           
                    }
                    handledAttributes.add("date");
                    
                    // handle attribute "did"
                    java.lang.String tempAttribDid =
                        
                                reader.getAttributeValue(null,"did");
                            
                   if (tempAttribDid!=null){
                         java.lang.String content = tempAttribDid;
                        
                                                 object.setDid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribDid));
                                            
                    } else {
                       
                                           object.setDid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("did");
                    
                    // handle attribute "type"
                    java.lang.String tempAttribType =
                        
                                reader.getAttributeValue(null,"type");
                            
                   if (tempAttribType!=null){
                         java.lang.String content = tempAttribType;
                        
                                                  object.setType(
                                                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ItemType.Factory.fromString(reader,tempAttribType));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("type");
                    
                    // handle attribute "enc"
                    java.lang.String tempAttribEnc =
                        
                                reader.getAttributeValue(null,"enc");
                            
                   if (tempAttribEnc!=null){
                         java.lang.String content = tempAttribEnc;
                        
                                                 object.setEnc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribEnc));
                                            
                    } else {
                       
                                           object.setEnc(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("enc");
                    
                    // handle attribute "itemid"
                    java.lang.String tempAttribItemid =
                        
                                reader.getAttributeValue(null,"itemid");
                            
                   if (tempAttribItemid!=null){
                         java.lang.String content = tempAttribItemid;
                        
                                                 object.setItemid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribItemid));
                                            
                    } else {
                       
                                           object.setItemid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("itemid");
                    
                    // handle attribute "local"
                    java.lang.String tempAttribLocal =
                        
                                reader.getAttributeValue(null,"local");
                            
                   if (tempAttribLocal!=null){
                         java.lang.String content = tempAttribLocal;
                        
                                                 object.setLocal(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribLocal));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("local");
                    
                    // handle attribute "lock"
                    java.lang.String tempAttribLock =
                        
                                reader.getAttributeValue(null,"lock");
                            
                   if (tempAttribLock!=null){
                         java.lang.String content = tempAttribLock;
                        
                                                  object.setLock(
                                                        com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.LockLevel.Factory.fromString(reader,tempAttribLock));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("lock");
                    
                    // handle attribute "item"
                    java.lang.String tempAttribItem =
                        
                                reader.getAttributeValue(null,"item");
                            
                   if (tempAttribItem!=null){
                         java.lang.String content = tempAttribItem;
                        
                                                 object.setItem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribItem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("item");
                    
                    // handle attribute "srclocal"
                    java.lang.String tempAttribSrclocal =
                        
                                reader.getAttributeValue(null,"srclocal");
                            
                   if (tempAttribSrclocal!=null){
                         java.lang.String content = tempAttribSrclocal;
                        
                                                 object.setSrclocal(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribSrclocal));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("srclocal");
                    
                    // handle attribute "srcitem"
                    java.lang.String tempAttribSrcitem =
                        
                                reader.getAttributeValue(null,"srcitem");
                            
                   if (tempAttribSrcitem!=null){
                         java.lang.String content = tempAttribSrcitem;
                        
                                                 object.setSrcitem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribSrcitem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("srcitem");
                    
                    // handle attribute "svrfm"
                    java.lang.String tempAttribSvrfm =
                        
                                reader.getAttributeValue(null,"svrfm");
                            
                   if (tempAttribSvrfm!=null){
                         java.lang.String content = tempAttribSvrfm;
                        
                                                 object.setSvrfm(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribSvrfm));
                                            
                    } else {
                       
                                           object.setSvrfm(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("svrfm");
                    
                    // handle attribute "sdi"
                    java.lang.String tempAttribSdi =
                        
                                reader.getAttributeValue(null,"sdi");
                            
                   if (tempAttribSdi!=null){
                         java.lang.String content = tempAttribSdi;
                        
                                                 object.setSdi(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribSdi));
                                            
                    } else {
                       
                                           object.setSdi(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("sdi");
                    
                    // handle attribute "ver"
                    java.lang.String tempAttribVer =
                        
                                reader.getAttributeValue(null,"ver");
                            
                   if (tempAttribVer!=null){
                         java.lang.String content = tempAttribVer;
                        
                                                 object.setVer(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribVer));
                                            
                    } else {
                       
                                           object.setVer(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("ver");
                    
                    // handle attribute "hash"
                    java.lang.String tempAttribHash =
                        
                                reader.getAttributeValue(null,"hash");
                            
                   if (tempAttribHash!=null){
                         java.lang.String content = tempAttribHash;
                        
                                                 object.setHash(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(tempAttribHash));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("hash");
                    
                    // handle attribute "len"
                    java.lang.String tempAttribLen =
                        
                                reader.getAttributeValue(null,"len");
                            
                   if (tempAttribLen!=null){
                         java.lang.String content = tempAttribLen;
                        
                                                 object.setLen(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(tempAttribLen));
                                            
                    } else {
                       
                                           object.setLen(java.lang.Long.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("len");
                    
                    // handle attribute "uhash"
                    java.lang.String tempAttribUhash =
                        
                                reader.getAttributeValue(null,"uhash");
                            
                   if (tempAttribUhash!=null){
                         java.lang.String content = tempAttribUhash;
                        
                                                 object.setUhash(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBase64Binary(tempAttribUhash));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("uhash");
                    
                    // handle attribute "pcid"
                    java.lang.String tempAttribPcid =
                        
                                reader.getAttributeValue(null,"pcid");
                            
                   if (tempAttribPcid!=null){
                         java.lang.String content = tempAttribPcid;
                        
                                                 object.setPcid(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribPcid));
                                            
                    } else {
                       
                                           object.setPcid(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("pcid");
                    
                    // handle attribute "durl"
                    java.lang.String tempAttribDurl =
                        
                                reader.getAttributeValue(null,"durl");
                            
                   if (tempAttribDurl!=null){
                         java.lang.String content = tempAttribDurl;
                        
                                                 object.setDurl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribDurl));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("durl");
                    
                    // handle attribute "shelvedurl"
                    java.lang.String tempAttribShelvedurl =
                        
                                reader.getAttributeValue(null,"shelvedurl");
                            
                   if (tempAttribShelvedurl!=null){
                         java.lang.String content = tempAttribShelvedurl;
                        
                                                 object.setShelvedurl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribShelvedurl));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("shelvedurl");
                    
                    // handle attribute "ct"
                    java.lang.String tempAttribCt =
                        
                                reader.getAttributeValue(null,"ct");
                            
                   if (tempAttribCt!=null){
                         java.lang.String content = tempAttribCt;
                        
                                                 object.setCt(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribCt));
                                            
                    } else {
                       
                                           object.setCt(java.lang.Integer.MIN_VALUE);
                                       
                    }
                    handledAttributes.add("ct");
                    
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","MergeSources").equals(reader.getName())){
                                
                                                object.setMergeSources(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfMergeSource.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/TeamFoundation/2005/06/VersionControl/ClientServices/03","PropertyValues").equals(reader.getName())){
                                
                                                object.setPropertyValues(com.microsoft.schemas.teamfoundation._2005._06.versioncontrol.clientservices._03.ArrayOfPropertyValue.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          