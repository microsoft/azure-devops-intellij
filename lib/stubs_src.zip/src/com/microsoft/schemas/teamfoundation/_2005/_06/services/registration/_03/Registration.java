

/**
 * Registration.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.schemas.teamfoundation._2005._06.services.registration._03;

    /*
     *  Registration java interface
     */

    public interface Registration {
          

        /**
          * Auto generated method signature
          * 
                    * @param getRegistrationEntries
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.GetRegistrationEntriesResponse getRegistrationEntries(

                        com.microsoft.schemas.teamfoundation._2005._06.services.registration._03.GetRegistrationEntries getRegistrationEntries)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    