
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "package_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Package_type0E.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Column_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Column_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Package_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Package_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "package_type1".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Package_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "queriesPayload_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueriesPayload_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type5".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type5.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type4".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type4.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type3".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type3.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type2".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type2.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type8".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type8.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ComputedColumn_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ComputedColumn_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "GroupType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GroupType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type7".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type7.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "RequestHeader".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeader.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type6".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type6.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "psQuery_type1".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PsQuery_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "psQuery_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PsQuery_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type1".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "InsertResourceLink_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.InsertResourceLink_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "metadata_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Metadata_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "c_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.C_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "id_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Id_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "queryPayload_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryPayload_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.wsdl.types.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "OperatorType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.OperatorType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "GroupOperatorType".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GroupOperatorType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfInt".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ArrayOfInt.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "table_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Table_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Expression_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Expression_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "QuerySortOrderEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QuerySortOrderEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "query_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Query_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "InsertText_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.InsertText_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfMetadataTableHaveEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ArrayOfMetadataTableHaveEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "MetadataTableHaveEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.MetadataTableHaveEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "UpdateWorkItem_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateWorkItem_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Columns_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Columns_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "resultIds_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ResultIds_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "Query_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Query_type0E.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "r_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.R_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "IdRevisionPair".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.IdRevisionPair.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "result_type1".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Result_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "result_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Result_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "QueryIds_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryIds_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfQuerySortOrderEntry".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ArrayOfQuerySortOrderEntry.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "rows_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Rows_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "queryItemsPayload_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryItemsPayload_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "items_type2".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Items_type2.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "items_type1".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Items_type1.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "columns_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Columns_type0E.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfIdRevisionPair".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ArrayOfIdRevisionPair.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "items_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Items_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ArrayOfString".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ArrayOfString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "workItem_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.WorkItem_type0.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://schemas.microsoft.com/TeamFoundation/2005/06/WorkItemTracking/ClientServices/03".equals(namespaceURI) &&
                  "ComputedColumns_type0".equals(typeName)){
                   
                            return  com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.ComputedColumns_type0.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    