

/**
 * ClientService2.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03;

    /*
     *  ClientService2 java interface
     */

    public interface ClientService2 {
          

        /**
          * Auto generated method signature
          * 
                    * @param syncBisGroupsAndUsers
                
                    * @param requestHeader
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsersResponse syncBisGroupsAndUsers(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncBisGroupsAndUsers syncBisGroupsAndUsers,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitemCountOnBehalfOf
                
                    * @param requestHeader0
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOfResponse queryWorkitemCountOnBehalfOf(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountOnBehalfOf queryWorkitemCountOnBehalfOf,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader0)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQuery
                
                    * @param requestHeader1
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryResponse getStoredQuery(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQuery getStoredQuery,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader1)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getReferencingWorkitemUris
                
                    * @param requestHeader2
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUrisResponse getReferencingWorkitemUris(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetReferencingWorkitemUris getReferencingWorkitemUris,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader2)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQueryItems
                
                    * @param requestHeader3
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItemsResponse getStoredQueryItems(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueryItems getStoredQueryItems,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader3)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getStoredQueries
                
                    * @param requestHeader4
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueriesResponse getStoredQueries(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetStoredQueries getStoredQueries,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader4)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadata
                
                    * @param requestHeader5
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataResponse getMetadata(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadata getMetadata,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader5)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageWorkitemsByIdRevs
                
                    * @param requestHeader6
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevsResponse pageWorkitemsByIdRevs(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdRevs pageWorkitemsByIdRevs,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader6)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param syncAccessControlLists
                
                    * @param requestHeader7
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlListsResponse syncAccessControlLists(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncAccessControlLists syncAccessControlLists,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader7)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param stampWorkitemCache
                
                    * @param requestHeader8
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCacheResponse stampWorkitemCache(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.StampWorkitemCache stampWorkitemCache,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader8)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param bulkUpdate
                
                    * @param requestHeader9
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdateResponse bulkUpdate(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.BulkUpdate bulkUpdate,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader9)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadataEx2
                
                    * @param requestHeader10
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2Response getMetadataEx2(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx2 getMetadataEx2,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader10)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param requestCancel
                
                    * @param requestHeader11
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancelResponse requestCancel(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestCancel requestCancel,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader11)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageItemsOnBehalfOf
                
                    * @param requestHeader12
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOfResponse pageItemsOnBehalfOf(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageItemsOnBehalfOf pageItemsOnBehalfOf,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader12)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getWorkItem
                
                    * @param requestHeader13
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItemResponse getWorkItem(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkItem getWorkItem,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader13)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param syncExternalStructures
                
                    * @param requestHeader14
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructuresResponse syncExternalStructures(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.SyncExternalStructures syncExternalStructures,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader14)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getWorkitemTrackingVersion
                
                    * @param requestHeader15
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersionResponse getWorkitemTrackingVersion(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetWorkitemTrackingVersion getWorkitemTrackingVersion,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader15)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param update
                
                    * @param requestHeader16
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.UpdateResponse update(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.Update update,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader16)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitemCount
                
                    * @param requestHeader17
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCountResponse queryWorkitemCount(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemCount queryWorkitemCount,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader17)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryWorkitems
                
                    * @param requestHeader18
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitemsResponse queryWorkitems(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.QueryWorkitems queryWorkitems,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader18)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param getMetadataEx
                
                    * @param requestHeader19
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataExResponse getMetadataEx(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.GetMetadataEx getMetadataEx,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader19)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param pageWorkitemsByIds
                
                    * @param requestHeader20
                
         */

         
                     public com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIdsResponse pageWorkitemsByIds(

                        com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.PageWorkitemsByIds pageWorkitemsByIds,com.microsoft.schemas.teamfoundation._2005._06.workitemtracking.clientservices._03.RequestHeaderE requestHeader20)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    