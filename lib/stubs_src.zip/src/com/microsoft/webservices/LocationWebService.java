

/**
 * LocationWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.webservices;

    /*
     *  LocationWebService java interface
     */

    public interface LocationWebService {
          

        /**
          * Auto generated method signature
          * 
                    * @param setDefaultAccessMapping
                
         */

         
                     public com.microsoft.webservices.SetDefaultAccessMappingResponse setDefaultAccessMapping(

                        com.microsoft.webservices.SetDefaultAccessMapping setDefaultAccessMapping)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeServiceDefinitions
                
         */

         
                     public com.microsoft.webservices.RemoveServiceDefinitionsResponse removeServiceDefinitions(

                        com.microsoft.webservices.RemoveServiceDefinitions removeServiceDefinitions)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param removeAccessMapping
                
         */

         
                     public com.microsoft.webservices.RemoveAccessMappingResponse removeAccessMapping(

                        com.microsoft.webservices.RemoveAccessMapping removeAccessMapping)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryServices
                
         */

         
                     public com.microsoft.webservices.QueryServicesResponse queryServices(

                        com.microsoft.webservices.QueryServices queryServices)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param configureAccessMapping
                
         */

         
                     public com.microsoft.webservices.ConfigureAccessMappingResponse configureAccessMapping(

                        com.microsoft.webservices.ConfigureAccessMapping configureAccessMapping)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param connect
                
         */

         
                     public com.microsoft.webservices.ConnectResponse connect(

                        com.microsoft.webservices.Connect connect)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param saveServiceDefinitions
                
         */

         
                     public com.microsoft.webservices.SaveServiceDefinitionsResponse saveServiceDefinitions(

                        com.microsoft.webservices.SaveServiceDefinitions saveServiceDefinitions)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    