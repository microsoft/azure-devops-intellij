

/**
 * CatalogWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

    package com.microsoft.webservices;

    /*
     *  CatalogWebService java interface
     */

    public interface CatalogWebService {
          

        /**
          * Auto generated method signature
          * 
                    * @param queryNodes
                
         */

         
                     public com.microsoft.webservices.QueryNodesResponse queryNodes(

                        com.microsoft.webservices.QueryNodes queryNodes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryResources
                
         */

         
                     public com.microsoft.webservices.QueryResourcesResponse queryResources(

                        com.microsoft.webservices.QueryResources queryResources)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryDependents
                
         */

         
                     public com.microsoft.webservices.QueryDependentsResponse queryDependents(

                        com.microsoft.webservices.QueryDependents queryDependents)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryResourceTypes
                
         */

         
                     public com.microsoft.webservices.QueryResourceTypesResponse queryResourceTypes(

                        com.microsoft.webservices.QueryResourceTypes queryResourceTypes)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryResourcesByType
                
         */

         
                     public com.microsoft.webservices.QueryResourcesByTypeResponse queryResourcesByType(

                        com.microsoft.webservices.QueryResourcesByType queryResourcesByType)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param queryParents
                
         */

         
                     public com.microsoft.webservices.QueryParentsResponse queryParents(

                        com.microsoft.webservices.QueryParents queryParents)
                        throws java.rmi.RemoteException
             ;

        

        /**
          * Auto generated method signature
          * 
                    * @param saveCatalogChanges
                
         */

         
                     public com.microsoft.webservices.SaveCatalogChangesResponse saveCatalogChanges(

                        com.microsoft.webservices.SaveCatalogChanges saveCatalogChanges)
                        throws java.rmi.RemoteException
             ;

        

        
       //
       }
    