
/**
 * CatalogNode.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */
            
                package com.microsoft.webservices;
            

            /**
            *  CatalogNode bean class
            */
        
        public  class CatalogNode
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = CatalogNode
                Namespace URI = http://microsoft.com/webservices/
                Namespace Prefix = 
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://microsoft.com/webservices/")){
                return "";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for NodeDependencies
                        */

                        
                                    protected com.microsoft.webservices.ArrayOfCatalogNodeDependency localNodeDependencies ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localNodeDependenciesTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.webservices.ArrayOfCatalogNodeDependency
                           */
                           public  com.microsoft.webservices.ArrayOfCatalogNodeDependency getNodeDependencies(){
                               return localNodeDependencies;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param NodeDependencies
                               */
                               public void setNodeDependencies(com.microsoft.webservices.ArrayOfCatalogNodeDependency param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localNodeDependenciesTracker = true;
                                       } else {
                                          localNodeDependenciesTracker = false;
                                              
                                       }
                                   
                                            this.localNodeDependencies=param;
                                    

                               }
                            

                        /**
                        * field for FullPath
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localFullPath ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getFullPath(){
                               return localFullPath;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FullPath
                               */
                               public void setFullPath(java.lang.String param){
                            
                                            this.localFullPath=param;
                                    

                               }
                            

                        /**
                        * field for _default
                        * This was an Attribute!
                        */

                        
                                    protected boolean local_default ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean get_default(){
                               return local_default;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param _default
                               */
                               public void set_default(boolean param){
                            
                                            this.local_default=param;
                                    

                               }
                            

                        /**
                        * field for ResourceIdentifier
                        * This was an Attribute!
                        */

                        
                                    protected com.microsoft.wsdl.types.Guid localResourceIdentifier ;
                                

                           /**
                           * Auto generated getter method
                           * @return com.microsoft.wsdl.types.Guid
                           */
                           public  com.microsoft.wsdl.types.Guid getResourceIdentifier(){
                               return localResourceIdentifier;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ResourceIdentifier
                               */
                               public void setResourceIdentifier(com.microsoft.wsdl.types.Guid param){
                            
                                            this.localResourceIdentifier=param;
                                    

                               }
                            

                        /**
                        * field for ParentPath
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localParentPath ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getParentPath(){
                               return localParentPath;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ParentPath
                               */
                               public void setParentPath(java.lang.String param){
                            
                                            this.localParentPath=param;
                                    

                               }
                            

                        /**
                        * field for ChildItem
                        * This was an Attribute!
                        */

                        
                                    protected java.lang.String localChildItem ;
                                

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getChildItem(){
                               return localChildItem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ChildItem
                               */
                               public void setChildItem(java.lang.String param){
                            
                                            this.localChildItem=param;
                                    

                               }
                            

                        /**
                        * field for NodeDependenciesIncluded
                        * This was an Attribute!
                        */

                        
                                    protected boolean localNodeDependenciesIncluded ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getNodeDependenciesIncluded(){
                               return localNodeDependenciesIncluded;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param NodeDependenciesIncluded
                               */
                               public void setNodeDependenciesIncluded(boolean param){
                            
                                            this.localNodeDependenciesIncluded=param;
                                    

                               }
                            

                        /**
                        * field for Ctype
                        * This was an Attribute!
                        */

                        
                                    protected int localCtype ;
                                

                           /**
                           * Auto generated getter method
                           * @return int
                           */
                           public  int getCtype(){
                               return localCtype;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Ctype
                               */
                               public void setCtype(int param){
                            
                                            this.localCtype=param;
                                    

                               }
                            

                        /**
                        * field for MatchedQuery
                        * This was an Attribute!
                        */

                        
                                    protected boolean localMatchedQuery ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getMatchedQuery(){
                               return localMatchedQuery;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MatchedQuery
                               */
                               public void setMatchedQuery(boolean param){
                            
                                            this.localMatchedQuery=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       CatalogNode.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://microsoft.com/webservices/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":CatalogNode",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "CatalogNode",
                           xmlWriter);
                   }

               
                   }
               
                                            if (localFullPath != null){
                                        
                                                writeAttribute("",
                                                         "FullPath",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFullPath), xmlWriter);

                                            
                                      }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "default",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(local_default), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute local_default is null");
                                      }
                                    
                                    
                                    if (localResourceIdentifier != null){
                                        writeAttribute("",
                                           "ResourceIdentifier",
                                           localResourceIdentifier.toString(), xmlWriter);
                                    }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localResourceIdentifier is null");
                                      }
                                    
                                            if (localParentPath != null){
                                        
                                                writeAttribute("",
                                                         "ParentPath",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localParentPath), xmlWriter);

                                            
                                      }
                                    
                                            if (localChildItem != null){
                                        
                                                writeAttribute("",
                                                         "ChildItem",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChildItem), xmlWriter);

                                            
                                      }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "NodeDependenciesIncluded",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localNodeDependenciesIncluded), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localNodeDependenciesIncluded is null");
                                      }
                                    
                                                   if (localCtype!=java.lang.Integer.MIN_VALUE) {
                                               
                                                writeAttribute("",
                                                         "ctype",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCtype), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localCtype is null");
                                      }
                                    
                                                   if (true) {
                                               
                                                writeAttribute("",
                                                         "MatchedQuery",
                                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMatchedQuery), xmlWriter);

                                            
                                      }
                                    
                                      else {
                                          throw new org.apache.axis2.databinding.ADBException("required attribute localMatchedQuery is null");
                                      }
                                     if (localNodeDependenciesTracker){
                                            if (localNodeDependencies==null){
                                                 throw new org.apache.axis2.databinding.ADBException("NodeDependencies cannot be null!!");
                                            }
                                           localNodeDependencies.serialize(new javax.xml.namespace.QName("http://microsoft.com/webservices/","NodeDependencies"),
                                               factory,xmlWriter);
                                        }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localNodeDependenciesTracker){
                            elementList.add(new javax.xml.namespace.QName("http://microsoft.com/webservices/",
                                                                      "NodeDependencies"));
                            
                            
                                    if (localNodeDependencies==null){
                                         throw new org.apache.axis2.databinding.ADBException("NodeDependencies cannot be null!!");
                                    }
                                    elementList.add(localNodeDependencies);
                                }
                            attribList.add(
                            new javax.xml.namespace.QName("","FullPath"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFullPath));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","default"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(local_default));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ResourceIdentifier"));
                            
                                      attribList.add(localResourceIdentifier.toString());
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ParentPath"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localParentPath));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ChildItem"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChildItem));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","NodeDependenciesIncluded"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localNodeDependenciesIncluded));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","ctype"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCtype));
                                
                            attribList.add(
                            new javax.xml.namespace.QName("","MatchedQuery"));
                            
                                      attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMatchedQuery));
                                

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static CatalogNode parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            CatalogNode object =
                new CatalogNode();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"CatalogNode".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (CatalogNode)com.microsoft.webservices.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    // handle attribute "FullPath"
                    java.lang.String tempAttribFullPath =
                        
                                reader.getAttributeValue(null,"FullPath");
                            
                   if (tempAttribFullPath!=null){
                         java.lang.String content = tempAttribFullPath;
                        
                                                 object.setFullPath(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribFullPath));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("FullPath");
                    
                    // handle attribute "default"
                    java.lang.String tempAttrib_default =
                        
                                reader.getAttributeValue(null,"default");
                            
                   if (tempAttrib_default!=null){
                         java.lang.String content = tempAttrib_default;
                        
                                                 object.set_default(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttrib_default));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute default is missing");
                           
                    }
                    handledAttributes.add("default");
                    
                    // handle attribute "ResourceIdentifier"
                    java.lang.String tempAttribResourceIdentifier =
                        
                                reader.getAttributeValue(null,"ResourceIdentifier");
                            
                   if (tempAttribResourceIdentifier!=null){
                         java.lang.String content = tempAttribResourceIdentifier;
                        
                                                  object.setResourceIdentifier(
                                                        com.microsoft.wsdl.types.Guid.Factory.fromString(reader,tempAttribResourceIdentifier));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ResourceIdentifier is missing");
                           
                    }
                    handledAttributes.add("ResourceIdentifier");
                    
                    // handle attribute "ParentPath"
                    java.lang.String tempAttribParentPath =
                        
                                reader.getAttributeValue(null,"ParentPath");
                            
                   if (tempAttribParentPath!=null){
                         java.lang.String content = tempAttribParentPath;
                        
                                                 object.setParentPath(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribParentPath));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ParentPath");
                    
                    // handle attribute "ChildItem"
                    java.lang.String tempAttribChildItem =
                        
                                reader.getAttributeValue(null,"ChildItem");
                            
                   if (tempAttribChildItem!=null){
                         java.lang.String content = tempAttribChildItem;
                        
                                                 object.setChildItem(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(tempAttribChildItem));
                                            
                    } else {
                       
                    }
                    handledAttributes.add("ChildItem");
                    
                    // handle attribute "NodeDependenciesIncluded"
                    java.lang.String tempAttribNodeDependenciesIncluded =
                        
                                reader.getAttributeValue(null,"NodeDependenciesIncluded");
                            
                   if (tempAttribNodeDependenciesIncluded!=null){
                         java.lang.String content = tempAttribNodeDependenciesIncluded;
                        
                                                 object.setNodeDependenciesIncluded(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttribNodeDependenciesIncluded));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute NodeDependenciesIncluded is missing");
                           
                    }
                    handledAttributes.add("NodeDependenciesIncluded");
                    
                    // handle attribute "ctype"
                    java.lang.String tempAttribCtype =
                        
                                reader.getAttributeValue(null,"ctype");
                            
                   if (tempAttribCtype!=null){
                         java.lang.String content = tempAttribCtype;
                        
                                                 object.setCtype(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(tempAttribCtype));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute ctype is missing");
                           
                    }
                    handledAttributes.add("ctype");
                    
                    // handle attribute "MatchedQuery"
                    java.lang.String tempAttribMatchedQuery =
                        
                                reader.getAttributeValue(null,"MatchedQuery");
                            
                   if (tempAttribMatchedQuery!=null){
                         java.lang.String content = tempAttribMatchedQuery;
                        
                                                 object.setMatchedQuery(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(tempAttribMatchedQuery));
                                            
                    } else {
                       
                               throw new org.apache.axis2.databinding.ADBException("Required attribute MatchedQuery is missing");
                           
                    }
                    handledAttributes.add("MatchedQuery");
                    
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://microsoft.com/webservices/","NodeDependencies").equals(reader.getName())){
                                
                                                object.setNodeDependencies(com.microsoft.webservices.ArrayOfCatalogNodeDependency.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          