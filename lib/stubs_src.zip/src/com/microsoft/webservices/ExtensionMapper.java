
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.webservices;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfGuid".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfGuid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfCatalogServiceReference".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfCatalogServiceReference.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfCatalogResourceType".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfCatalogResourceType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfLocationMapping".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfLocationMapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "CatalogResource".equals(typeName)){
                   
                            return  com.microsoft.webservices.CatalogResource.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfCatalogNodeDependency".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfCatalogNodeDependency.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfCatalogResource".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfCatalogResource.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.wsdl.types.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfString".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ServiceDefinition".equals(typeName)){
                   
                            return  com.microsoft.webservices.ServiceDefinition.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "CatalogNode".equals(typeName)){
                   
                            return  com.microsoft.webservices.CatalogNode.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfKeyValueOfStringString".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfKeyValueOfStringString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "CatalogResourceType".equals(typeName)){
                   
                            return  com.microsoft.webservices.CatalogResourceType.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "CatalogData".equals(typeName)){
                   
                            return  com.microsoft.webservices.CatalogData.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "KeyValueOfStringString".equals(typeName)){
                   
                            return  com.microsoft.webservices.KeyValueOfStringString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "CatalogNodeDependency".equals(typeName)){
                   
                            return  com.microsoft.webservices.CatalogNodeDependency.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "LocationMapping".equals(typeName)){
                   
                            return  com.microsoft.webservices.LocationMapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "CatalogServiceReference".equals(typeName)){
                   
                            return  com.microsoft.webservices.CatalogServiceReference.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfCatalogNode".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfCatalogNode.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    