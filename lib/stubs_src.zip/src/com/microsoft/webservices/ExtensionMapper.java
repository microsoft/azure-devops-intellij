
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:34 EDT)
 */

            package com.microsoft.webservices;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ServiceTypeFilter".equals(typeName)){
                   
                            return  com.microsoft.webservices.ServiceTypeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfAccessMapping".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfAccessMapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "LocationServiceData".equals(typeName)){
                   
                            return  com.microsoft.webservices.LocationServiceData.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfServiceDefinition".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfServiceDefinition.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfServiceTypeFilter".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfServiceTypeFilter.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "TeamFoundationIdentity".equals(typeName)){
                   
                            return  com.microsoft.webservices.TeamFoundationIdentity.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfLocationMapping".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfLocationMapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                  "guid".equals(typeName)){
                   
                            return  com.microsoft.wsdl.types.Guid.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "AccessMapping".equals(typeName)){
                   
                            return  com.microsoft.webservices.AccessMapping.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "IdentityDescriptor".equals(typeName)){
                   
                            return  com.microsoft.webservices.IdentityDescriptor.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfIdentityDescriptor".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfIdentityDescriptor.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ServiceDefinition".equals(typeName)){
                   
                            return  com.microsoft.webservices.ServiceDefinition.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ArrayOfKeyValueOfStringString".equals(typeName)){
                   
                            return  com.microsoft.webservices.ArrayOfKeyValueOfStringString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "ConnectionData".equals(typeName)){
                   
                            return  com.microsoft.webservices.ConnectionData.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "KeyValueOfStringString".equals(typeName)){
                   
                            return  com.microsoft.webservices.KeyValueOfStringString.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://microsoft.com/webservices/".equals(namespaceURI) &&
                  "LocationMapping".equals(typeName)){
                   
                            return  com.microsoft.webservices.LocationMapping.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    